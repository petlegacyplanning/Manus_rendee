export const petLawReferences: Record<string, { petTrustLaw: string; notes: string }> = {
  Alabama: {
    petTrustLaw: "Ala. Code § 19-3B-408",
    notes: "Alabama law allows creation of a trust for the care of animals alive during the settlor's lifetime.",
  },
  Alaska: {
    petTrustLaw: "Alaska Stat. § 13.36.040",
    notes: "Allows a trust to provide for care of animals alive during the lifetime of the settlor.",
  },
  Arizona: {
    petTrustLaw: "Ariz. Rev. Stat. § 14-10408",
    notes: "Arizona recognizes enforceable pet trusts for animals alive during the settlor's lifetime.",
  },
  Arkansas: {
    petTrustLaw: "Ark. Code § 28-73-408",
    notes: "Allows trusts for animals alive during the settlor's lifetime.",
  },
  California: {
    petTrustLaw: "Cal. Probate Code § 15212",
    notes: "California law recognizes pet trusts for care of animals after an owner's death.",
  },
  Colorado: {
    petTrustLaw: "Colo. Rev. Stat. § 15-11-901",
    notes: "Colorado permits trusts to care for animals alive during the settlor's lifetime.",
  },
  Connecticut: {
    petTrustLaw: "Conn. Gen. Stat. § 45a-489a",
    notes: "Pet trusts are legally recognized in Connecticut.",
  },
  Delaware: {
    petTrustLaw: "12 Del. Code § 3555",
    notes: "Allows enforceable pet trusts for animals alive during the settlor's lifetime.",
  },
  Florida: {
    petTrustLaw: "Fla. Stat. § 736.0408",
    notes: "Florida recognizes enforceable trusts for the care of animals.",
  },
  Georgia: {
    petTrustLaw: "Ga. Code § 53-12-28",
    notes: "Allows creation of a trust for the care of animals alive during the settlor's lifetime.",
  },
  Hawaii: {
    petTrustLaw: "Haw. Rev. Stat. § 560:7-408",
    notes: "Allows enforceable pet trusts.",
  },
  Idaho: {
    petTrustLaw: "Idaho Code § 15-7-408",
    notes: "Allows trusts for animals alive during the settlor's lifetime.",
  },
  Illinois: {
    petTrustLaw: "760 ILCS 5/15.2",
    notes: "Illinois recognizes enforceable trusts for pets.",
  },
  Indiana: {
    petTrustLaw: "Ind. Code § 30-4-2-18",
    notes: "Pet trusts allowed for animals alive during settlor's lifetime.",
  },
  Iowa: {
    petTrustLaw: "Iowa Code § 633A.2105",
    notes: "Allows pet trusts enforceable by a court.",
  },
  Kansas: {
    petTrustLaw: "Kan. Stat. § 58a-408",
    notes: "Allows trusts for care of animals.",
  },
  Kentucky: {
    petTrustLaw: "Ky. Rev. Stat. § 386B.4-080",
    notes: "Allows enforceable trusts for animals.",
  },
  Louisiana: {
    petTrustLaw: "La. Rev. Stat. § 9:2263",
    notes: "Allows pet care trusts.",
  },
  Maine: {
    petTrustLaw: "Me. Rev. Stat. tit. 18-B § 408",
    notes: "Allows trusts for animals alive during the settlor's lifetime.",
  },
  Maryland: {
    petTrustLaw: "Md. Code Est. & Trusts § 14.5-408",
    notes: "Allows enforceable pet trusts.",
  },
  Massachusetts: {
    petTrustLaw: "Mass. Gen. Laws ch. 203E § 408",
    notes: "Allows pet trusts enforceable for care of animals.",
  },
  Michigan: {
    petTrustLaw: "Mich. Comp. Laws § 700.2722",
    notes: "Allows trusts for care of animals alive during the settlor's lifetime.",
  },
  Minnesota: {
    petTrustLaw: "Minn. Stat. § 501C.1401",
    notes: "Minnesota recognizes enforceable pet trusts.",
  },
  Mississippi: {
    petTrustLaw: "Miss. Code § 91-9-501",
    notes: "Allows trusts for care of animals.",
  },
  Missouri: {
    petTrustLaw: "Mo. Rev. Stat. § 456.4-408",
    notes: "Allows enforceable pet trusts.",
  },
  Montana: {
    petTrustLaw: "Mont. Code Ann. § 72-2-1029",
    notes: "Montana permits trusts for animals alive during the settlor's lifetime.",
  },
  Nebraska: {
    petTrustLaw: "Neb. Rev. Stat. § 30-3408",
    notes: "Allows trusts for care of animals.",
  },
  Nevada: {
    petTrustLaw: "Nev. Rev. Stat. § 163.0055",
    notes: "Nevada recognizes enforceable pet trusts.",
  },
  "New Hampshire": {
    petTrustLaw: "N.H. Rev. Stat. § 564:23-g",
    notes: "Allows pet trusts for animals alive during the settlor's lifetime.",
  },
  "New Jersey": {
    petTrustLaw: "N.J. Stat. § 3B:3-38",
    notes: "New Jersey recognizes enforceable pet trusts.",
  },
  "New Mexico": {
    petTrustLaw: "N.M. Stat. § 46A-4-408",
    notes: "Allows trusts for care of animals.",
  },
  "New York": {
    petTrustLaw: "N.Y. Est. Powers & Trusts Law § 7-8.1",
    notes: "New York recognizes enforceable trusts for pets.",
  },
  "North Carolina": {
    petTrustLaw: "N.C. Gen. Stat. § 36C-4-408",
    notes: "Allows enforceable pet trusts.",
  },
  "North Dakota": {
    petTrustLaw: "N.D. Cent. Code § 59-04-08",
    notes: "Allows trusts for animals alive during the settlor's lifetime.",
  },
  Ohio: {
    petTrustLaw: "Ohio Rev. Code § 1339.65",
    notes: "Ohio recognizes enforceable pet trusts.",
  },
  Oklahoma: {
    petTrustLaw: "Okla. Stat. § 84-44",
    notes: "Allows trusts for care of animals.",
  },
  Oregon: {
    petTrustLaw: "Or. Rev. Stat. § 130.710",
    notes: "Oregon permits enforceable pet trusts.",
  },
  Pennsylvania: {
    petTrustLaw: "20 Pa. Cons. Stat. § 7408",
    notes: "Allows trusts for animals alive during the settlor's lifetime.",
  },
  "Rhode Island": {
    petTrustLaw: "R.I. Gen. Laws § 34-5-35",
    notes: "Rhode Island recognizes enforceable pet trusts.",
  },
  "South Carolina": {
    petTrustLaw: "S.C. Code § 62-7-408",
    notes: "Allows trusts for care of animals.",
  },
  "South Dakota": {
    petTrustLaw: "S.D. Codified Laws § 55-2-13",
    notes: "South Dakota permits enforceable pet trusts.",
  },
  Tennessee: {
    petTrustLaw: "Tenn. Code § 35-15-408",
    notes: "Allows trusts for animals alive during the settlor's lifetime.",
  },
  Texas: {
    petTrustLaw: "Tex. Prop. Code § 112.037",
    notes: "Texas recognizes enforceable trusts for pets.",
  },
  Utah: {
    petTrustLaw: "Utah Code § 75-2-1001",
    notes: "Allows trusts for care of animals.",
  },
  Vermont: {
    petTrustLaw: "Vt. Stat. Ann. tit. 14 § 408",
    notes: "Vermont permits enforceable pet trusts.",
  },
  Virginia: {
    petTrustLaw: "Va. Code § 64.2-746",
    notes: "Allows trusts for animals alive during the settlor's lifetime.",
  },
  Washington: {
    petTrustLaw: "Wash. Rev. Code § 11.118.005",
    notes: "Washington recognizes enforceable pet trusts.",
  },
  "West Virginia": {
    petTrustLaw: "W. Va. Code § 44-6-28",
    notes: "Allows trusts for care of animals.",
  },
  Wisconsin: {
    petTrustLaw: "Wis. Stat. § 701.10",
    notes: "Wisconsin permits enforceable pet trusts.",
  },
  Wyoming: {
    petTrustLaw: "Wyo. Stat. § 4-10-408",
    notes: "Allows trusts for animals alive during the settlor's lifetime.",
  },
};
