import {
  boolean,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  planTier: mysqlEnum("planTier", ["free", "premium", "ultimate", "platinum"]).default("free").notNull(),
  affiliateCode: varchar("affiliateCode", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Organizations (rescues/shelters) ─────────────────────────────────────────
export const organizations = mysqlTable("organizations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["rescue", "shelter", "other"]).default("rescue").notNull(),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 50 }),
  website: varchar("website", { length: 255 }),
  description: text("description"),
  logoUrl: varchar("logoUrl", { length: 512 }),
  approved: boolean("approved").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Organization = typeof organizations.$inferSelect;

// ─── Pets ─────────────────────────────────────────────────────────────────────
export const pets = mysqlTable("pets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  species: varchar("species", { length: 50 }),
  breed: varchar("breed", { length: 100 }),
  age: varchar("age", { length: 20 }),
  color: varchar("color", { length: 100 }),
  photoUrl: varchar("photoUrl", { length: 512 }),
  microchipId: varchar("microchipId", { length: 100 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Pet = typeof pets.$inferSelect;

// ─── Plan Workspaces ──────────────────────────────────────────────────────────
export const planWorkspaces = mysqlTable("plan_workspaces", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  tier: mysqlEnum("tier", ["free", "premium", "ultimate", "platinum"]).default("free").notNull(),
  completionPct: int("completionPct").default(0).notNull(),
  lastSaved: timestamp("lastSaved").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type PlanWorkspace = typeof planWorkspaces.$inferSelect;

// ─── Plan Sections ────────────────────────────────────────────────────────────
export const planSections = mysqlTable("plan_sections", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  sectionKey: varchar("sectionKey", { length: 50 }).notNull(),
  data: json("data"),
  completed: boolean("completed").default(false).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type PlanSection = typeof planSections.$inferSelect;

// ─── Adoption Listings ────────────────────────────────────────────────────────
export const adoptionListings = mysqlTable("adoption_listings", {
  id: int("id").autoincrement().primaryKey(),
  orgId: int("orgId").notNull(),
  petName: varchar("petName", { length: 100 }).notNull(),
  species: varchar("species", { length: 50 }),
  breed: varchar("breed", { length: 100 }),
  age: varchar("age", { length: 20 }),
  gender: mysqlEnum("gender", ["male", "female", "unknown"]).default("unknown"),
  photoUrl: varchar("photoUrl", { length: 512 }),
  description: text("description"),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 50 }),
  status: mysqlEnum("status", ["available", "pending", "adopted"]).default("available").notNull(),
  featured: boolean("featured").default(false).notNull(),
  approved: boolean("approved").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type AdoptionListing = typeof adoptionListings.$inferSelect;

// ─── Rehoming Listings ────────────────────────────────────────────────────────
export const rehomingListings = mysqlTable("rehoming_listings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  petName: varchar("petName", { length: 100 }).notNull(),
  species: varchar("species", { length: 50 }),
  breed: varchar("breed", { length: 100 }),
  age: varchar("age", { length: 20 }),
  gender: mysqlEnum("gender", ["male", "female", "unknown"]).default("unknown"),
  photoUrl: varchar("photoUrl", { length: 512 }),
  description: text("description"),
  reason: text("reason"),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 50 }),
  contactEmail: varchar("contactEmail", { length: 320 }),
  status: mysqlEnum("status", ["active", "pending_review", "rehomed", "removed"]).default("pending_review").notNull(),
  approved: boolean("approved").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type RehomingListing = typeof rehomingListings.$inferSelect;

// ─── Newsletter Issues ────────────────────────────────────────────────────────
export const newsletterIssues = mysqlTable("newsletter_issues", {
  id: int("id").autoincrement().primaryKey(),
  issueNumber: int("issueNumber").notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  publishDate: timestamp("publishDate").notNull(),
  breedOfWeek: varchar("breedOfWeek", { length: 100 }),
  funFacts: json("funFacts"),
  triviaQuestions: json("triviaQuestions"),
  triviaAnswers: json("triviaAnswers"),
  healthcareSection: text("healthcareSection"),
  trainingTip: text("trainingTip"),
  sponsoredContent: text("sponsoredContent"),
  memorialEntries: json("memorialEntries"),
  crosswordData: json("crosswordData"),
  wordSearchData: json("wordSearchData"),
  published: boolean("published").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type NewsletterIssue = typeof newsletterIssues.$inferSelect;

// ─── Memorial Entries ─────────────────────────────────────────────────────────
export const memorialEntries = mysqlTable("memorial_entries", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  petName: varchar("petName", { length: 100 }).notNull(),
  species: varchar("species", { length: 50 }),
  breed: varchar("breed", { length: 100 }),
  birthDate: varchar("birthDate", { length: 20 }),
  passDate: varchar("passDate", { length: 20 }),
  photoUrl: varchar("photoUrl", { length: 512 }),
  tribute: text("tribute"),
  submitterName: varchar("submitterName", { length: 100 }),
  approved: boolean("approved").default(false).notNull(),
  featured: boolean("featured").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type MemorialEntry = typeof memorialEntries.$inferSelect;

// ─── Registered Pets ──────────────────────────────────────────────────────────
export const registeredPets = mysqlTable("registered_pets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  petName: varchar("petName", { length: 100 }).notNull(),
  species: varchar("species", { length: 50 }),
  breed: varchar("breed", { length: 100 }),
  photoUrl: varchar("photoUrl", { length: 512 }),
  registrationNumber: varchar("registrationNumber", { length: 32 }).unique(),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 50 }),
  approved: boolean("approved").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type RegisteredPet = typeof registeredPets.$inferSelect;

// ─── Community Entries (Pet of Week/Month) ────────────────────────────────────
export const communityEntries = mysqlTable("community_entries", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  category: mysqlEnum("category", [
    "pet_of_week", "cutest_pet", "hero_pet", "breed_of_week",
    "rescue_of_week", "shelter_pet", "pet_of_month"
  ]).notNull(),
  petName: varchar("petName", { length: 100 }).notNull(),
  ownerName: varchar("ownerName", { length: 100 }),
  species: varchar("species", { length: 50 }),
  breed: varchar("breed", { length: 100 }),
  photoUrl: varchar("photoUrl", { length: 512 }),
  story: text("story"),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 50 }),
  featured: boolean("featured").default(false).notNull(),
  approved: boolean("approved").default(false).notNull(),
  weekOf: varchar("weekOf", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type CommunityEntry = typeof communityEntries.$inferSelect;

// ─── Affiliate Codes ──────────────────────────────────────────────────────────
export const affiliateCodes = mysqlTable("affiliate_codes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  code: varchar("code", { length: 32 }).notNull().unique(),
  affiliateName: varchar("affiliateName", { length: 100 }),
  discountPct: int("discountPct").default(10).notNull(),
  commissionPct: int("commissionPct").default(10).notNull(),
  visits: int("visits").default(0).notNull(),
  conversions: int("conversions").default(0).notNull(),
  totalRevenue: decimal("totalRevenue", { precision: 10, scale: 2 }).default("0.00"),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type AffiliateCode = typeof affiliateCodes.$inferSelect;

// ─── Promo Codes ──────────────────────────────────────────────────────────────
export const promoCodes = mysqlTable("promo_codes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  discountPct: int("discountPct").notNull(),
  maxUses: int("maxUses"),
  uses: int("uses").default(0).notNull(),
  expiresAt: timestamp("expiresAt"),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type PromoCode = typeof promoCodes.$inferSelect;

// ─── Platinum Clients ─────────────────────────────────────────────────────────
export const platinumClients = mysqlTable("platinum_clients", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  assignedAdminId: int("assignedAdminId"),
  status: mysqlEnum("status", ["intake", "in_progress", "review", "complete"]).default("intake").notNull(),
  notes: text("notes"),
  missingItems: json("missingItems"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type PlatinumClient = typeof platinumClients.$inferSelect;

// ─── Library Articles ─────────────────────────────────────────────────────────
export const libraryArticles = mysqlTable("library_articles", {
  id: int("id").autoincrement().primaryKey(),
  hub: varchar("hub", { length: 100 }).notNull(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  excerpt: text("excerpt"),
  content: text("content"),
  tags: json("tags"),
  metaTitle: varchar("metaTitle", { length: 255 }),
  metaDesc: text("metaDesc"),
  published: boolean("published").default(true).notNull(),
  featured: boolean("featured").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type LibraryArticle = typeof libraryArticles.$inferSelect;

// ─── Newsletter Subscribers ───────────────────────────────────────────────────
export const newsletterSubscribers = mysqlTable("newsletter_subscribers", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  name: varchar("name", { length: 100 }),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;

// ─── Orders ───────────────────────────────────────────────────────────────────
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  tier: mysqlEnum("tier", ["premium", "ultimate", "platinum"]).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  promoCode: varchar("promoCode", { length: 32 }),
  affiliateCode: varchar("affiliateCode", { length: 32 }),
  discountApplied: decimal("discountApplied", { precision: 10, scale: 2 }).default("0.00"),
  status: mysqlEnum("status", ["pending", "complete", "refunded"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Order = typeof orders.$inferSelect;

// ─── Contact Messages ─────────────────────────────────────────────────────────
export const contactMessages = mysqlTable("contact_messages", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 255 }),
  message: text("message"),
  type: varchar("type", { length: 50 }).default("general"),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ContactMessage = typeof contactMessages.$inferSelect;

// ─── Planner Projects ──────────────────────────────────────────────────────────
export const plannerProjects = mysqlTable("planner_projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  planTier: mysqlEnum("planTier", ["basic", "premium", "ultimate", "platinum"]).notNull(),
  status: mysqlEnum("status", ["in_progress", "completed"]).default("in_progress").notNull(),
  currentStep: int("currentStep").default(0).notNull(),
  totalSteps: int("totalSteps").default(8).notNull(),
  data: json("data"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type PlannerProject = typeof plannerProjects.$inferSelect;
export type InsertPlannerProject = typeof plannerProjects.$inferInsert;

// ─── Quiz Responses ──────────────────────────────────────────────────────────
export const quizResponses = mysqlTable("quiz_responses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  score: int("score").notNull(),
  answers: json("answers"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type QuizResponse = typeof quizResponses.$inferSelect;
export type InsertQuizResponse = typeof quizResponses.$inferInsert;

// ─── Pet Map Pins ─────────────────────────────────────────────────────────
export const petPins = mysqlTable("pet_pins", {
  id: int("id").autoincrement().primaryKey(),
  petName: varchar("petName", { length: 100 }).notNull(),
  breed: varchar("breed", { length: 100 }),
  city: varchar("city", { length: 100 }).notNull(),
  state: varchar("state", { length: 50 }).notNull(),
  story: text("story"),
  lat: decimal("lat", { precision: 10, scale: 6 }).notNull(),
  lng: decimal("lng", { precision: 10, scale: 6 }).notNull(),
  approved: boolean("approved").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type PetPin = typeof petPins.$inferSelect;

// ─── Pet Guardian Registry ────────────────────────────────────────────────────
export const petGuardianRegistry = mysqlTable("pet_guardian_registry", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  
  // Pet Information
  petName: varchar("petName", { length: 100 }).notNull(),
  petSpecies: varchar("petSpecies", { length: 50 }).notNull(),
  petBreed: varchar("petBreed", { length: 100 }),
  petAge: int("petAge"),
  petMicrochipId: varchar("petMicrochipId", { length: 100 }),
  petMedicalNotes: text("petMedicalNotes"),
  
  // Guardian Information
  guardianName: varchar("guardianName", { length: 100 }).notNull(),
  guardianPhone: varchar("guardianPhone", { length: 20 }).notNull(),
  guardianEmail: varchar("guardianEmail", { length: 255 }),
  guardianAddress: text("guardianAddress"),
  
  // Emergency Contact
  emergencyContactName: varchar("emergencyContactName", { length: 100 }),
  emergencyContactPhone: varchar("emergencyContactPhone", { length: 20 }),
  emergencyContactRelationship: varchar("emergencyContactRelationship", { length: 100 }),
  
  // Location
  state: varchar("state", { length: 50 }).notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  
  // Metadata
  registrationStatus: mysqlEnum("registrationStatus", ["active", "inactive", "pending"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PetGuardianRegistry = typeof petGuardianRegistry.$inferSelect;
export type InsertPetGuardianRegistry = typeof petGuardianRegistry.$inferInsert;


// ─── Directory Listings ───────────────────────────────────────────────────────
export const directoryListings = mysqlTable("directory_listings", {
  id: int("id").autoincrement().primaryKey(),
  
  // Business Information
  businessName: varchar("businessName", { length: 255 }).notNull(),
  businessType: varchar("businessType", { length: 100 }).notNull(), // e.g., "Veterinarian", "Pet Groomer", "Pet Sitter"
  businessEmail: varchar("businessEmail", { length: 255 }).notNull(),
  businessPhone: varchar("businessPhone", { length: 20 }).notNull(),
  businessWebsite: varchar("businessWebsite", { length: 255 }),
  
  // Address
  address: text("address").notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  state: varchar("state", { length: 50 }).notNull(),
  zipCode: varchar("zipCode", { length: 10 }),
  
  // Listing Details
  description: text("description"),
  services: text("services"), // JSON array of services
  
  // Pricing & Status
  listingTier: mysqlEnum("listingTier", ["basic", "premium"]).default("basic").notNull(),
  price: int("price").notNull(), // in cents
  renewalDate: timestamp("renewalDate"),
  
  // Verification
  verified: boolean("verified").default(false).notNull(),
  verificationCode: varchar("verificationCode", { length: 100 }),
  
  // Metadata
  googlePlacesId: varchar("googlePlacesId", { length: 255 }),
  approvalStatus: mysqlEnum("approvalStatus", ["pending", "approved", "rejected"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DirectoryListing = typeof directoryListings.$inferSelect;
export type InsertDirectoryListing = typeof directoryListings.$inferInsert;

// ─── Outreach Campaigns ───────────────────────────────────────────────────────
export const outreachCampaigns = mysqlTable("outreach_campaigns", {
  id: int("id").autoincrement().primaryKey(),
  
  // Campaign Details
  campaignName: varchar("campaignName", { length: 255 }).notNull(),
  description: text("description"),
  
  // Target Cities
  targetCities: text("targetCities").notNull(), // JSON array of cities
  
  // Campaign Status
  status: mysqlEnum("status", ["draft", "active", "paused", "completed"]).default("draft").notNull(),
  
  // Email Template
  emailSubject: varchar("emailSubject", { length: 255 }).notNull(),
  emailBody: text("emailBody").notNull(),
  
  // Metrics
  leadsDiscovered: int("leadsDiscovered").default(0).notNull(),
  emailsSent: int("emailsSent").default(0).notNull(),
  responsesReceived: int("responsesReceived").default(0).notNull(),
  conversions: int("conversions").default(0).notNull(),
  
  // Dates
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OutreachCampaign = typeof outreachCampaigns.$inferSelect;
export type InsertOutreachCampaign = typeof outreachCampaigns.$inferInsert;

// ─── Campaign Leads ───────────────────────────────────────────────────────────
export const campaignLeads = mysqlTable("campaign_leads", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").notNull(),
  
  // Lead Information
  businessName: varchar("businessName", { length: 255 }).notNull(),
  businessEmail: varchar("businessEmail", { length: 255 }).notNull(),
  businessPhone: varchar("businessPhone", { length: 20 }),
  address: text("address"),
  city: varchar("city", { length: 100 }).notNull(),
  state: varchar("state", { length: 50 }).notNull(),
  
  // Lead Status
  status: mysqlEnum("status", ["discovered", "contacted", "interested", "converted", "rejected"]).default("discovered").notNull(),
  emailSentAt: timestamp("emailSentAt"),
  responseReceived: boolean("responseReceived").default(false).notNull(),
  responseDate: timestamp("responseDate"),
  
  // Google Places
  googlePlacesId: varchar("googlePlacesId", { length: 255 }),
  
  // Metadata
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CampaignLead = typeof campaignLeads.$inferSelect;
export type InsertCampaignLead = typeof campaignLeads.$inferInsert;
