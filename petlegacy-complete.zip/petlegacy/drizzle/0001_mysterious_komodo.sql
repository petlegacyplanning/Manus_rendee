CREATE TABLE `adoption_listings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orgId` int NOT NULL,
	`petName` varchar(100) NOT NULL,
	`species` varchar(50),
	`breed` varchar(100),
	`age` varchar(20),
	`gender` enum('male','female','unknown') DEFAULT 'unknown',
	`photoUrl` varchar(512),
	`description` text,
	`city` varchar(100),
	`state` varchar(50),
	`status` enum('available','pending','adopted') NOT NULL DEFAULT 'available',
	`featured` boolean NOT NULL DEFAULT false,
	`approved` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `adoption_listings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `affiliate_codes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`code` varchar(32) NOT NULL,
	`affiliateName` varchar(100),
	`discountPct` int NOT NULL DEFAULT 10,
	`commissionPct` int NOT NULL DEFAULT 10,
	`visits` int NOT NULL DEFAULT 0,
	`conversions` int NOT NULL DEFAULT 0,
	`totalRevenue` decimal(10,2) DEFAULT '0.00',
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `affiliate_codes_id` PRIMARY KEY(`id`),
	CONSTRAINT `affiliate_codes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `community_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`category` enum('pet_of_week','cutest_pet','hero_pet','breed_of_week','rescue_of_week','shelter_pet','pet_of_month') NOT NULL,
	`petName` varchar(100) NOT NULL,
	`ownerName` varchar(100),
	`species` varchar(50),
	`breed` varchar(100),
	`photoUrl` varchar(512),
	`story` text,
	`city` varchar(100),
	`state` varchar(50),
	`featured` boolean NOT NULL DEFAULT false,
	`approved` boolean NOT NULL DEFAULT false,
	`weekOf` varchar(20),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `community_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `library_articles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`hub` varchar(100) NOT NULL,
	`slug` varchar(200) NOT NULL,
	`title` varchar(255) NOT NULL,
	`excerpt` text,
	`content` text,
	`tags` json,
	`metaTitle` varchar(255),
	`metaDesc` text,
	`published` boolean NOT NULL DEFAULT true,
	`featured` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `library_articles_id` PRIMARY KEY(`id`),
	CONSTRAINT `library_articles_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `memorial_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`petName` varchar(100) NOT NULL,
	`species` varchar(50),
	`breed` varchar(100),
	`birthDate` varchar(20),
	`passDate` varchar(20),
	`photoUrl` varchar(512),
	`tribute` text,
	`submitterName` varchar(100),
	`approved` boolean NOT NULL DEFAULT false,
	`featured` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `memorial_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `newsletter_issues` (
	`id` int AUTO_INCREMENT NOT NULL,
	`issueNumber` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`publishDate` timestamp NOT NULL,
	`breedOfWeek` varchar(100),
	`funFacts` json,
	`triviaQuestions` json,
	`triviaAnswers` json,
	`healthcareSection` text,
	`trainingTip` text,
	`sponsoredContent` text,
	`memorialEntries` json,
	`crosswordData` json,
	`wordSearchData` json,
	`published` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `newsletter_issues_id` PRIMARY KEY(`id`),
	CONSTRAINT `newsletter_issues_issueNumber_unique` UNIQUE(`issueNumber`)
);
--> statement-breakpoint
CREATE TABLE `newsletter_subscribers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`name` varchar(100),
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `newsletter_subscribers_id` PRIMARY KEY(`id`),
	CONSTRAINT `newsletter_subscribers_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tier` enum('premium','ultimate','platinum') NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`promoCode` varchar(32),
	`affiliateCode` varchar(32),
	`discountApplied` decimal(10,2) DEFAULT '0.00',
	`status` enum('pending','complete','refunded') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `organizations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('rescue','shelter','other') NOT NULL DEFAULT 'rescue',
	`city` varchar(100),
	`state` varchar(50),
	`website` varchar(255),
	`description` text,
	`logoUrl` varchar(512),
	`approved` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `organizations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`species` varchar(50),
	`breed` varchar(100),
	`age` varchar(20),
	`color` varchar(100),
	`photoUrl` varchar(512),
	`microchipId` varchar(100),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `plan_sections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`sectionKey` varchar(50) NOT NULL,
	`data` json,
	`completed` boolean NOT NULL DEFAULT false,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `plan_sections_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `plan_workspaces` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tier` enum('free','premium','ultimate','platinum') NOT NULL DEFAULT 'free',
	`completionPct` int NOT NULL DEFAULT 0,
	`lastSaved` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `plan_workspaces_id` PRIMARY KEY(`id`),
	CONSTRAINT `plan_workspaces_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `platinum_clients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`assignedAdminId` int,
	`status` enum('intake','in_progress','review','complete') NOT NULL DEFAULT 'intake',
	`notes` text,
	`missingItems` json,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `platinum_clients_id` PRIMARY KEY(`id`),
	CONSTRAINT `platinum_clients_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `promo_codes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`discountPct` int NOT NULL,
	`maxUses` int,
	`uses` int NOT NULL DEFAULT 0,
	`expiresAt` timestamp,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `promo_codes_id` PRIMARY KEY(`id`),
	CONSTRAINT `promo_codes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `registered_pets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`petName` varchar(100) NOT NULL,
	`species` varchar(50),
	`breed` varchar(100),
	`photoUrl` varchar(512),
	`registrationNumber` varchar(32),
	`city` varchar(100),
	`state` varchar(50),
	`approved` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `registered_pets_id` PRIMARY KEY(`id`),
	CONSTRAINT `registered_pets_registrationNumber_unique` UNIQUE(`registrationNumber`)
);
--> statement-breakpoint
CREATE TABLE `rehoming_listings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`petName` varchar(100) NOT NULL,
	`species` varchar(50),
	`breed` varchar(100),
	`age` varchar(20),
	`gender` enum('male','female','unknown') DEFAULT 'unknown',
	`photoUrl` varchar(512),
	`description` text,
	`reason` text,
	`city` varchar(100),
	`state` varchar(50),
	`contactEmail` varchar(320),
	`status` enum('active','pending_review','rehomed','removed') NOT NULL DEFAULT 'pending_review',
	`approved` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `rehoming_listings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `planTier` enum('free','premium','ultimate','platinum') DEFAULT 'free' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `affiliateCode` varchar(32);