CREATE TABLE `pet_pins` (
	`id` int AUTO_INCREMENT NOT NULL,
	`petName` varchar(100) NOT NULL,
	`breed` varchar(100),
	`city` varchar(100) NOT NULL,
	`state` varchar(50) NOT NULL,
	`story` text,
	`lat` decimal(10,6) NOT NULL,
	`lng` decimal(10,6) NOT NULL,
	`approved` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pet_pins_id` PRIMARY KEY(`id`)
);
