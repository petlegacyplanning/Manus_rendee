CREATE TABLE `quiz_responses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`score` int NOT NULL,
	`answers` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quiz_responses_id` PRIMARY KEY(`id`)
);
