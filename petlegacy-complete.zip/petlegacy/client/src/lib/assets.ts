/**
 * Real CDN asset URLs for PetLegacyPlanning.com
 * All images are tied to the webdev project lifecycle.
 */

/** Combined logo + verified partner seal image (left = shield crest logo, right = circular verified partner seal) */
export const LOGO_AND_SEAL_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/logo-and-seal_8422082b.png";

/** Chase avatar photo — young man in pink shirt with camo hat.
 *  Use ONLY for: narrator widget, FAQ helper, plan explainer, sticky support.
 *  Do NOT use for memorial content. */
export const CHASE_AVATAR_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/chase-avatar_0e1d3426.jpg";

/** Jonathan Sawyer + Savannah (Rottweiler) photo with PetLegacyPlanning.com branding.
 *  Use for: founder story, about/mission, homepage trust, emotional credibility. */
export const JONATHAN_SAVANNAH_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/jonathan-savannah_1c8cf253.png";

/** Chase Brent Sawyer memorial photo — young boy in orange shirt.
 *  Use ONLY for: "In Memory of Chase Brent Sawyer" sections, memorial tribute.
 *  Dates: 04-09-04 to 08-21-16.
 *  Do NOT use as avatar. */
export const CHASE_MEMORIAL_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/chase-memorial_4b0f62a3.jpg";

/** Cinematic dark luxury hero background */
export const HERO_BG_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/hero-bg-cCMkCQme6U9msK27WPhSEb.webp";
