import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { ChaseFloatingChat } from "./components/ChaseFloatingChat";

// Layout
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import LuxuryBorder from "./components/LuxuryBorder";
import ScrollToTop from "./components/ScrollToTop";

// Public pages
import Home from "./pages/Home";
import HowItWorks from "./pages/HowItWorks";
import Plans from "./pages/Plans";
import FounderStory from "./pages/FounderStory";
import FAQ from "./pages/FAQ";
import Contact from "./pages/Contact";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import Disclaimer from "./pages/Disclaimer";

// Community
import Community from "./pages/Community";
import Memorials from "./pages/Memorials";
import RegisteredPets from "./pages/RegisteredPets";
import Adopt from "./pages/Adopt";
import Rehome from "./pages/Rehome";

// Newsletter & Library
import Newsletter from "./pages/Newsletter";
import Library from "./pages/Library";

// Workspace & Platinum
import MyPlan from "./pages/MyPlan";
import Platinum from "./pages/Platinum";

// SEO
import StatePage from "./pages/StatePage";

// Directory
import Directory from "./pages/Directory";
import DirectoryPartnerSignup from "./pages/DirectoryPartnerSignup";

// Payment
import Checkout from "./pages/Checkout";
import ThankYou from "./pages/ThankYou";

// Quiz
import Quiz from "./pages/Quiz";
import QuizResults from "./pages/QuizResults";

// Planner
import PlannerDashboard from "./pages/PlannerDashboard";
import PlannerWizard from "./pages/PlannerWizard";
import CompliancePlanner from "./pages/CompliancePlanner";

// Registry
import PetGuardianRegistry from "./pages/PetGuardianRegistry";

// Admin
import Admin from "./pages/Admin";

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <LuxuryBorder />
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

function Router() {
  return (
    <Layout>
      <ScrollToTop />
      <Switch>
        {/* Home */}
        <Route path="/" component={Home} />

        {/* About */}
        <Route path="/how-it-works" component={HowItWorks} />
        <Route path="/plans" component={Plans} />
        <Route path="/founder-story" component={FounderStory} />
        <Route path="/faq" component={FAQ} />
        <Route path="/contact" component={Contact} />

        {/* Community */}
        <Route path="/community" component={Community} />
        <Route path="/community/:category" component={Community} />
        <Route path="/community/memorials" component={Memorials} />
        <Route path="/memorials" component={Memorials} />
        <Route path="/community/registered-pets" component={RegisteredPets} />
        <Route path="/registered-pets" component={RegisteredPets} />
        <Route path="/adopt" component={Adopt} />
        <Route path="/rehome" component={Rehome} />

        {/* Newsletter */}
        <Route path="/newsletter" component={Newsletter} />

        {/* Library */}
        <Route path="/library" component={Library} />
        <Route path="/library/article/:slug" component={Library} />
        <Route path="/library/:hub" component={Library} />

        {/* Payment */}
        <Route path="/checkout/:plan" component={Checkout} />
        <Route path="/thank-you" component={ThankYou} />

        {/* Quiz */}
        <Route path="/quiz" component={Quiz} />
        <Route path="/quiz-results" component={QuizResults} />

        {/* Planner */}
        <Route path="/planner-dashboard" component={PlannerDashboard} />
        <Route path="/planner/:projectId" component={(props: any) => <PlannerWizard projectId={parseInt(props.projectId)} />} />
        <Route path="/compliance-planner" component={CompliancePlanner} />

        {/* Pet Guardian Registry */}
        <Route path="/pet-guardian-registry" component={PetGuardianRegistry} />

        {/* Workspace */}
        <Route path="/my-plan" component={MyPlan} />
        <Route path="/platinum" component={Platinum} />

        {/* National Directory */}
        <Route path="/directory" component={Directory} />
        <Route path="/directory/partner-signup" component={DirectoryPartnerSignup} />
        <Route path="/directory/:state" component={StatePage} />

        {/* SEO State Pages */}
        <Route path="/pet-protection/:state" component={StatePage} />

        {/* Legal */}
        <Route path="/privacy" component={Privacy} />
        <Route path="/terms" component={Terms} />
        <Route path="/disclaimer" component={Disclaimer} />

        {/* Admin */}
        <Route path="/admin" component={Admin} />

        {/* 404 */}
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
          <ChaseFloatingChat />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
