import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { CheckCircle, Newspaper, Mail, Loader2, ChevronRight } from "lucide-react";
import { PetCrossword, PetWordSearch } from "@/components/PetPuzzles";
import { toast } from "sonner";
import BackToHome from "@/components/BackToHome";


const sections = [
  "Breed of the Week spotlight",
  "5 Fun Facts about pets",
  "Trivia questions & answers",
  "Healthcare & wellness tips",
  "Training advice",
  "Community pet spotlights",
  "Memorial section",
  "Adoption & rescue features",
];

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [subscribing, setSubscribing] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState<any>(null);

  const { data: issues, isLoading } = trpc.newsletter.list.useQuery();

  const subscribeMutation = trpc.newsletter.subscribe.useMutation({
    onSuccess: () => {
      toast.success("You're subscribed! Welcome to Pet Legacy Weekly.");
      setEmail("");
      setName("");
      setSubscribing(false);
    },
    onError: () => {
      toast.error("Subscription failed. Please try again.");
      setSubscribing(false);
    },
  });

  const handleSubscribe = () => {
    if (!email.trim()) { toast.error("Please enter your email address."); return; }
    setSubscribing(true);
    subscribeMutation.mutate({ email, name: name || undefined });
  };

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Weekly Newsletter</Badge>
          <h1 className="font-serif text-5xl font-bold text-cream mb-4">Pet Legacy Weekly</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            The most comprehensive pet newsletter in America. Every week, beautifully organized and delivered free to your inbox.
          </p>
        </div>
      </section>

      {/* Subscribe + What's Inside */}
      <section className="section-padding">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-start max-w-5xl mx-auto">
            {/* Subscribe */}
            <div className="card-luxury rounded-2xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <Mail className="w-6 h-6 text-gold" />
                <h2 className="font-serif text-2xl font-bold text-cream">Subscribe Free</h2>
              </div>
              <p className="text-muted-foreground mb-6">
                Join thousands of pet families who receive Pet Legacy Weekly every week. No spam, ever. Unsubscribe anytime.
              </p>
              <div className="space-y-3">
                <Input
                  placeholder="Your name (optional)"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="bg-input border-border"
                />
                <Input
                  type="email"
                  placeholder="Your email address *"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSubscribe()}
                  className="bg-input border-border"
                />
                <Button
                  className="w-full bg-primary text-primary-foreground font-semibold"
                  onClick={handleSubscribe}
                  disabled={subscribing}
                >
                  {subscribing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Mail className="w-4 h-4 mr-2" />}
                  Subscribe to Pet Legacy Weekly
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-4 text-center">
                Free forever. No credit card required.
              </p>
            </div>

            {/* What's inside */}
            <div>
              <h2 className="font-serif text-2xl font-bold text-cream mb-6">What's Inside Every Issue</h2>
              <div className="space-y-3">
                {sections.map((s) => (
                  <div key={s} className="flex items-center gap-3 card-luxury rounded-xl p-3">
                    <CheckCircle className="w-4 h-4 text-gold flex-shrink-0" />
                    <span className="text-sm text-foreground/80">{s}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── CROSSWORD PUZZLE ─────────────────────────────────────────── */}
      <section className="section-padding">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <Badge className="badge-gold mb-4 px-4 py-1.5">Weekly Puzzle</Badge>
              <h2 className="font-serif text-3xl font-bold text-cream mb-3">Pet Crossword Puzzle</h2>
              <p className="text-muted-foreground">A new pet-themed crossword puzzle in every issue. Click a cell to start, then type your answer.</p>
            </div>
            <PetCrossword />
          </div>
        </div>
      </section>

      {/* ── WORD SEARCH ──────────────────────────────────────────────── */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <Badge className="badge-gold mb-4 px-4 py-1.5">Word Search</Badge>
              <h2 className="font-serif text-3xl font-bold text-cream mb-3">Pet Word Search</h2>
              <p className="text-muted-foreground">Find all the hidden pet-related words. Click the first letter, then click the last letter to mark a word.</p>
            </div>
            <PetWordSearch />
          </div>
        </div>
      </section>

      {/* Archive */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-serif text-3xl font-bold text-cream mb-8">Issue Archive</h2>
            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 text-gold animate-spin" />
              </div>
            ) : issues && issues.length > 0 ? (
              <div className="space-y-4">
                {issues.map((issue: any) => (
                  <div
                    key={issue.id}
                    className="card-luxury rounded-xl p-5 cursor-pointer hover:border-gold/40 transition-all"
                    onClick={() => setSelectedIssue(selectedIssue?.id === issue.id ? null : issue)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-lg bg-gold/10 border border-gold/20 flex items-center justify-center">
                          <span className="text-xs font-bold text-gold">#{issue.issueNumber}</span>
                        </div>
                        <div>
                          <h3 className="font-semibold text-cream">{issue.title}</h3>
                          <p className="text-xs text-muted-foreground">
                            {issue.publishedAt ? new Date(issue.publishedAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }) : ""}
                          </p>
                        </div>
                      </div>
                      <ChevronRight className={`w-4 h-4 text-gold transition-transform ${selectedIssue?.id === issue.id ? "rotate-90" : ""}`} />
                    </div>
                    {selectedIssue?.id === issue.id && issue.content && (
                      <div className="mt-4 pt-4 border-t border-border">
                        <div className="prose prose-invert prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: issue.content }} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 card-luxury rounded-2xl">
                <Newspaper className="w-12 h-12 text-gold/30 mx-auto mb-4" />
                <p className="text-muted-foreground mb-2">No issues published yet.</p>
                <p className="text-sm text-muted-foreground">Subscribe to be notified when the first issue drops!</p>
              </div>
            )}
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
