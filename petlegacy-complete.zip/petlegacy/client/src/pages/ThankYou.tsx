import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle, Mail, Download, ArrowRight } from "lucide-react";

export default function ThankYou() {
  const [, setLocation] = useLocation();
  const [sessionId, setSessionId] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setSessionId(params.get("session_id") || "");
  }, []);

  return (
    <div className="min-h-screen bg-dark-bg py-12">
      <div className="container max-w-2xl">
        {/* Success Message */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="bg-gold/20 p-6 rounded-full">
              <CheckCircle className="w-16 h-16 text-gold" />
            </div>
          </div>
          <h1 className="font-serif text-4xl font-bold text-cream mb-2">Thank You!</h1>
          <p className="text-xl text-muted-foreground mb-2">Your purchase is complete</p>
          <p className="text-muted-foreground">We're excited to help you protect your pet's future</p>
        </div>

        {/* Confirmation Card */}
        <Card className="p-8 border border-gold/20 bg-dark-surface mb-8">
          <div className="space-y-6">
            {/* Order Details */}
            <div className="pb-6 border-b border-gold/10">
              <h2 className="text-lg font-semibold text-cream mb-4">Order Confirmation</h2>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Order ID</span>
                  <span className="font-mono text-cream">{sessionId || "Processing..."}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status</span>
                  <span className="text-gold font-semibold">✓ Confirmed</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Date</span>
                  <span className="text-cream">{new Date().toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            {/* Next Steps */}
            <div>
              <h3 className="text-lg font-semibold text-cream mb-4">What's Next?</h3>
              <ul className="space-y-3">
                <li className="flex gap-3">
                  <Mail className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-cream">Check Your Email</p>
                    <p className="text-sm text-muted-foreground">We've sent a confirmation email with your receipt and access details</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <Download className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-cream">Download Your Resources</p>
                    <p className="text-sm text-muted-foreground">Access your planning guides, templates, and emergency care cards</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <ArrowRight className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-cream">Start Planning</p>
                    <p className="text-sm text-muted-foreground">Use our tools to set up your pet's protection plan</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            onClick={() => setLocation("/dashboard")}
            className="w-full h-12 bg-gradient-to-r from-gold to-amber-600 hover:from-gold hover:to-amber-700 text-dark-bg font-bold"
          >
            Go to Dashboard
          </Button>
          <Button
            onClick={() => setLocation("/library")}
            variant="outline"
            className="w-full h-12"
          >
            Explore Pet Legacy Library
          </Button>
          <Button
            onClick={() => setLocation("/")}
            variant="ghost"
            className="w-full"
          >
            Back to Home
          </Button>
        </div>

        {/* Support Info */}
        <div className="mt-12 p-6 bg-dark-surface rounded-lg border border-gold/10">
          <h4 className="font-semibold text-cream mb-2">Need Help?</h4>
          <p className="text-muted-foreground text-sm mb-4">
            If you have any questions about your purchase or need assistance getting started, our team is here to help.
          </p>
          <Button variant="outline" size="sm">
            Contact Support
          </Button>
        </div>
      </div>
    </div>
  );
}
