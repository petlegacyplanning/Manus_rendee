import { Badge } from "@/components/ui/badge";
import BackToHome from "@/components/BackToHome";


export default function Privacy() {
  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding">
        <div className="container max-w-3xl mx-auto">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Legal</Badge>
          <h1 className="font-serif text-4xl font-bold text-cream mb-4">Privacy Policy</h1>
          <p className="text-sm text-muted-foreground mb-8">Last updated: January 1, 2025</p>

          <div className="prose prose-invert max-w-none space-y-8">
            {[
              { title: "1. Information We Collect", body: "We collect information you provide directly to us, such as when you create an account, complete your pet protection plan, subscribe to our newsletter, or contact us for support. This may include your name, email address, and information about your pets. We also collect certain information automatically when you use our services, including log data, device information, and usage data." },
              { title: "2. How We Use Your Information", body: "We use the information we collect to provide, maintain, and improve our services; to process transactions; to send you technical notices and support messages; to respond to your comments and questions; to send you newsletters and marketing communications (with your consent); and to monitor and analyze trends and usage." },
              { title: "3. Information Sharing", body: "We do not sell, trade, or otherwise transfer your personal information to outside parties. We may share your information with trusted third parties who assist us in operating our website and conducting our business, so long as those parties agree to keep this information confidential. We may also release your information when we believe release is appropriate to comply with the law." },
              { title: "4. Data Security", body: "We implement a variety of security measures to maintain the safety of your personal information. All data is encrypted in transit using SSL/TLS. Sensitive information is encrypted at rest. We regularly review our security practices and update them as necessary." },
              { title: "5. Cookies", body: "We use cookies and similar tracking technologies to track activity on our service and hold certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent." },
              { title: "6. Your Rights", body: "You have the right to access, correct, or delete your personal information. You may also object to or restrict certain processing of your data. To exercise these rights, please contact us at privacy@petlegacyplanning.com." },
              { title: "7. Children's Privacy", body: "Our services are not directed to children under the age of 13. We do not knowingly collect personal information from children under 13." },
              { title: "8. Changes to This Policy", body: "We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the 'Last updated' date." },
              { title: "9. Contact Us", body: "If you have any questions about this Privacy Policy, please contact us at privacy@petlegacyplanning.com." },
            ].map(({ title, body }) => (
              <div key={title} className="card-luxury rounded-xl p-6">
                <h2 className="font-serif text-lg font-bold text-cream mb-3">{title}</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
