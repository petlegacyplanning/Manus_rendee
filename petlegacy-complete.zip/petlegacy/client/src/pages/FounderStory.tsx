import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, Shield, ArrowRight } from "lucide-react";
import BackToHome from "@/components/BackToHome";


const JONATHAN_SAVANNAH_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/jonathan-savannah_1c8cf253.png";
const CHASE_MEMORIAL_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/chase-memorial_4b0f62a3.jpg";

export default function FounderStory() {
  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Our Story</Badge>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-cream mb-6">
            Built to Serve the People
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            The story behind Pet Legacy Planning — and why we built something that truly matters.
          </p>
        </div>
      </section>

      {/* Memorial */}
      <section className="section-padding">
        <div className="container max-w-3xl mx-auto">
          <div className="card-luxury rounded-2xl p-10 text-center mb-12">
            {/* Chase memorial photo */}
            <div className="w-32 h-32 rounded-full overflow-hidden border-2 border-gold/40 mx-auto mb-6 shadow-lg" style={{ boxShadow: "0 0 24px oklch(0.78 0.12 75 / 0.25)" }}>
              <img src={CHASE_MEMORIAL_URL} alt="Chase Brent Sawyer" className="w-full h-full object-cover object-top" />
            </div>
            <p className="text-xs text-gold tracking-widest uppercase mb-4 font-semibold">In Loving Memory</p>
            <h2 className="font-serif text-3xl font-bold text-cream mb-3">Chase Brent Sawyer</h2>
            <p className="text-muted-foreground text-sm mb-6 tracking-wider">April 9, 2004 — August 21, 2016</p>
            <p className="text-muted-foreground leading-relaxed italic font-display text-lg max-w-xl mx-auto">
              "Some bonds transcend time. The love we carry for those we've lost is the very reason we build something that lasts."
            </p>
          </div>

          {/* Story */}
          <div className="space-y-8">
            <div className="card-luxury rounded-2xl p-8">
              <h2 className="font-serif text-2xl font-bold text-cream mb-4">Why We Built This</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Pet Legacy Planning was born from a simple but powerful belief: people work too hard and deserve real value. Pets are family. And family deserves real planning.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                We've seen what happens when there's no plan — the confusion, the grief, the pets left without direction. We've heard the stories of animals ending up in shelters not because their owners stopped loving them, but because no one knew what to do when something unexpected happened.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                We built Pet Legacy Planning so that never has to happen to your family. Because your pets deserve more than a handwritten note on the refrigerator.
              </p>
            </div>

            <div className="card-luxury rounded-2xl p-8">
              <h2 className="font-serif text-2xl font-bold text-cream mb-4">Our Mission</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Our mission is to raise the standard of care and preparation for every pet family in America. We believe that structured pet protection planning should be accessible, affordable, and genuinely useful — not a generic template you fill out once and forget.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                We've built the most complete, most compassionate, and most nationally authoritative pet protection platform in the United States. Our 50-state framework, our community features, our library, our newsletter — everything we build is designed to serve the people who love their animals most.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                We are proud supporters of shelters and rescue missions. We believe every pet deserves a loving home, and we actively support the organizations working to make that happen.
              </p>
            </div>

            <div className="card-luxury rounded-2xl p-8">
              <h2 className="font-serif text-2xl font-bold text-cream mb-4">The Founders</h2>
              <div className="flex flex-col md:flex-row gap-6 items-start">
                <div className="flex-shrink-0">
                  {/* Real photo: Jonathan & Savannah with their Rottweiler */}
                  <div className="w-40 h-48 rounded-2xl overflow-hidden border border-gold/30 shadow-lg">
                    <img src={JONATHAN_SAVANNAH_URL} alt="Jonathan and Savannah, Founders" className="w-full h-full object-cover object-top" />
                  </div>
                </div>
                <div>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    Jonathan and Savannah founded Pet Legacy Planning with a shared vision: to create a platform that genuinely serves pet families — not just sells them a product. Their combined experience in planning, technology, and animal welfare shaped every aspect of what Pet Legacy Planning has become.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    "We want every pet family in America to have access to the kind of protection planning that was previously only available to those who could afford expensive attorneys. We've democratized it. We've made it accessible. And we've made it genuinely good."
                  </p>
                  <p className="text-sm text-gold mt-3 font-medium">— Jonathan & Savannah, Founders</p>
                </div>
              </div>
            </div>

            <div className="card-luxury rounded-2xl p-8">
              <h2 className="font-serif text-2xl font-bold text-cream mb-4">Sister Brand: Life Legacy Planner</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Pet Legacy Planning is proudly connected to <a href="https://lifelegacyplanner.com" target="_blank" rel="noopener noreferrer" className="text-gold hover:text-gold-light">LifeLegacyPlanner.com</a> — our sister brand focused on human life legacy planning. Together, these platforms form a complete family protection ecosystem.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Because protecting what matters most means protecting your whole family — human and animal alike.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding bg-dark-surface">
        <div className="container text-center">
          <Shield className="w-12 h-12 text-gold mx-auto mb-6" />
          <h2 className="font-serif text-3xl font-bold text-cream mb-4">Join Our Mission</h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Every plan you create, every pet you protect, and every family you help is part of something bigger. Join us.
          </p>
          <Button size="lg" className="bg-primary text-primary-foreground font-bold px-10 py-6" asChild>
            <Link href="/plans">
              Start Your Plan <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </Button>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
