import React, { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { toast } from "sonner";

const PLANS = {
  premium: {
    name: "Premium Kit",
    price: 3495,
    description: "Comprehensive pet protection planning",
    features: ["Full care documentation", "Guardian designation forms", "Medical history templates", "Emergency planning guide", "Online workspace access"]
  },
  ultimate: {
    name: "Ultimate Kit",
    price: 6995,
    description: "Complete pet legacy planning with legal guidance",
    features: ["Everything in Premium", "Multi-pet coverage", "50-state legal framework", "Lifetime updates", "Priority support", "Community access"]
  },
  platinum: {
    name: "Platinum Done-For-You",
    price: 17995,
    description: "Full-service pet protection with dedicated advisor",
    features: ["Everything in Ultimate", "Done-for-you completion", "Dedicated advisor", "Custom documentation", "Final review & delivery", "Platinum client portal"]
  }
};

export default function Checkout() {
  const [, params] = useRoute("/checkout/:plan");
  const planId = (params?.plan as keyof typeof PLANS) || "premium";
  const plan = PLANS[planId];

  const [promoCode, setPromoCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const createCheckoutMutation = trpc.stripe.createCheckoutSession.useMutation();

  if (!plan) {
    return (
      <div className="min-h-screen bg-dark-bg flex items-center justify-center">
        <Card className="p-8 max-w-md">
          <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
          <h1 className="text-2xl font-bold text-cream mb-2">Invalid Plan</h1>
          <p className="text-muted-foreground mb-6">The plan you selected is not available.</p>
          <Button onClick={() => window.location.href = "/plans"} className="w-full">Back to Plans</Button>
        </Card>
      </div>
    );
  }

  const originalPrice = plan.price;
  const finalPrice = originalPrice - discount;

  const handleApplyPromo = () => {
    if (promoCode.toLowerCase() === "grand20") {
      const discountAmount = Math.round(originalPrice * 0.2);
      setDiscount(discountAmount);
      toast.success("Promo code applied! 20% off");
      setError("");
    } else if (promoCode.trim()) {
      setError("Invalid promo code");
      setDiscount(0);
    }
  };

  const handleCheckout = async () => {
    setLoading(true);
    try {
      const res = await createCheckoutMutation.mutateAsync({
        planId,
        promoCode: discount > 0 ? "grand20" : undefined
      });

      if (res.checkoutUrl) {
        toast.success("Redirecting to checkout...");
        window.open(res.checkoutUrl, "_blank");
      }
    } catch (err) {
      toast.error("Failed to create checkout session");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg py-12">
      <div className="container max-w-2xl">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="badge-gold mb-4">Grand Opening Special</Badge>
          <h1 className="font-serif text-4xl font-bold text-cream mb-2">Secure Your Pet's Future</h1>
          <p className="text-muted-foreground">Complete your purchase with our special launch pricing</p>
        </div>

        {/* Checkout Card */}
        <Card className="p-8 border border-gold/20 bg-dark-surface">
          {/* Plan Summary */}
          <div className="mb-8 pb-8 border-b border-gold/10">
            <h2 className="text-2xl font-bold text-cream mb-2">{plan.name}</h2>
            <p className="text-muted-foreground mb-4">{plan.description}</p>

            {/* Features */}
            <ul className="space-y-2 mb-6">
              {plan.features.map((feature) => (
                <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <CheckCircle className="w-4 h-4 text-gold" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>

          {/* Promo Code Section */}
          <div className="mb-8 pb-8 border-b border-gold/10">
            <label className="block text-sm font-semibold text-cream mb-3">Promo Code</label>
            <div className="flex gap-2">
              <Input
                placeholder="Enter promo code"
                value={promoCode}
                onChange={(e) => {
                  setPromoCode(e.target.value);
                  setError("");
                }}
                className="flex-1"
              />
              <Button
                variant="outline"
                onClick={handleApplyPromo}
                disabled={!promoCode.trim()}
              >
                Apply
              </Button>
            </div>
            {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
            {discount > 0 && (
              <p className="text-gold text-sm mt-2">✓ 20% discount applied!</p>
            )}
          </div>

          {/* Pricing */}
          <div className="mb-8 space-y-3">
            <div className="flex justify-between text-muted-foreground">
              <span>Subtotal</span>
              <span>${(originalPrice / 100).toFixed(2)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-gold">
                <span>Discount (20%)</span>
                <span>-${(discount / 100).toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-xl font-bold text-cream pt-3 border-t border-gold/10">
              <span>Total</span>
              <span>${(finalPrice / 100).toFixed(2)}</span>
            </div>
          </div>

          {/* Checkout Button */}
          <Button
            onClick={handleCheckout}
            disabled={loading}
            className="w-full h-12 bg-gradient-to-r from-gold to-amber-600 hover:from-gold hover:to-amber-700 text-dark-bg font-bold text-lg"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              "Proceed to Payment"
            )}
          </Button>

          {/* Security Info */}
          <p className="text-xs text-muted-foreground text-center mt-6">
            🔒 Secure payment powered by Stripe. Your information is encrypted and protected.
          </p>
        </Card>

        {/* Back to Plans */}
        <div className="text-center mt-8">
          <Button variant="ghost" onClick={() => window.location.href = "/plans"}>
            ← Back to Plans
          </Button>
        </div>
      </div>
    </div>
  );
}
