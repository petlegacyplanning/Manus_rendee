import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Shield, CheckCircle, Lock, Loader2, ChevronRight, Download, Save } from "lucide-react";
import { toast } from "sonner";
import BackToHome from "@/components/BackToHome";


const SECTIONS = [
  {
    key: "pet-profile",
    title: "Pet Profile",
    desc: "Basic information about your pet",
    fields: [
      { key: "petName", label: "Pet Name", type: "text", required: true },
      { key: "species", label: "Species", type: "text" },
      { key: "breed", label: "Breed", type: "text" },
      { key: "birthDate", label: "Date of Birth", type: "date" },
      { key: "color", label: "Color / Markings", type: "text" },
      { key: "microchipId", label: "Microchip ID", type: "text" },
    ],
  },
  {
    key: "medical-history",
    title: "Medical History",
    desc: "Veterinarian info and medical records",
    fields: [
      { key: "vetName", label: "Veterinarian Name", type: "text" },
      { key: "vetPhone", label: "Vet Phone", type: "tel" },
      { key: "vetAddress", label: "Vet Address", type: "text" },
      { key: "conditions", label: "Known Conditions / Diagnoses", type: "textarea" },
      { key: "allergies", label: "Allergies", type: "text" },
      { key: "vaccinations", label: "Vaccination Notes", type: "textarea" },
    ],
  },
  {
    key: "medications",
    title: "Medications",
    desc: "Current medications and dosage schedules",
    fields: [
      { key: "medications", label: "Medications (name, dose, frequency)", type: "textarea" },
      { key: "pharmacy", label: "Pharmacy Name & Phone", type: "text" },
      { key: "prescriptionNotes", label: "Prescription Notes", type: "textarea" },
    ],
  },
  {
    key: "feeding-routine",
    title: "Feeding Routine",
    desc: "Diet, feeding schedule, and food preferences",
    fields: [
      { key: "foodBrand", label: "Food Brand & Type", type: "text" },
      { key: "feedingSchedule", label: "Feeding Schedule", type: "text" },
      { key: "portionSize", label: "Portion Size", type: "text" },
      { key: "dietaryRestrictions", label: "Dietary Restrictions / Allergies", type: "textarea" },
      { key: "treats", label: "Favorite Treats", type: "text" },
    ],
  },
  {
    key: "behavioral-notes",
    title: "Behavioral Notes",
    desc: "Personality, quirks, and special needs",
    fields: [
      { key: "personality", label: "Personality Description", type: "textarea" },
      { key: "fears", label: "Fears / Triggers", type: "textarea" },
      { key: "favoriteActivities", label: "Favorite Activities", type: "textarea" },
      { key: "specialNeeds", label: "Special Needs or Accommodations", type: "textarea" },
    ],
  },
  {
    key: "guardian-designation",
    title: "Guardian Designation",
    desc: "Who will care for your pet if you cannot",
    fields: [
      { key: "primaryGuardianName", label: "Primary Guardian Name", type: "text", required: true },
      { key: "primaryGuardianPhone", label: "Primary Guardian Phone", type: "tel" },
      { key: "primaryGuardianEmail", label: "Primary Guardian Email", type: "email" },
      { key: "primaryGuardianRelationship", label: "Relationship to You", type: "text" },
      { key: "backupGuardianName", label: "Backup Guardian Name", type: "text" },
      { key: "backupGuardianPhone", label: "Backup Guardian Phone", type: "tel" },
      { key: "guardianInstructions", label: "Instructions for Guardians", type: "textarea" },
    ],
  },
  {
    key: "emergency-contacts",
    title: "Emergency Contacts",
    desc: "People to contact in an emergency",
    fields: [
      { key: "emergencyContact1Name", label: "Emergency Contact 1 Name", type: "text" },
      { key: "emergencyContact1Phone", label: "Emergency Contact 1 Phone", type: "tel" },
      { key: "emergencyContact2Name", label: "Emergency Contact 2 Name", type: "text" },
      { key: "emergencyContact2Phone", label: "Emergency Contact 2 Phone", type: "tel" },
      { key: "emergencyVetName", label: "Emergency Vet Name", type: "text" },
      { key: "emergencyVetPhone", label: "Emergency Vet Phone", type: "tel" },
    ],
  },
  {
    key: "end-of-life",
    title: "End-of-Life Wishes",
    desc: "Your wishes for your pet's care at end of life",
    fields: [
      { key: "endOfLifeWishes", label: "End-of-Life Care Wishes", type: "textarea" },
      { key: "burialPreferences", label: "Burial / Cremation Preferences", type: "textarea" },
      { key: "financialProvisions", label: "Financial Provisions for Care", type: "textarea" },
      { key: "additionalNotes", label: "Additional Notes", type: "textarea" },
    ],
  },
];

function SectionForm({ section, initialData, onSave, saving }: {
  section: typeof SECTIONS[0];
  initialData: Record<string, string>;
  onSave: (data: Record<string, string>) => void;
  saving: boolean;
}) {
  const [data, setData] = useState<Record<string, string>>(initialData);

  return (
    <div className="space-y-4">
      {section.fields.map((field) => (
        <div key={field.key}>
          <label className="text-xs text-muted-foreground mb-1 block">
            {field.label}
            {field.required && <span className="text-gold ml-1">*</span>}
          </label>
          {field.type === "textarea" ? (
            <Textarea
              value={data[field.key] ?? ""}
              onChange={(e) => setData({ ...data, [field.key]: e.target.value })}
              className="bg-input border-border"
              rows={3}
            />
          ) : (
            <Input
              type={field.type}
              value={data[field.key] ?? ""}
              onChange={(e) => setData({ ...data, [field.key]: e.target.value })}
              className="bg-input border-border"
            />
          )}
        </div>
      ))}
      <Button
        className="bg-primary text-primary-foreground w-full"
        onClick={() => onSave(data)}
        disabled={saving}
      >
        {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
        Save Section
      </Button>
    </div>
  );
}

export default function MyPlan() {
  const { isAuthenticated, user } = useAuth();
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [savingSection, setSavingSection] = useState<string | null>(null);

  const utils = trpc.useUtils();
  const { data: workspaceData, isLoading } = trpc.workspace.get.useQuery(undefined, { enabled: isAuthenticated });

  const saveSectionMutation = trpc.workspace.saveSection.useMutation({
    onSuccess: () => {
      toast.success("Section saved successfully.");
      setSavingSection(null);
      utils.workspace.get.invalidate();
    },
    onError: () => {
      toast.error("Failed to save. Please try again.");
      setSavingSection(null);
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background pt-24 flex items-center justify-center">
        <div className="text-center max-w-md">
          <Shield className="w-16 h-16 text-gold/40 mx-auto mb-6" />
          <h1 className="font-serif text-3xl font-bold text-cream mb-4">Your Pet Protection Workspace</h1>
          <p className="text-muted-foreground mb-8">Sign in to access your personal pet protection workspace and build your plan.</p>
          <Button size="lg" className="bg-primary text-primary-foreground" asChild>
            <a href={getLoginUrl()}>Sign In to Get Started</a>
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pt-24 flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-gold animate-spin" />
      </div>
    );
  }

  const workspace = workspaceData?.workspace;
  const sections = workspaceData?.sections ?? [];
  const completionPct = workspace?.completionPct ?? 0;
  const tier = workspace?.tier ?? "free";

  const getSectionData = (key: string): Record<string, string> => {
    const sec = sections.find((s: any) => s.sectionKey === key);
    return (sec?.data as Record<string, string>) ?? {};
  };

  const isSectionComplete = (key: string) => {
    return sections.some((s: any) => s.sectionKey === key && s.completed);
  };

  const isPremiumLocked = (sectionIdx: number) => {
    return tier === "free" && sectionIdx >= 2;
  };

  const handleSave = (sectionKey: string, data: Record<string, string>) => {
    setSavingSection(sectionKey);
    saveSectionMutation.mutate({ sectionKey, data });
  };

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container">
          <div className="flex flex-col md:flex-row items-start justify-between gap-6 mb-8">
            <div>
              <Badge className="badge-gold mb-3 px-4 py-1.5">My Workspace</Badge>
              <h1 className="font-serif text-4xl font-bold text-cream">My Pet Protection Plan</h1>
              <p className="text-muted-foreground mt-2">Welcome back, {user?.name?.split(" ")[0] ?? "friend"}.</p>
            </div>
            <div className="flex flex-col items-end gap-3">
              <div className="text-right">
                <p className="text-xs text-muted-foreground mb-1">Plan Completion</p>
                <p className="font-serif text-2xl font-bold text-gold">{completionPct}%</p>
              </div>
              <Progress value={completionPct} className="w-48 h-2" />
              <Badge className={`text-xs ${tier === "platinum" ? "bg-gold text-background" : tier === "ultimate" ? "bg-burgundy text-cream" : tier === "premium" ? "bg-dark-elevated text-gold border border-gold/40" : "bg-dark-elevated text-muted-foreground"}`}>
                {tier.charAt(0).toUpperCase() + tier.slice(1)} Plan
              </Badge>
            </div>
          </div>

          {tier === "free" && (
            <div className="card-luxury rounded-xl p-4 mb-8 border-gold/20 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-gold flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-cream">Unlock All 8 Sections</p>
                  <p className="text-xs text-muted-foreground">Upgrade to Premium to access all workspace sections.</p>
                </div>
              </div>
              <Button size="sm" className="bg-primary text-primary-foreground flex-shrink-0" asChild>
                <Link href="/plans">Upgrade Now</Link>
              </Button>
            </div>
          )}
        </div>
      </section>

      <section className="section-padding pt-4">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-6">
            {/* Section List */}
            <div className="md:col-span-1">
              <div className="space-y-2">
                {SECTIONS.map((section, idx) => {
                  const locked = isPremiumLocked(idx);
                  const complete = isSectionComplete(section.key);
                  const active = activeSection === section.key;

                  return (
                    <button
                      key={section.key}
                      onClick={() => !locked && setActiveSection(active ? null : section.key)}
                      className={`w-full text-left rounded-xl p-4 transition-all border ${
                        active
                          ? "border-gold/40 bg-gold/5"
                          : locked
                          ? "border-border bg-dark-surface opacity-50 cursor-not-allowed"
                          : "border-border hover:border-gold/30 cursor-pointer"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {complete ? (
                            <CheckCircle className="w-5 h-5 text-gold flex-shrink-0" />
                          ) : locked ? (
                            <Lock className="w-5 h-5 text-muted-foreground/50 flex-shrink-0" />
                          ) : (
                            <div className="w-5 h-5 rounded-full border-2 border-border flex-shrink-0" />
                          )}
                          <div>
                            <p className={`text-sm font-semibold ${active ? "text-gold" : "text-cream"}`}>{section.title}</p>
                            <p className="text-xs text-muted-foreground">{section.desc}</p>
                          </div>
                        </div>
                        <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${active ? "rotate-90" : ""}`} />
                      </div>
                    </button>
                  );
                })}
              </div>

              {completionPct === 100 && (
                <div className="mt-4 card-luxury rounded-xl p-4 text-center">
                  <CheckCircle className="w-8 h-8 text-gold mx-auto mb-2" />
                  <p className="text-sm font-semibold text-cream mb-1">Plan Complete!</p>
                  <Button size="sm" className="bg-primary text-primary-foreground w-full mt-2">
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                  </Button>
                </div>
              )}
            </div>

            {/* Section Form */}
            <div className="md:col-span-2">
              {activeSection ? (
                <div className="card-luxury rounded-2xl p-6">
                  {(() => {
                    const section = SECTIONS.find((s) => s.key === activeSection);
                    if (!section) return null;
                    return (
                      <>
                        <h2 className="font-serif text-xl font-bold text-cream mb-1">{section.title}</h2>
                        <p className="text-sm text-muted-foreground mb-6">{section.desc}</p>
                        <SectionForm
                          section={section}
                          initialData={getSectionData(section.key)}
                          onSave={(data) => handleSave(section.key, data)}
                          saving={savingSection === section.key}
                        />
                      </>
                    );
                  })()}
                </div>
              ) : (
                <div className="card-luxury rounded-2xl p-8 text-center">
                  <Shield className="w-16 h-16 text-gold/30 mx-auto mb-4" />
                  <h2 className="font-serif text-xl font-bold text-cream mb-2">Select a Section to Begin</h2>
                  <p className="text-muted-foreground text-sm">
                    Click any section on the left to start filling out your pet protection plan. Each section you complete brings you closer to full protection.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
