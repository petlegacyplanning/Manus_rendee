import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Plus, Search, Edit2, Trash2, AlertCircle, CheckCircle2 } from "lucide-react";
import BackToHome from "@/components/BackToHome";

interface RegistryRecord {
  id: number;
  petName: string;
  petSpecies: string;
  petBreed?: string;
  petAge?: number;
  petMicrochipId?: string;
  petMedicalNotes?: string;
  guardianName: string;
  guardianPhone: string;
  guardianEmail?: string;
  guardianAddress?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelationship?: string;
  state: string;
  city: string;
  registrationStatus: "active" | "inactive" | "pending";
  createdAt: Date;
  updatedAt: Date;
}

export default function PetGuardianRegistry() {
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState({
    petName: "",
    petSpecies: "",
    petBreed: "",
    petAge: "",
    petMicrochipId: "",
    petMedicalNotes: "",
    guardianName: "",
    guardianPhone: "",
    guardianEmail: "",
    guardianAddress: "",
    emergencyContactName: "",
    emergencyContactPhone: "",
    emergencyContactRelationship: "",
    state: "",
    city: "",
  });

  // Queries and mutations
  const { data: records = [], refetch: refetchRecords } = trpc.registry.list.useQuery(
    undefined,
    { enabled: !!user }
  );

  const createMutation = trpc.registry.create.useMutation({
    onSuccess: () => {
      refetchRecords();
      resetForm();
      setShowForm(false);
    },
  });

  const updateMutation = trpc.registry.update.useMutation({
    onSuccess: () => {
      refetchRecords();
      resetForm();
      setEditingId(null);
    },
  });

  const deleteMutation = trpc.registry.delete.useMutation({
    onSuccess: () => {
      refetchRecords();
    },
  });

  const searchQuery = trpc.registry.search.useQuery(
    { petName: searchTerm },
    { enabled: false }
  );

  // Check if user has access
  if (!user || user.planTier === "free") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="border-red-500/30 bg-red-500/5">
            <CardContent className="py-8 text-center">
              <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-cream mb-2">Access Restricted</h2>
              <p className="text-muted-foreground mb-6">
                The Pet Guardian Registry is available for Premium, Ultimate, and Platinum plan members.
              </p>
              <Button onClick={() => (window.location.href = "/plans")} className="bg-gold text-black hover:bg-gold/90">
                View Plans
              </Button>
            </CardContent>
          </Card>
        </div>
        <BackToHome />
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      ...formData,
      petAge: formData.petAge ? parseInt(formData.petAge) : undefined,
    };

    if (editingId) {
      await updateMutation.mutateAsync({ id: editingId, ...payload });
    } else {
      await createMutation.mutateAsync(payload);
    }
  };

  const handleSearch = async () => {
    if (searchTerm.trim()) {
      await searchQuery.refetch();
    }
  };

  const resetForm = () => {
    setFormData({
      petName: "",
      petSpecies: "",
      petBreed: "",
      petAge: "",
      petMicrochipId: "",
      petMedicalNotes: "",
      guardianName: "",
      guardianPhone: "",
      guardianEmail: "",
      guardianAddress: "",
      emergencyContactName: "",
      emergencyContactPhone: "",
      emergencyContactRelationship: "",
      state: "",
      city: "",
    });
    setEditingId(null);
  };

  const handleEdit = (record: RegistryRecord) => {
    setFormData({
      petName: record.petName,
      petSpecies: record.petSpecies,
      petBreed: record.petBreed || "",
      petAge: record.petAge?.toString() || "",
      petMicrochipId: record.petMicrochipId || "",
      petMedicalNotes: record.petMedicalNotes || "",
      guardianName: record.guardianName,
      guardianPhone: record.guardianPhone,
      guardianEmail: record.guardianEmail || "",
      guardianAddress: record.guardianAddress || "",
      emergencyContactName: record.emergencyContactName || "",
      emergencyContactPhone: record.emergencyContactPhone || "",
      emergencyContactRelationship: record.emergencyContactRelationship || "",
      state: record.state,
      city: record.city,
    });
    setEditingId(record.id);
    setShowForm(true);
  };

  const filteredRecords = searchTerm
    ? (searchQuery.data as RegistryRecord[]) || []
    : (records as RegistryRecord[]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Badge className="badge-gold mb-4">Premium Feature</Badge>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-cream mb-4">
            Pet Guardian Registry
          </h1>
          <p className="text-lg text-muted-foreground max-w-3xl">
            Register your pets and designate guardians. Keep all critical information in one secure location for emergency situations.
          </p>
        </div>

        {/* Search Bar */}
        <div className="flex gap-2 mb-8">
          <Input
            placeholder="Search by pet name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-background/50 border-border/50"
          />
          <Button onClick={handleSearch} className="bg-gold text-black hover:bg-gold/90">
            <Search className="w-4 h-4 mr-2" />
            Search
          </Button>
          <Button onClick={() => setShowForm(!showForm)} className="bg-gold text-black hover:bg-gold/90">
            <Plus className="w-4 h-4 mr-2" />
            Register Pet
          </Button>
        </div>

        {/* Registration Form */}
        {showForm && (
          <Card className="border-gold/40 bg-card/50 mb-8">
            <CardHeader>
              <CardTitle>{editingId ? "Edit Pet Registration" : "Register New Pet"}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Pet Information */}
                <div>
                  <h3 className="text-lg font-semibold text-cream mb-4">Pet Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Pet Name"
                      value={formData.petName}
                      onChange={(e) => setFormData({ ...formData, petName: e.target.value })}
                      required
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Species (Dog, Cat, Bird, etc.)"
                      value={formData.petSpecies}
                      onChange={(e) => setFormData({ ...formData, petSpecies: e.target.value })}
                      required
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Breed"
                      value={formData.petBreed}
                      onChange={(e) => setFormData({ ...formData, petBreed: e.target.value })}
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Age (years)"
                      type="number"
                      value={formData.petAge}
                      onChange={(e) => setFormData({ ...formData, petAge: e.target.value })}
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Microchip ID"
                      value={formData.petMicrochipId}
                      onChange={(e) => setFormData({ ...formData, petMicrochipId: e.target.value })}
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Medical Notes"
                      value={formData.petMedicalNotes}
                      onChange={(e) => setFormData({ ...formData, petMedicalNotes: e.target.value })}
                      className="bg-background/50 border-border/50"
                    />
                  </div>
                </div>

                {/* Guardian Information */}
                <div>
                  <h3 className="text-lg font-semibold text-cream mb-4">Guardian Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Guardian Name"
                      value={formData.guardianName}
                      onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
                      required
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Guardian Phone"
                      value={formData.guardianPhone}
                      onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                      required
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Guardian Email"
                      type="email"
                      value={formData.guardianEmail}
                      onChange={(e) => setFormData({ ...formData, guardianEmail: e.target.value })}
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Guardian Address"
                      value={formData.guardianAddress}
                      onChange={(e) => setFormData({ ...formData, guardianAddress: e.target.value })}
                      className="bg-background/50 border-border/50"
                    />
                  </div>
                </div>

                {/* Emergency Contact */}
                <div>
                  <h3 className="text-lg font-semibold text-cream mb-4">Emergency Contact</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Emergency Contact Name"
                      value={formData.emergencyContactName}
                      onChange={(e) => setFormData({ ...formData, emergencyContactName: e.target.value })}
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Emergency Contact Phone"
                      value={formData.emergencyContactPhone}
                      onChange={(e) => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="Relationship to Pet Owner"
                      value={formData.emergencyContactRelationship}
                      onChange={(e) => setFormData({ ...formData, emergencyContactRelationship: e.target.value })}
                      className="bg-background/50 border-border/50"
                    />
                  </div>
                </div>

                {/* Location */}
                <div>
                  <h3 className="text-lg font-semibold text-cream mb-4">Location</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      placeholder="State"
                      value={formData.state}
                      onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                      required
                      className="bg-background/50 border-border/50"
                    />
                    <Input
                      placeholder="City"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      required
                      className="bg-background/50 border-border/50"
                    />
                  </div>
                </div>

                {/* Buttons */}
                <div className="flex gap-4">
                  <Button type="submit" className="bg-gold text-black hover:bg-gold/90">
                    {editingId ? "Update Registration" : "Register Pet"}
                  </Button>
                  <Button
                    type="button"
                    onClick={() => {
                      resetForm();
                      setShowForm(false);
                    }}
                    className="bg-muted text-foreground hover:bg-muted/80"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Registry Records */}
        <div className="space-y-4">
          {filteredRecords.length === 0 ? (
            <Card className="border-border/50 bg-card/50">
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground mb-4">No pets registered yet.</p>
                <Button onClick={() => setShowForm(true)} className="bg-gold text-black hover:bg-gold/90">
                  Register Your First Pet
                </Button>
              </CardContent>
            </Card>
          ) : (
            filteredRecords.map((record: RegistryRecord) => (
              <Card key={record.id} className="border-border/50 bg-card/50">
                <CardContent className="py-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Pet Info */}
                    <div>
                      <h3 className="text-xl font-bold text-cream mb-2">{record.petName}</h3>
                      <div className="space-y-1 text-sm text-muted-foreground">
                        <p>
                          <span className="text-foreground font-semibold">Species:</span> {record.petSpecies}
                        </p>
                        {record.petBreed && (
                          <p>
                            <span className="text-foreground font-semibold">Breed:</span> {record.petBreed}
                          </p>
                        )}
                        {record.petAge && (
                          <p>
                            <span className="text-foreground font-semibold">Age:</span> {record.petAge} years
                          </p>
                        )}
                        {record.petMicrochipId && (
                          <p>
                            <span className="text-foreground font-semibold">Microchip:</span> {record.petMicrochipId}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Guardian Info */}
                    <div>
                      <h4 className="font-semibold text-cream mb-2">Guardian</h4>
                      <div className="space-y-1 text-sm text-muted-foreground">
                        <p>{record.guardianName}</p>
                        <p>{record.guardianPhone}</p>
                        {record.guardianEmail && <p>{record.guardianEmail}</p>}
                        {record.guardianAddress && <p>{record.guardianAddress}</p>}
                        <p className="text-xs">
                          {record.city}, {record.state}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 mt-6 pt-6 border-t border-border/50">
                    <Button
                      size="sm"
                      onClick={() => handleEdit(record)}
                      className="bg-gold/20 text-gold hover:bg-gold/30"
                    >
                      <Edit2 className="w-4 h-4 mr-2" />
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => deleteMutation.mutateAsync({ id: record.id })}
                      className="bg-red-500/20 text-red-500 hover:bg-red-500/30"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      <BackToHome />
    </div>
  );
}
