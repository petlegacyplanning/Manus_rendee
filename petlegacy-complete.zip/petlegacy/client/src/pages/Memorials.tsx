import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Heart, Plus, Loader2, MapPin } from "lucide-react";
import { toast } from "sonner";
import BackToHome from "@/components/BackToHome";


const CHASE_MEMORIAL_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/chase-memorial_4b0f62a3.jpg";

export default function Memorials() {
  const [submitOpen, setSubmitOpen] = useState(false);
  const [form, setForm] = useState({ petName: "", species: "", breed: "", birthDate: "", passDate: "", tribute: "", submitterName: "" });

  const { data: memorials, isLoading, refetch } = trpc.memorials.list.useQuery();

  const submitMutation = trpc.memorials.submit.useMutation({
    onSuccess: () => {
      toast.success("Memorial submitted. We'll review it and publish it shortly.");
      setSubmitOpen(false);
      setForm({ petName: "", species: "", breed: "", birthDate: "", passDate: "", tribute: "", submitterName: "" });
    },
    onError: () => toast.error("Submission failed. Please try again."),
  });

  const handleSubmit = () => {
    if (!form.petName.trim()) { toast.error("Pet name is required."); return; }
    submitMutation.mutate(form);
  };

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">In Loving Memory</Badge>
          <h1 className="font-serif text-5xl font-bold text-cream mb-4">Pet Memorials</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
            A sacred space to honor the pets who have crossed the rainbow bridge. Their love lives on in our hearts forever.
          </p>

          {/* In Memory of Chase */}
          <div className="max-w-xl mx-auto card-luxury rounded-2xl p-8 mb-8 border-gold/20">
            <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-gold/40 mx-auto mb-4" style={{ boxShadow: "0 0 20px oklch(0.78 0.12 75 / 0.22)" }}>
              <img src={CHASE_MEMORIAL_URL} alt="Chase Brent Sawyer" className="w-full h-full object-cover object-top" />
            </div>
            <p className="text-xs text-gold tracking-widest uppercase mb-2 font-semibold">In Loving Memory</p>
            <h2 className="font-serif text-2xl font-bold text-cream mb-1">Chase Brent Sawyer</h2>
            <p className="text-muted-foreground text-sm mb-4 tracking-wider">April 9, 2004 — August 21, 2016</p>
            <p className="text-muted-foreground leading-relaxed italic">
              "Some bonds transcend time. The love we carry for those we've lost is the very reason we build something that lasts."
            </p>
          </div>

          <Dialog open={submitOpen} onOpenChange={setSubmitOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary text-primary-foreground">
                <Plus className="w-4 h-4 mr-2" />
                Submit a Memorial
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border max-w-lg">
              <DialogHeader>
                <DialogTitle className="font-serif text-xl text-cream">Submit a Memorial</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Pet Name *</label>
                    <Input value={form.petName} onChange={(e) => setForm({ ...form, petName: e.target.value })} className="bg-input border-border" placeholder="Buddy" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Your Name</label>
                    <Input value={form.submitterName} onChange={(e) => setForm({ ...form, submitterName: e.target.value })} className="bg-input border-border" placeholder="Jane Smith" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Species</label>
                    <Input value={form.species} onChange={(e) => setForm({ ...form, species: e.target.value })} className="bg-input border-border" placeholder="Dog" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Breed</label>
                    <Input value={form.breed} onChange={(e) => setForm({ ...form, breed: e.target.value })} className="bg-input border-border" placeholder="Golden Retriever" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Birth Date</label>
                    <Input type="date" value={form.birthDate} onChange={(e) => setForm({ ...form, birthDate: e.target.value })} className="bg-input border-border" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Passing Date</label>
                    <Input type="date" value={form.passDate} onChange={(e) => setForm({ ...form, passDate: e.target.value })} className="bg-input border-border" />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Tribute</label>
                  <Textarea value={form.tribute} onChange={(e) => setForm({ ...form, tribute: e.target.value })} className="bg-input border-border" placeholder="Share a memory, a tribute, or a few words about your beloved pet..." rows={5} />
                </div>
                <Button className="w-full bg-primary text-primary-foreground" onClick={handleSubmit} disabled={submitMutation.isPending}>
                  {submitMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Submit Memorial
                </Button>
                <p className="text-xs text-muted-foreground text-center">All memorials are reviewed before publishing.</p>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 text-gold animate-spin" />
            </div>
          ) : memorials && memorials.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {memorials.map((m: any) => (
                <div key={m.id} className="card-luxury rounded-2xl p-6 text-center">
                  <div className="w-14 h-14 rounded-full bg-dark-elevated border border-gold/20 flex items-center justify-center mx-auto mb-4">
                    <Heart className="w-6 h-6 text-gold/50" />
                  </div>
                  <h3 className="font-serif text-xl font-bold text-cream mb-1">{m.petName}</h3>
                  {m.breed && <p className="text-xs text-gold mb-1">{m.breed}</p>}
                  {(m.birthDate || m.passDate) && (
                    <p className="text-xs text-muted-foreground mb-3">
                      {m.birthDate && new Date(m.birthDate).getFullYear()}
                      {m.birthDate && m.passDate && " — "}
                      {m.passDate && new Date(m.passDate).getFullYear()}
                    </p>
                  )}
                  {m.tribute && <p className="text-sm text-muted-foreground leading-relaxed italic mb-3 line-clamp-4">"{m.tribute}"</p>}
                  {m.submitterName && <p className="text-xs text-muted-foreground">— {m.submitterName}</p>}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <Heart className="w-12 h-12 text-gold/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No memorials yet. Be the first to honor a beloved pet.</p>
            </div>
          )}
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
