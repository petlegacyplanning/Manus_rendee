import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Star, Heart, Award, Users, Home, Newspaper, MapPin, Plus, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useRoute } from "wouter";
import BackToHome from "@/components/BackToHome";


const categories = [
  { id: "pet-of-the-week", label: "Pet of the Week", icon: Star, desc: "Celebrate a beloved pet from our community each week." },
  { id: "cutest-pet", label: "Cutest Pet", icon: Heart, desc: "Show off the most adorable members of our community." },
  { id: "hero-pet", label: "Hero Pet", icon: Award, desc: "Honor pets who have shown extraordinary courage or love." },
  { id: "breed-of-the-week", label: "Breed of the Week", icon: Users, desc: "Spotlight a specific breed and learn what makes them special." },
  { id: "rescue-of-the-week", label: "Rescue of the Week", icon: Home, desc: "Celebrate rescue organizations doing incredible work." },
  { id: "pet-of-the-month", label: "Pet of the Month", icon: Newspaper, desc: "Our monthly feature — the most celebrated pet of the month." },
];

function CommunityCategory({ categoryId }: { categoryId: string }) {
  const cat = categories.find((c) => c.id === categoryId) ?? categories[0];
  const [submitOpen, setSubmitOpen] = useState(false);
  const [form, setForm] = useState({ petName: "", ownerName: "", species: "", breed: "", story: "", city: "", state: "" });

  const { data: entries, isLoading } = trpc.community.byCategory.useQuery({ category: categoryId });

  const submitMutation = trpc.community.submit.useMutation({
    onSuccess: () => {
      toast.success("Submission received! We'll review it shortly.");
      setSubmitOpen(false);
      setForm({ petName: "", ownerName: "", species: "", breed: "", story: "", city: "", state: "" });
    },
    onError: () => toast.error("Submission failed. Please try again."),
  });

  const handleSubmit = () => {
    if (!form.petName.trim()) { toast.error("Pet name is required."); return; }
    submitMutation.mutate({ ...form, category: categoryId });
  };

  const Icon = cat.icon;

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <Icon className="w-7 h-7 text-gold" />
          <div>
            <h2 className="font-serif text-2xl font-bold text-cream">{cat.label}</h2>
            <p className="text-sm text-muted-foreground">{cat.desc}</p>
          </div>
        </div>
        <Dialog open={submitOpen} onOpenChange={setSubmitOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-primary-foreground">
              <Plus className="w-4 h-4 mr-2" />
              Submit a Pet
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border max-w-lg">
            <DialogHeader>
              <DialogTitle className="font-serif text-xl text-cream">Submit to {cat.label}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Pet Name *</label>
                  <Input value={form.petName} onChange={(e) => setForm({ ...form, petName: e.target.value })} className="bg-input border-border" placeholder="Buddy" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Your Name</label>
                  <Input value={form.ownerName} onChange={(e) => setForm({ ...form, ownerName: e.target.value })} className="bg-input border-border" placeholder="Jane Smith" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Species</label>
                  <Input value={form.species} onChange={(e) => setForm({ ...form, species: e.target.value })} className="bg-input border-border" placeholder="Dog" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Breed</label>
                  <Input value={form.breed} onChange={(e) => setForm({ ...form, breed: e.target.value })} className="bg-input border-border" placeholder="Golden Retriever" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">City</label>
                  <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="bg-input border-border" placeholder="Austin" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">State</label>
                  <Input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} className="bg-input border-border" placeholder="TX" maxLength={2} />
                </div>
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Story</label>
                <Textarea value={form.story} onChange={(e) => setForm({ ...form, story: e.target.value })} className="bg-input border-border" placeholder="Tell us about this special pet..." rows={4} />
              </div>
              <Button className="w-full bg-primary text-primary-foreground" onClick={handleSubmit} disabled={submitMutation.isPending}>
                {submitMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Submit for Review
              </Button>
              <p className="text-xs text-muted-foreground text-center">All submissions are reviewed before publishing.</p>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 text-gold animate-spin" />
        </div>
      ) : entries && entries.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {entries.map((entry: any) => (
            <div key={entry.id} className="card-luxury rounded-2xl p-6">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-serif text-lg font-bold text-cream">{entry.petName}</h3>
                  {entry.breed && <p className="text-xs text-gold">{entry.breed}</p>}
                </div>
                {entry.featured && <Badge className="badge-gold text-xs">Featured</Badge>}
              </div>
              {entry.story && <p className="text-sm text-muted-foreground leading-relaxed mb-3 line-clamp-3">{entry.story}</p>}
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                {entry.ownerName && <span>By {entry.ownerName}</span>}
                {entry.city && entry.state && (
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {entry.city}, {entry.state}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 card-luxury rounded-2xl">
          <Icon className="w-12 h-12 text-gold/30 mx-auto mb-4" />
          <p className="text-muted-foreground mb-2">No entries yet for {cat.label}.</p>
          <p className="text-sm text-muted-foreground">Be the first to submit your pet!</p>
        </div>
      )}
    </div>
  );
}

export default function Community() {
  const [, params] = useRoute("/community/:category");
  const activeCategory = params?.category ?? "pet-of-the-week";

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Community</Badge>
          <h1 className="font-serif text-5xl font-bold text-cream mb-4">Our Pet Community</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Celebrate, connect, and support one another. Weekly spotlights, memorials, registered pets, and more.
          </p>
        </div>
      </section>

      {/* Category Nav */}
      <section className="py-8 bg-dark-surface border-b border-border">
        <div className="container">
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((cat) => (
              <Link key={cat.id} href={`/community/${cat.id}`}>
                <Button
                  variant={activeCategory === cat.id ? "default" : "outline"}
                  size="sm"
                  className={activeCategory === cat.id
                    ? "bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:text-gold hover:border-gold/40"
                  }
                >
                  <cat.icon className="w-3.5 h-3.5 mr-1.5" />
                  {cat.label}
                </Button>
              </Link>
            ))}
            <Link href="/community/memorials">
              <Button variant="outline" size="sm" className="border-border text-muted-foreground hover:text-gold hover:border-gold/40">
                <Heart className="w-3.5 h-3.5 mr-1.5" />
                Memorials
              </Button>
            </Link>
            <Link href="/community/registered-pets">
              <Button variant="outline" size="sm" className="border-border text-muted-foreground hover:text-gold hover:border-gold/40">
                <Star className="w-3.5 h-3.5 mr-1.5" />
                Registered Pets
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="section-padding">
        <div className="container">
          <CommunityCategory categoryId={activeCategory} />
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
