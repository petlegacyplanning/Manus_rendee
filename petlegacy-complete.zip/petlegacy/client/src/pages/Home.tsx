import { useState, useRef, useEffect, useCallback } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

import PetLegacyMap from "@/components/PetLegacyMap";

import {
  Shield, Star, CheckCircle, ArrowRight, Heart, BookOpen, Users, Home as HomeIcon,
  Award, Newspaper, ChevronRight, Mail, Phone, MapPin, AlertCircle, Leaf
} from "lucide-react";
import { toast } from "sonner";

// ── Real CDN image assets ──────────────────────────────────────────────────
const LOGO_AND_SEAL_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/logo-and-seal_8422082b.png";
const JONATHAN_SAVANNAH_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/jonathan-savannah_1c8cf253.png";
const CHASE_MEMORIAL_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/chase-memorial_4b0f62a3.jpg";
const CHASE_AVATAR_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/chase-avatar_0e1d3426.jpg";
const HERO_BG_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/hero-bg-cCMkCQme6U9msK27WPhSEb.webp";

// ── Hero rotation spec ───────────────────────────────────────────────────────────────────────────
// Main headline rotates through all 8 authority phrases (per provided spec)
const HERO_HEADLINES = [
  "America's #1 Structured Pet Protection Planning System",
  "The Nation's Most Complete Pet Protection Planning System",
  "50-State Structured Planning for the Pets You Love",
  "Premium Pet Protection, Emergency Readiness, and Peace of Mind",
  "A More Complete Pet Planning System Than Ordinary Templates",
  "Built for Families Who Want Real Pet Protection",
  "Nationwide Pet Protection, Guidance, and Community Support",
  "Planning for Your Pet's Future Starts Here",
];

// Sub-phrase row (Trusted for:) keeps its own rotation
const ROTATING_PHRASES = [
  "50-State Structured Pet Protection",
  "Emergency Planning for the Pets You Love",
  "More Complete Than Ordinary Templates",
  "Built for Families Who Want Real Protection",
  "Planning, Protection, Guidance, and Peace of Mind",
  "Proud Supporter of Shelters and Rescue Missions",
  "Helping Pet Owners Prepare with Confidence",
  "Community, Care, and Nationwide Pet Protection",
];

const trustBadges = [
  { icon: Shield, label: "50-State Framework" },
  { icon: Award, label: "Premium Quality" },
  { icon: Heart, label: "Rescue Supporter" },
  { icon: CheckCircle, label: "Trusted by Families" },
  { icon: Star, label: "Nationally Recognized" },
];

const packages = [
  {
    name: "Free Basic Checklist",
    price: "Free",
    tier: "free",
    description: "Start your pet protection journey with our essential checklist.",
    features: ["Basic care checklist", "Emergency contact template", "Downloadable PDF", "Email support"],
    cta: "Download Free",
    href: "/plans",
    highlight: false,
  },
  {
    name: "Premium Kit",
    price: "$47",
    tier: "premium",
    description: "A comprehensive kit that goes far beyond what competitors offer.",
    features: ["Full care documentation", "Guardian designation forms", "Medical history templates", "Emergency planning guide", "Printable workbook", "Online workspace"],
    cta: "Get Premium",
    href: "/plans/premium",
    highlight: false,
  },
  {
    name: "Ultimate Kit",
    price: "$97",
    tier: "ultimate",
    description: "The complete pet protection system — nothing left out.",
    features: ["Everything in Premium", "Multi-pet coverage", "Legal planning language", "50-state framework", "Lifetime updates", "Priority support", "Community access"],
    cta: "Get Ultimate",
    href: "/plans/ultimate",
    highlight: true,
  },
  {
    name: "Platinum Done-For-You",
    price: "$179.95",
    tier: "platinum",
    description: "We complete your entire plan for you — live human help included.",
    features: ["Everything in Ultimate", "Done-for-you completion", "Dedicated advisor", "Custom documentation", "Final review & delivery", "Platinum client portal"],
    cta: "Get Platinum",
    href: "/plans/platinum",
    highlight: false,
  },
];

const howItWorks = [
  { step: "1", title: "Choose Your Plan", desc: "Select the level of protection that fits your family and your pets." },
  { step: "2", title: "Complete Your Workspace", desc: "Fill out your pet's details, guardian information, and care instructions online." },
  { step: "3", title: "Save, Download & Share", desc: "Your plan is saved securely and downloadable anytime. Share with guardians." },
  { step: "4", title: "Update Anytime", desc: "Life changes. Your plan can too. Update your workspace whenever needed." },
];

const communityFeatures = [
  { icon: Star, label: "Pet of the Week", href: "/community/pet-of-the-week" },
  { icon: Heart, label: "Memorials", href: "/community/memorials" },
  { icon: Award, label: "Hero Pet", href: "/community/hero-pet" },
  { icon: Users, label: "Registered Pets", href: "/community/registered-pets" },
  { icon: HomeIcon, label: "Rescue of the Week", href: "/community/rescue-of-the-week" },
  { icon: Newspaper, label: "Pet of the Month", href: "/community/pet-of-the-month" },
];

const libraryHubs = [
  { label: "Dogs", href: "/library/dogs", icon: "🐕" },
  { label: "Cats", href: "/library/cats", icon: "🐈" },
  { label: "Senior Pets", href: "/library/senior-pets", icon: "🐾" },
  { label: "Pet Grief", href: "/library/pet-grief", icon: "💙" },
  { label: "Training", href: "/library/training", icon: "🎓" },
  { label: "Emergency Planning", href: "/library/emergency-planning", icon: "🚨" },
  { label: "Guardianship", href: "/library/guardianship", icon: "📋" },
  { label: "Health", href: "/library/health", icon: "🏥" },
];

const testimonials = [
  { name: "Sarah M.", location: "Austin, TX", text: "I never thought about what would happen to my dogs if something happened to me. Pet Legacy Planning gave me real peace of mind. The Ultimate Kit was worth every penny.", stars: 5 },
  { name: "David R.", location: "Chicago, IL", text: "The Platinum service was incredible. They walked me through everything and built a complete plan for all three of my cats. I feel so much better knowing they're protected.", stars: 5 },
  { name: "Jennifer L.", location: "Atlanta, GA", text: "As a rescue volunteer, I recommend this to every adopter. The free checklist alone is more comprehensive than anything else out there.", stars: 5 },
];

export default function Home() {
  const [phraseIdx, setPhraseIdx] = useState(0);
  const [phraseFade, setPhraseFade] = useState(true);
  const [headlineIdx, setHeadlineIdx] = useState(0);
  const [headlineChanging, setHeadlineChanging] = useState(false);
  const [email, setEmail] = useState("");
  const [subscribing, setSubscribing] = useState(false);


  const subscribeMutation = trpc.newsletter.subscribe.useMutation({
    onSuccess: () => {
      toast.success("You're subscribed! Welcome to Pet Legacy Weekly.");
      setEmail("");
      setSubscribing(false);
    },
    onError: () => {
      toast.error("Something went wrong. Please try again.");
      setSubscribing(false);
    },
  });

  // Rotation: 4000ms display, 750ms fade+blur+translateY transition (per provided spec)
  useEffect(() => {
    const interval = setInterval(() => {
      // Fade out headline
      setHeadlineChanging(true);
      setPhraseFade(false);
      setTimeout(() => {
        setHeadlineIdx((i) => (i + 1) % HERO_HEADLINES.length);
        setPhraseIdx((i) => (i + 1) % ROTATING_PHRASES.length);
        setHeadlineChanging(false);
        setPhraseFade(true);
      }, 750);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleSubscribe = () => {
    if (!email.trim()) return;
    setSubscribing(true);
    subscribeMutation.mutate({ email });
  };

  // Scroll reveal
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* ── 1. HERO ─────────────────────────────────────────────────────────── */}
      <section
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `url(${HERO_BG_URL})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Dark luxury overlay */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(160deg, rgba(10,8,6,0.82) 0%, rgba(30,10,10,0.75) 50%, rgba(10,8,6,0.88) 100%)" }} />

        <div className="relative container text-center pt-32 pb-20">
          {/* Hero authority block — no frame/border */}
          <div className="inline-block w-full max-w-4xl mx-auto px-8 py-10">

            {/* Kicker */}
            <p style={{
              color: "rgba(245,231,192,0.9)",
              fontSize: "0.95rem",
              textTransform: "uppercase",
              letterSpacing: "0.16em",
              marginBottom: "14px",
              fontWeight: 600,
            }}>
              50-State Structured Planning • Emergency Readiness • Community Resources
            </p>

            {/* Rotating main headline — 8 authority phrases (per provided spec) */}
            <h1
              id="heroMainTitle"
              className={`hero-main-headline font-serif font-bold${headlineChanging ? " is-changing" : ""}`}
            >
              {HERO_HEADLINES[headlineIdx]}
            </h1>

            {/* Rotating support phrase — "Trusted for:" label + gold phrase */}
            <div
              aria-live="polite"
              style={{
                display: "flex",
                flexWrap: "wrap",
                alignItems: "center",
                justifyContent: "center",
                gap: "10px",
                minHeight: "42px",
                margin: "12px 0 18px",
              }}
            >
              <span style={{ color: "rgba(245,231,192,0.78)", fontWeight: 600, fontSize: "0.98rem" }}>
                Trusted for:
              </span>
              <span
                style={{
                  color: "#d9b24d",
                  fontSize: "clamp(1.05rem, 2.2vw, 1.45rem)",
                  fontWeight: 700,
                  opacity: phraseFade ? 1 : 0,
                  transform: phraseFade ? "translateY(0)" : "translateY(8px)",
                  filter: phraseFade ? "drop-shadow(0 0 10px rgba(217,178,77,0.10))" : "blur(1px)",
                  transition: "opacity 0.7s ease, transform 0.7s ease, filter 0.7s ease",
                  display: "inline-block",
                }}
              >
                {ROTATING_PHRASES[phraseIdx]}
              </span>
            </div>

            {/* Subtext */}
            <p style={{
              color: "rgba(250,247,238,0.92)",
              fontSize: "clamp(1rem, 1.7vw, 1.18rem)",
              lineHeight: 1.7,
              maxWidth: "860px",
              margin: "0 auto 28px",
            }}>
              Protect your pet with a more complete system than ordinary templates — including planning tools,
              emergency resources, memorial support, grief resources, rescue support, and nationwide guidance.
            </p>

            {/* CTA buttons — per spec */}
            <div style={{ display: "flex", flexWrap: "wrap", gap: "14px", justifyContent: "center", marginTop: "10px" }}>
              <Link
                href="/plans"
                style={{
                  display: "inline-flex", alignItems: "center", justifyContent: "center",
                  minHeight: "48px", padding: "12px 24px", borderRadius: "999px",
                  textDecoration: "none", fontWeight: 700,
                  background: "linear-gradient(180deg, #d4af37, #b88a18)",
                  color: "#111",
                  boxShadow: "0 12px 26px rgba(0,0,0,0.28)",
                  transition: "transform 0.25s ease, box-shadow 0.25s ease",
                }}
              >
                Get Free Checklist
              </Link>
              <Link
                href="/plans"
                style={{
                  display: "inline-flex", alignItems: "center", justifyContent: "center",
                  minHeight: "48px", padding: "12px 24px", borderRadius: "999px",
                  textDecoration: "none", fontWeight: 700,
                  background: "rgba(255,255,255,0.06)",
                  color: "#f7f1df",
                  border: "1px solid rgba(245,231,192,0.18)",
                  backdropFilter: "blur(5px)",
                  transition: "transform 0.25s ease",
                }}
              >
                Compare Plans
              </Link>
              <Link
                href="/my-plan"
                style={{
                  display: "inline-flex", alignItems: "center", justifyContent: "center",
                  minHeight: "48px", padding: "12px 24px", borderRadius: "999px",
                  textDecoration: "none", fontWeight: 700,
                  background: "rgba(255,255,255,0.06)",
                  color: "#f7f1df",
                  border: "1px solid rgba(245,231,192,0.18)",
                  backdropFilter: "blur(5px)",
                  transition: "transform 0.25s ease",
                }}
              >
                Start My Plan
              </Link>
              <Link
                href="/directory"
                style={{
                  display: "inline-flex", alignItems: "center", justifyContent: "center",
                  minHeight: "48px", padding: "12px 24px", borderRadius: "999px",
                  textDecoration: "none", fontWeight: 700,
                  background: "rgba(255,255,255,0.06)",
                  color: "#f7f1df",
                  border: "1px solid rgba(245,231,192,0.18)",
                  backdropFilter: "blur(5px)",
                  transition: "transform 0.25s ease",
                }}
              >
                Explore National Directory
              </Link>
            </div>

            {/* Headline progress dots */}
            <div style={{ display: "flex", justifyContent: "center", gap: "8px", marginTop: "28px" }}>
              {HERO_HEADLINES.map((_, i) => (
                <button
                  key={i}
                  onClick={() => { setHeadlineIdx(i); setPhraseIdx(i % ROTATING_PHRASES.length); setHeadlineChanging(false); setPhraseFade(true); }}
                  aria-label={`Headline ${i + 1}`}
                  style={{
                    borderRadius: "999px",
                    border: "none",
                    cursor: "pointer",
                    transition: "all 0.3s ease",
                    width: i === headlineIdx ? "1.5rem" : "0.5rem",
                    height: "0.5rem",
                    background: i === headlineIdx ? "#d9b24d" : "rgba(217,178,77,0.25)",
                    padding: 0,
                  }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
      </section>

      {/* ── 2. TRUST STRIP ──────────────────────────────────────────────────── */}
      <section className="bg-dark-surface border-y border-border py-6">
        <div className="container">
          <div className="flex flex-wrap justify-center gap-8">
            {trustBadges.map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-2 text-sm text-muted-foreground">
                <Icon className="w-4 h-4 text-gold" />
                <span>{label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 3. WHAT IS PET LEGACY PLANNING ──────────────────────────────────── */}
      <section id="section-what" className="section-padding">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center reveal">
            <Badge className="badge-gold mb-6 px-4 py-1.5">What We Do</Badge>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-cream mb-6">
              What is Pet Legacy Planning?
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              Pet Legacy Planning is the structured process of documenting your pet's care needs, designating trusted guardians, and creating a complete protection system — so your pets are always cared for, no matter what life brings.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              We've built the most complete, most compassionate, and most nationally authoritative pet protection platform in the United States. Because your pets deserve more than a handwritten note on the refrigerator.
            </p>
          </div>
        </div>
      </section>

      {/* ── 4. WHY IT MATTERS ───────────────────────────────────────────────── */}
      <section id="section-why" className="section-padding bg-dark-surface">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="reveal">
              <Badge className="badge-gold mb-6 px-4 py-1.5">Why It Matters</Badge>
              <h2 className="font-serif text-4xl font-bold text-cream mb-6">
                Your Pets Can't Speak for Themselves
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Every year, thousands of beloved pets end up in shelters — not because their owners stopped loving them, but because no plan existed. A hospitalization, an accident, or a sudden loss can leave pets without direction, without care, and without the people who love them.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-8">
                A complete pet protection plan changes everything. It names guardians, documents care routines, preserves medical histories, and gives the people you trust everything they need to step in seamlessly.
              </p>
              <Button className="bg-primary text-primary-foreground" asChild>
                <Link href="/how-it-works">
                  Learn How It Works <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4 reveal">
              {[
                { stat: "67%", label: "of US households own a pet" },
                { stat: "6.5M", label: "pets enter shelters each year" },
                { stat: "1 in 3", label: "pet owners have no plan" },
                { stat: "100%", label: "of pets deserve protection" },
              ].map(({ stat, label }) => (
                <div key={label} className="card-luxury rounded-xl p-6 text-center">
                  <div className="font-serif text-3xl font-bold text-gold mb-2">{stat}</div>
                  <div className="text-xs text-muted-foreground">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── 4b. WHY CHOOSE US — COMPARISON TABLE ────────────────────────────── */}
      <section id="section-compare" className="plp-compare-section">
        <div className="plp-compare-overlay" />
        <div className="plp-compare-container">
          <div className="plp-compare-header">
            <span className="plp-eyebrow">WHY CHOOSE US</span>
            <h2>Why Families Choose Pet Legacy Planning</h2>
            <p>
              A more complete, pet-centered protection system designed with structure,
              clarity, and real-life guidance.
            </p>
          </div>

          <div className="plp-compare-card">
            <div className="plp-compare-table-wrap">
              <table className="plp-compare-table">
                <thead>
                  <tr>
                    <th>What Matters Most</th>
                    <th className="highlight-col">Pet Legacy Planning</th>
                    <th>Top 15 Competition</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { feature: "Pet-Specific Protection", us: "gold-check", them: "soft-partial" },
                    { feature: "Structured Planning Experience", us: "gold-check", them: "soft-partial" },
                    { feature: "Emergency Readiness", us: "gold-check", them: "soft-partial" },
                    { feature: "Guardian & Caregiver Clarity", us: "gold-check", them: "gold-check-alt" },
                    { feature: "Routine & Lifestyle Instructions", us: "gold-check", them: "soft-partial" },
                    { feature: "Financial Protection Options", us: "gold-check", them: "gold-check-alt" },
                    { feature: "End-of-Life Guidance", us: "gold-check", them: "soft-partial" },
                    { feature: "Resource Library", us: "gold-check", them: "soft-partial" },
                    { feature: "Community Mission", us: "gold-check", them: "soft-none" },
                    { feature: "Premium Experience", us: "gold-check", them: "soft-partial" },
                    { feature: "Overall Pet-Focused Value", us: "gold-check", them: "soft-partial" },
                  ].map(({ feature, us, them }) => (
                    <tr key={feature}>
                      <td>{feature}</td>
                      <td className="highlight-col">
                        <span className={`badge ${us}`}>
                          {us === "gold-check" ? "✓" : us === "gold-check-alt" ? "✓" : us === "soft-partial" ? "◐" : "—"}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${them}`}>
                          {them === "gold-check" ? "✓" : them === "gold-check-alt" ? "✓" : them === "soft-partial" ? "◐" : "—"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* ── 5. PACKAGE COMPARISON ───────────────────────────────────────────── */}
      <section className="section-padding" id="plans">
        <div className="container">
          <div className="text-center mb-12 reveal">
            <Badge className="badge-gold mb-6 px-4 py-1.5">Protection Plans</Badge>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-cream mb-4">
              Choose Your Level of Protection
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              From a free checklist to a fully done-for-you platinum service — we have the right plan for every pet family.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {packages.map((pkg) => (
              <div
                key={pkg.name}
                className={`relative rounded-2xl p-6 flex flex-col reveal ${
                  pkg.highlight
                    ? "bg-gradient-to-b from-burgundy to-burgundy-dark border-2 border-gold/40 glow-gold"
                    : "card-luxury"
                }`}
              >
                {pkg.highlight && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="badge-gold px-3 py-1 rounded-full text-xs">Most Popular</span>
                  </div>
                )}
                <div className="mb-4">
                  <h3 className="font-serif text-lg font-bold text-cream mb-1">{pkg.name}</h3>
                  <div className="font-serif text-3xl font-bold text-gold mb-2">{pkg.price}</div>
                  <p className="text-xs text-muted-foreground">{pkg.description}</p>
                </div>
                <ul className="space-y-2 flex-1 mb-6">
                  {pkg.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm text-foreground/80">
                      <CheckCircle className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Button
                  className={`w-full ${pkg.highlight ? "bg-gold text-background hover:opacity-90" : "bg-primary text-primary-foreground"}`}
                  asChild
                >
                  <Link href={pkg.href}>{pkg.cta}</Link>
                </Button>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link href="/plans">
              <span className="text-gold hover:text-gold-light text-sm cursor-pointer inline-flex items-center gap-1">
                Compare all plans in detail <ChevronRight className="w-4 h-4" />
              </span>
            </Link>
          </div>
        </div>
      </section>

      {/* ── 6. HOW IT WORKS ─────────────────────────────────────────────────── */}
      <section id="section-how" className="section-padding bg-dark-surface">
        <div className="container">
          <div className="text-center mb-12 reveal">
            <Badge className="badge-gold mb-6 px-4 py-1.5">Simple Process</Badge>
            <h2 className="font-serif text-4xl font-bold text-cream mb-4">How It Works</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">Four simple steps to complete protection for your pets.</p>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {howItWorks.map((step, i) => (
              <div key={step.step} className="text-center reveal">
                <div className="w-14 h-14 rounded-full border-2 border-gold/40 bg-gold/10 flex items-center justify-center mx-auto mb-4">
                  <span className="font-serif text-xl font-bold text-gold">{step.step}</span>
                </div>
                {i < howItWorks.length - 1 && (
                  <div className="hidden md:block absolute top-7 left-full w-full h-px bg-gold/20" />
                )}
                <h3 className="font-serif text-lg font-semibold text-cream mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 7. COMMUNITY ────────────────────────────────────────────────────── */}
      <section id="section-community" className="section-padding bg-dark-surface">
        <div className="container">
          <div className="text-center mb-12 reveal">
            <Badge className="badge-gold mb-6 px-4 py-1.5">Community</Badge>
            <h2 className="font-serif text-4xl font-bold text-cream mb-4">A Community Built for Pet Families</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Celebrate, connect, and support one another. Our community features weekly spotlights, memorials, registered pets, and more.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {communityFeatures.map(({ icon: Icon, label, href }) => (
              <Link key={href} href={href}>
                <div className="card-luxury rounded-xl p-5 text-center hover:border-gold/40 transition-all cursor-pointer reveal group">
                  <Icon className="w-8 h-8 text-gold mx-auto mb-3 group-hover:scale-110 transition-transform" />
                  <p className="text-xs text-foreground/80 font-medium">{label}</p>
                </div>
              </Link>
            ))}
          </div>
          <div className="text-center mt-8">
            <Button variant="outline" className="border-gold/40 text-gold hover:bg-gold/10" asChild>
              <Link href="/community">Explore Community</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ── 9. ADOPTION + RESCUE MISSION ────────────────────────────────────── */}
      <section id="section-rescue" className="section-padding">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="reveal">
              <Badge className="badge-gold mb-6 px-4 py-1.5">Rescue Mission</Badge>
              <h2 className="font-serif text-4xl font-bold text-cream mb-6">
                Proud Supporter of Shelters and Rescue Missions
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6">
                We believe every pet deserves a loving home and a complete protection plan. That's why we actively support rescue organizations, shelters, and the families who open their hearts to animals in need.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-8">
                Browse adoptable pets from approved rescue organizations, or find a new home for a pet you can no longer care for through our safe, moderated rehoming system.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button className="bg-primary text-primary-foreground" asChild>
                  <Link href="/adopt">Find a Pet to Adopt</Link>
                </Button>
                <Button variant="outline" className="border-gold/40 text-gold hover:bg-gold/10" asChild>
                  <Link href="/rescues">Browse Rescues & Shelters</Link>
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 reveal">
              {[
                { icon: Heart, title: "Adoption Hub", desc: "Pets from approved rescue organizations", href: "/adopt" },
                { icon: HomeIcon, title: "Rehoming Support", desc: "Safe, moderated rehoming for pets", href: "/rehome" },
                { icon: Users, title: "Rescue Directory", desc: "Find rescues and shelters near you", href: "/rescues" },
                { icon: Shield, title: "Shelter Support", desc: "Resources for shelter organizations", href: "/shelters" },
              ].map(({ icon: Icon, title, desc, href }) => (
                <Link key={href} href={href}>
                  <div className="card-luxury rounded-xl p-5 hover:border-gold/40 transition-all cursor-pointer">
                    <Icon className="w-7 h-7 text-gold mb-3" />
                    <h4 className="font-semibold text-sm text-cream mb-1">{title}</h4>
                    <p className="text-xs text-muted-foreground">{desc}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── 10. REHOMING ────────────────────────────────────────────────────── */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center reveal">
            <Badge className="badge-gold mb-6 px-4 py-1.5">Rehoming Support</Badge>
            <h2 className="font-serif text-3xl font-bold text-cream mb-4">
              Need to Rehome a Pet? We're Here to Help.
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              Life circumstances change. Our safe, moderated rehoming system helps connect pets with loving new families — with safety notices, contact protection, and admin oversight at every step.
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-8">
              <AlertCircle className="w-4 h-4 text-gold" />
              <span>All listings are reviewed before publishing. Your pet's safety is our priority.</span>
            </div>
            <Button className="bg-primary text-primary-foreground" asChild>
              <Link href="/rehome">Submit a Rehoming Listing</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ── 11. LIBRARY PREVIEW ─────────────────────────────────────────────── */}
      <section className="section-padding">
        <div className="container">
          <div className="text-center mb-12 reveal">
            <Badge className="badge-gold mb-6 px-4 py-1.5">Pet Library</Badge>
            <h2 className="font-serif text-4xl font-bold text-cream mb-4">
              The Most Complete Pet Resource Library
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Thousands of articles, guides, and resources covering every aspect of pet ownership — from training and health to grief support and emergency planning.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {libraryHubs.map(({ label, href, icon }) => (
              <Link key={href} href={href}>
                <div className="card-luxury rounded-xl p-5 text-center hover:border-gold/40 transition-all cursor-pointer reveal group">
                  <div className="text-3xl mb-3">{icon}</div>
                  <p className="text-sm font-medium text-foreground/80 group-hover:text-gold transition-colors">{label}</p>
                </div>
              </Link>
            ))}
          </div>
          <div className="text-center">
            <Button variant="outline" className="border-gold/40 text-gold hover:bg-gold/10" asChild>
              <Link href="/library">
                <BookOpen className="w-4 h-4 mr-2" />
                Browse the Full Library
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ── 12. NEWSLETTER PREVIEW ──────────────────────────────────────────── */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="reveal">
              <Badge className="badge-gold mb-6 px-4 py-1.5">Weekly Newsletter</Badge>
              <h2 className="font-serif text-4xl font-bold text-cream mb-6">
                Pet Legacy Weekly
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Every week, our newsletter delivers breed spotlights, fun facts, trivia, healthcare tips, training advice, memorials, and more — all in one beautifully organized issue.
              </p>
              <ul className="space-y-2 mb-8">
                {["Breed of the Week", "5 Fun Facts", "Trivia Questions", "Healthcare Section", "Training Tip", "Memorial Section"].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-gold flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <Button className="bg-primary text-primary-foreground" asChild>
                <Link href="/newsletter">Read Latest Issue</Link>
              </Button>
            </div>
            <div className="reveal">
              <div className="card-luxury rounded-2xl p-8">
                <h3 className="font-serif text-xl font-bold text-gold mb-4">Subscribe to Pet Legacy Weekly</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Join thousands of pet families who receive our free weekly newsletter. No spam, ever.
                </p>
                <div className="flex gap-2">
                  <Input
                    type="email"
                    placeholder="Your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSubscribe()}
                    className="bg-input border-border"
                  />
                  <Button
                    onClick={handleSubscribe}
                    disabled={subscribing}
                    className="bg-primary text-primary-foreground flex-shrink-0"
                  >
                    <Mail className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── 13. FOUNDER STORY ───────────────────────────────────────────────── */}
      <section id="section-founder" className="section-padding">
        <div className="container">
          <div className="max-w-4xl mx-auto reveal">
            <div className="text-center mb-10">
              <Badge className="badge-gold mb-6 px-4 py-1.5">Our Story</Badge>
              <h2 className="font-serif text-4xl font-bold text-cream mb-4">Built to Serve the People</h2>
            </div>
            <div className="card-luxury rounded-2xl p-8 md:p-12">
              <div className="flex flex-col md:flex-row gap-8 items-center">
                <div className="flex-shrink-0">
                  <img
                    src={JONATHAN_SAVANNAH_URL}
                    alt="Jonathan with Savannah"
                    className="w-48 h-48 rounded-2xl object-cover border-2 border-gold/30"
                    style={{ objectPosition: "top" }}
                  />
                </div>
                <div>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    "We built Pet Legacy Planning because we believe people work too hard and deserve real value. Pets are family. Real planning prevents heartbreak and confusion — and it's our mission to raise the standard of care and preparation for every pet family in America."
                  </p>
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    Our platform was built with compassion at its core. We've seen what happens when there's no plan — the confusion, the grief, the pets left without direction. We built this so that never has to happen to your family.
                  </p>
                  <Button variant="outline" className="border-gold/40 text-gold hover:bg-gold/10" asChild>
                    <Link href="/founder-story">Read the Full Story</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── 14. IN MEMORY OF CHASE BRENT SAWYER ─────────────────────────────── */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center reveal">
            <div className="divider-gold mb-10" />
            <div className="mb-8">
              <img
                src={CHASE_MEMORIAL_URL}
                alt="In Memory of Chase Brent Sawyer"
                className="w-64 h-64 rounded-2xl object-cover border-2 border-gold/40 mx-auto"
                style={{ boxShadow: "0 0 32px rgba(212,175,55,0.18)" }}
              />
            </div>
            <p className="text-xs text-gold tracking-widest uppercase mb-4 font-semibold">In Loving Memory</p>
            <h2 className="font-serif text-3xl font-bold text-cream mb-3">Chase Brent Sawyer</h2>
            <p className="text-muted-foreground text-sm mb-6 tracking-wider">April 9, 2004 — August 21, 2016</p>
            <p className="text-muted-foreground leading-relaxed italic font-display text-lg">
              "Some bonds transcend time. The love we carry for those we've lost is the very reason we build something that lasts."
            </p>
            <div className="divider-gold mt-10" />
          </div>
        </div>
      </section>

      {/* ── 15. TESTIMONIALS ────────────────────────────────────────────────── */}
      <section id="section-testimonials" className="section-padding">
        <div className="container">
          <div className="text-center mb-12 reveal">
            <Badge className="badge-gold mb-6 px-4 py-1.5">Testimonials</Badge>
            <h2 className="font-serif text-4xl font-bold text-cream mb-4">What Pet Families Are Saying</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <div key={i} className="card-luxury rounded-2xl p-6 reveal">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.stars }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 text-gold fill-gold" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4 italic">"{t.text}"</p>
                <div>
                  <p className="text-sm font-semibold text-cream">{t.name}</p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> {t.location}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>      {/* ── 15b. PUZZLE PREVIEW ─────────────────────────────────────────────── */}
      <section className="section-padding">
        <div className="container">
          <div className="text-center mb-10 reveal">
            <Badge className="badge-gold mb-4 px-4 py-1.5">Pet Puzzles</Badge>
            <h2 className="font-serif text-3xl font-bold text-cream mb-3">Fun Pet Puzzles — Free Every Week</h2>
            <p className="text-muted-foreground max-w-xl mx-auto text-sm">
              Each issue of Pet Legacy Weekly includes an interactive pet crossword and breed word search. Play a sample below.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {/* Crossword preview card */}
            <div className="card-luxury rounded-2xl p-6 reveal">
              <div className="flex items-center gap-3 mb-4">
                <span className="text-2xl">📏</span>
                <div>
                  <h3 className="font-serif text-lg font-bold text-gold">Pet Crossword Puzzle</h3>
                  <p className="text-xs text-muted-foreground">10×10 interactive grid — pet-themed clues</p>
                </div>
              </div>
              {/* Mini crossword preview grid (5×5 sample) */}
              <div className="inline-grid gap-0.5 bg-border/40 p-0.5 rounded mb-4" style={{ gridTemplateColumns: "repeat(5, 28px)" }}>
                {["P","A","W"," ","C","E"," ","A"," ","A","T","R","I","C","K"," "," ","L"," "," "," ","B"," ","F","E"].map((cell, i) => (
                  <div key={i} className={`w-7 h-7 flex items-center justify-center text-xs font-bold rounded-sm ${
                    cell === " " ? "bg-foreground/80" : "bg-card border border-border/60 text-cream"
                  }`}>
                    {cell !== " " ? cell : null}
                  </div>
                ))}
              </div>
              <div>
                <Link href="/newsletter">
                  <Button size="sm" className="bg-primary text-primary-foreground w-full">
                    Play Full Crossword
                  </Button>
                </Link>
              </div>
            </div>
            {/* Word search preview card */}
            <div className="card-luxury rounded-2xl p-6 reveal">
              <div className="flex items-center gap-3 mb-4">
                <span className="text-2xl">🔍</span>
                <div>
                  <h3 className="font-serif text-lg font-bold text-gold">Breed Word Search</h3>
                  <p className="text-xs text-muted-foreground">12×12 grid — find 10 hidden pet words</p>
                </div>
              </div>
              {/* Mini word search preview grid (5×5 sample) */}
              <div className="inline-grid gap-0.5 p-0.5 rounded mb-4" style={{ gridTemplateColumns: "repeat(5, 28px)" }}>
                {["G","U","A","R","D","P","A","W","S","F","U","X","K","I","T","P","L","E","G","A","P","E","A","X","B"].map((cell, i) => (
                  <div key={i} className="w-7 h-7 flex items-center justify-center text-xs font-bold rounded-sm bg-card border border-border/60 text-foreground/70 hover:text-gold hover:bg-gold/10 cursor-default">
                    {cell}
                  </div>
                ))}
              </div>
              <div className="mb-3">
                <p className="text-xs text-muted-foreground">Find: <span className="text-gold font-semibold">PAWS · FETCH · LEASH · COLLAR · KENNEL · PUPPY · KITTEN · RESCUE · GUARDIAN · LEGACY</span></p>
              </div>
              <Link href="/newsletter">
                <Button size="sm" className="bg-primary text-primary-foreground w-full">
                  Play Full Word Search
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── 15c. NATIONAL DIRECTORY ──────────────────────────────────────────── */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="text-center mb-10 reveal">
            <Badge className="badge-gold mb-4 px-4 py-1.5">National Directory</Badge>
            <h2 className="font-serif text-4xl font-bold text-cream mb-4">Find Pet Services in Your State</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our nationwide directory connects pet families with verified veterinarians, groomers, trainers, emergency clinics, rescue organizations, and pet-friendly attorneys — in all 50 states.
            </p>
          </div>
          {/* Service category grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 reveal">
            {[
              { icon: "🏥", label: "Veterinarians" },
              { icon: "⚖️", label: "Pet Attorneys" },
              { icon: "🛡️", label: "Rescue & Shelters" },
              { icon: "🐾", label: "Groomers" },
              { icon: "🏫", label: "Trainers" },
              { icon: "🚨", label: "Emergency Clinics" },
              { icon: "🏠", label: "Pet-Friendly Housing" },
              { icon: "💻", label: "Telehealth Vets" },
            ].map(({ icon, label }) => (
              <Link key={label} href="/directory">
                <div className="card-luxury rounded-xl p-4 text-center hover:border-gold/40 transition-all cursor-pointer">
                  <div className="text-2xl mb-2">{icon}</div>
                  <p className="text-xs font-semibold text-foreground/80">{label}</p>
                </div>
              </Link>
            ))}
          </div>
          {/* State quick-links */}
          <div className="card-luxury rounded-2xl p-6 reveal">
            <h3 className="font-serif text-lg font-bold text-gold mb-4 text-center">Browse by State</h3>
            <div className="flex flex-wrap gap-2 justify-center">
              {["Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware","Florida","Georgia",
                "Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland",
                "Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada",
                "New Hampshire","New Jersey","New Mexico","New York","North Carolina","North Dakota","Ohio",
                "Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota","Tennessee",
                "Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming"
              ].map((state) => (
                <Link key={state} href={`/directory?state=${encodeURIComponent(state)}`}>
                  <span className="inline-block px-3 py-1 text-xs rounded-full border border-gold/20 text-muted-foreground hover:border-gold/50 hover:text-gold transition-all cursor-pointer">
                    {state}
                  </span>
                </Link>
              ))}
            </div>
          </div>
          <div className="text-center mt-6">
            <Button className="bg-primary text-primary-foreground" asChild>
              <Link href="/directory">
                <MapPin className="w-4 h-4 mr-2" />
                Open Full National Directory
              </Link>
            </Button>
          </div>
        </div>
      </section>

        {/* ── 15d. HOW YOU WIN — VALUE SECTION ────────────────────────────── */}
      <section id="section-value" className="plp-value-section">
        <div className="plp-value-container">
          <div className="plp-value-header">
            <span className="plp-eyebrow">YOUR ADVANTAGE</span>
            <h2>How You Win with Pet Legacy Planning</h2>
            <p>
              Lawyers often charge <span className="plp-highlight">hundreds of dollars per hour</span>.
              Our structured planning system costs less than what many law firms charge for a single hour
              and helps you organize far more information before you ever need to pay professional hourly fees.
            </p>
          </div>

          <div className="plp-value-grid">
            {[
              { title: "Save Money", body: "Many legal professionals charge hundreds per hour. Our structured system can cost less than a single billable hour." },
              { title: "Organize Everything", body: "Store your pet's caregivers, medical information, feeding routines, medications, behavior notes, and emergency instructions." },
              { title: "Reduce Confusion", body: "Your family, caregivers, or emergency responders can easily understand your pet's needs without guessing." },
              { title: "Plan Ahead", body: "Document guardians, funding plans, emergency care instructions, and future protection for your pets." },
            ].map(({ title, body }) => (
              <div key={title} className="plp-value-card">
                <h3>{title}</h3>
                <p>{body}</p>
              </div>
            ))}
          </div>

          <div className="plp-membership-card">
            <h2>Optional Plan Protection Membership — $9.95/month</h2>
            <p>
              Keep your plan stored safely in our system and access it whenever you need.
              Members receive updated templates, new planning tools, and platform improvements as our system evolves.
            </p>
            <ul>
              <li>Secure storage of your pet protection plan</li>
              <li>Easy updates anytime</li>
              <li>New tools and improvements added regularly</li>
              <li>Convenient access when life changes</li>
            </ul>
          </div>

          <div className="plp-bonus-card">
            <h2>Free Emergency Responder Kit</h2>
            <p>
              When you purchase the <span className="plp-highlight">Ultimate Kit</span> or{" "}
              <span className="plp-highlight">Platinum Kit</span>, you receive our Emergency Responder Kit at no extra cost.
            </p>
            <ul>
              <li>Emergency door hanger template</li>
              <li>5×5 emergency window notice</li>
              <li>Wallet emergency contact card</li>
              <li>Designed to alert first responders that pets are inside</li>
            </ul>
          </div>
        </div>
      </section>

      {/* ── 15e. PET LEGACY MAP ───────────────────────────────────────────────────── */}
      <section id="section-map" className="plp-map-section">
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div className="plp-map-section-header">
            <span className="plp-eyebrow">COMMUNITY</span>
            <h2>The Pet Legacy Map</h2>
            <p>
              Share where your pet is from and help build a nationwide community of pet lovers.
              Pin your pet by city and state and share a short story.
            </p>
          </div>
          <PetLegacyMap />
        </div>
      </section>

      {/* ── 16. FINAL CTA ──────────────────────────────────────────────────────── */}
      <section id="section-newsletter" className="section-padding bg-gradient-to-br from-burgundy-dark to-dark-base">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center reveal">
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-cream mb-6">
              Your Pets Deserve a Plan. Start Today.
            </h2>
            <p className="text-lg text-muted-foreground mb-10">
              Join thousands of pet families who have taken the most important step they can take for the animals they love.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-primary text-primary-foreground hover:opacity-90 font-bold text-base px-10 py-6" asChild>
                <Link href="/plans">Choose Your Plan</Link>
              </Button>
              <Button size="lg" variant="outline" className="border-gold/50 text-gold hover:bg-gold/10 text-base px-10 py-6" asChild>
                <Link href="/how-it-works">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>


    </div>
  );
}
