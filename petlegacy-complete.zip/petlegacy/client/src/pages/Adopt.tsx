import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Heart, MapPin, Loader2, AlertCircle } from "lucide-react";
import BackToHome from "@/components/BackToHome";


const US_STATES = ["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"];

export default function Adopt() {
  const [selectedState, setSelectedState] = useState<string>("");

  const { data: listings, isLoading } = trpc.adoption.list.useQuery({
    state: selectedState || undefined,
  });

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Adoption Hub</Badge>
          <h1 className="font-serif text-5xl font-bold text-cream mb-4">Adopt a Pet</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
            Find your next family member from our network of approved rescue organizations and shelters. Every pet listed here is waiting for a loving home.
          </p>
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-8">
            <AlertCircle className="w-4 h-4 text-gold" />
            <span>All listings are from approved rescue organizations. Verified and moderated.</span>
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          {/* Filter */}
          <div className="flex items-center gap-4 mb-8">
            <Select value={selectedState} onValueChange={setSelectedState}>
              <SelectTrigger className="w-48 bg-input border-border">
                <SelectValue placeholder="Filter by state" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                <SelectItem value="all">All States</SelectItem>
                {US_STATES.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedState && selectedState !== "all" && (
              <Button variant="ghost" size="sm" className="text-muted-foreground" onClick={() => setSelectedState("")}>
                Clear filter
              </Button>
            )}
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 text-gold animate-spin" />
            </div>
          ) : listings && listings.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {listings.map((listing: any) => (
                <div key={listing.id} className="card-luxury rounded-2xl p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-serif text-xl font-bold text-cream">{listing.petName}</h3>
                      {listing.breed && <p className="text-xs text-gold">{listing.species} — {listing.breed}</p>}
                      {listing.age && <p className="text-xs text-muted-foreground">Age: {listing.age}</p>}
                    </div>
                    {listing.featured && <Badge className="badge-gold text-xs">Featured</Badge>}
                  </div>
                  {listing.description && (
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-3">{listing.description}</p>
                  )}
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    {listing.city && listing.state && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {listing.city}, {listing.state}
                      </span>
                    )}
                    {listing.contactEmail && (
                      <a href={`mailto:${listing.contactEmail}`} className="text-gold hover:text-gold-light flex items-center gap-1">
                        <Heart className="w-3 h-3" />
                        Inquire
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 card-luxury rounded-2xl">
              <Heart className="w-12 h-12 text-gold/30 mx-auto mb-4" />
              <p className="text-muted-foreground mb-2">No adoption listings available{selectedState && selectedState !== "all" ? ` in ${selectedState}` : ""} at this time.</p>
              <p className="text-sm text-muted-foreground">Check back soon — we're always adding new listings from our rescue partners.</p>
            </div>
          )}
        </div>
      </section>

      {/* Rescue CTA */}
      <section className="section-padding bg-dark-surface">
        <div className="container text-center">
          <h2 className="font-serif text-3xl font-bold text-cream mb-4">Are You a Rescue Organization?</h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Partner with Pet Legacy Planning to reach thousands of potential adopters. Contact us to get your organization listed.
          </p>
          <Button className="bg-primary text-primary-foreground" asChild>
            <a href="mailto:rescues@petlegacyplanning.com">Partner With Us</a>
          </Button>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
