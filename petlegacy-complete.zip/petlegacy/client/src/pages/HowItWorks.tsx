import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Shield, Download, Users, RefreshCw, ArrowRight, Lock, Globe } from "lucide-react";
import BackToHome from "@/components/BackToHome";


const steps = [
  {
    number: "01",
    icon: Shield,
    title: "Choose Your Plan",
    desc: "Select the level of protection that fits your family and your pets. From our free checklist to the Platinum done-for-you service, every plan is built with the same commitment to quality.",
    details: ["Free Basic Checklist", "Premium Kit ($34.95)", "Ultimate Kit ($69.95)", "Platinum Done-For-You ($179.95)"],
  },
  {
    number: "02",
    icon: CheckCircle,
    title: "Create Your Account",
    desc: "Sign in securely to access your personal pet protection workspace. Your account stores all your pet information, documents, and plan details in one safe place.",
    details: ["Secure OAuth login", "Encrypted data storage", "Access from any device", "No data ever sold"],
  },
  {
    number: "03",
    icon: Users,
    title: "Complete Your Workspace",
    desc: "Fill out your pet's care details, medical history, feeding routines, behavioral notes, and designate your trusted guardians. Our guided workspace makes it simple.",
    details: ["Pet profile & photo", "Medical history & medications", "Daily care routines", "Guardian designation"],
  },
  {
    number: "04",
    icon: Download,
    title: "Save, Download & Share",
    desc: "Your plan is saved securely in your workspace and available as a downloadable PDF anytime. Share it with your designated guardians, veterinarian, or attorney.",
    details: ["Printable PDF format", "Digital workspace access", "Share with guardians", "Store with important documents"],
  },
  {
    number: "05",
    icon: RefreshCw,
    title: "Update Anytime",
    desc: "Life changes. Your pets change. Your plan can too. Return to your workspace whenever you need to update information, add pets, or change guardians.",
    details: ["Unlimited updates", "Version history", "Add new pets anytime", "Change guardians easily"],
  },
];

const included = [
  "Pet identification & profile",
  "Medical history & vaccination records",
  "Medication schedules & dosages",
  "Feeding routines & dietary needs",
  "Behavioral notes & special needs",
  "Veterinarian & emergency contacts",
  "Guardian designation & instructions",
  "Daily care routines",
  "Financial care instructions",
  "End-of-life wishes",
];

export default function HowItWorks() {
  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Simple Process</Badge>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-cream mb-6">How Pet Legacy Planning Works</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Five simple steps to complete protection for the pets you love. No legal expertise required — just your love for your animals and a few minutes of your time.
          </p>
        </div>
      </section>

      {/* Steps */}
      <section className="section-padding">
        <div className="container max-w-4xl mx-auto">
          <div className="space-y-8">
            {steps.map((step, i) => (
              <div key={step.number} className="flex gap-6 items-start">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-2xl bg-dark-elevated border border-gold/30 flex items-center justify-center">
                    <span className="font-serif text-2xl font-bold text-gold">{step.number}</span>
                  </div>
                  {i < steps.length - 1 && (
                    <div className="w-px h-8 bg-gold/20 mx-auto mt-2" />
                  )}
                </div>
                <div className="flex-1 card-luxury rounded-2xl p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <step.icon className="w-5 h-5 text-gold" />
                    <h2 className="font-serif text-xl font-bold text-cream">{step.title}</h2>
                  </div>
                  <p className="text-muted-foreground leading-relaxed mb-4">{step.desc}</p>
                  <div className="grid grid-cols-2 gap-2">
                    {step.details.map((d) => (
                      <div key={d} className="flex items-center gap-2 text-sm text-foreground/70">
                        <CheckCircle className="w-3.5 h-3.5 text-gold flex-shrink-0" />
                        {d}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="font-serif text-3xl font-bold text-cream mb-4">What's Included in Your Plan</h2>
              <p className="text-muted-foreground">A complete pet protection plan covers every aspect of your pet's care needs.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {included.map((item) => (
                <div key={item} className="flex items-center gap-3 card-luxury rounded-xl p-4">
                  <CheckCircle className="w-5 h-5 text-gold flex-shrink-0" />
                  <span className="text-sm text-foreground/80">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Security */}
      <section className="section-padding">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { icon: Lock, title: "Secure & Private", desc: "All data is encrypted. We never sell or share your personal information." },
              { icon: Globe, title: "50-State Framework", desc: "Our planning language and guidance works across all 50 US states." },
              { icon: Shield, title: "30-Day Guarantee", desc: "Not satisfied? We'll refund your purchase within 30 days, no questions asked." },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="card-luxury rounded-2xl p-6 text-center">
                <Icon className="w-10 h-10 text-gold mx-auto mb-4" />
                <h3 className="font-serif text-lg font-bold text-cream mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding bg-dark-surface">
        <div className="container text-center">
          <h2 className="font-serif text-4xl font-bold text-cream mb-6">Ready to Protect Your Pets?</h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Start with our free checklist or choose a paid plan for complete protection. Your pets are counting on you.
          </p>
          <Button size="lg" className="bg-primary text-primary-foreground font-bold px-10 py-6" asChild>
            <Link href="/plans">
              Choose Your Plan <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </Button>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
