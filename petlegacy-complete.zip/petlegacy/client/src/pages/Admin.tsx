import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, XCircle, Users, ShoppingBag, Star, Newspaper, BarChart3, Loader2, Shield } from "lucide-react";
import { toast } from "sonner";
import { Link } from "wouter";
import BackToHome from "@/components/BackToHome";


export default function Admin() {
  const { user } = useAuth();

  const { data: modRaw, isLoading: modLoading, refetch: refetchMod } = trpc.admin.moderation.useQuery();
  const modItems = modRaw ? [
    ...(modRaw.community ?? []).map((i: any) => ({ ...i, type: "community" as const, name: i.petName })),
    ...(modRaw.rehoming ?? []).map((i: any) => ({ ...i, type: "rehoming" as const, name: i.petName })),
    ...(modRaw.memorials ?? []).map((i: any) => ({ ...i, type: "memorial" as const, name: i.petName })),
    ...(modRaw.adoptions ?? []).map((i: any) => ({ ...i, type: "adoption" as const, name: i.petName })),
  ] : [];
  const { data: allUsers, isLoading: usersLoading } = trpc.admin.users.useQuery();
  const { data: platinumClients, isLoading: platinumLoading } = trpc.platinum.adminList.useQuery();
  const { data: affiliateStats, isLoading: statsLoading } = trpc.admin.affiliateStats.useQuery();

  const approveMutation = trpc.admin.approveItem.useMutation({
    onSuccess: () => {
      toast.success("Item updated.");
      refetchMod();
    },
    onError: () => toast.error("Action failed."),
  });

  const updatePlatinumMutation = trpc.platinum.adminUpdateStatus.useMutation({
    onSuccess: () => toast.success("Status updated."),
    onError: () => toast.error("Update failed."),
  });

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background pt-24 flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
          <h1 className="font-serif text-2xl font-bold text-cream mb-2">Access Restricted</h1>
          <p className="text-muted-foreground">This area is for administrators only.</p>
          <Button className="mt-4" asChild><Link href="/">Go Home</Link></Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container">
          <div className="flex items-center gap-3 mb-8">
            <Shield className="w-7 h-7 text-gold" />
            <div>
              <h1 className="font-serif text-3xl font-bold text-cream">Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Pet Legacy Planning — Internal Management</p>
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
              { label: "Total Users", value: allUsers?.length ?? "—", icon: Users },
              { label: "Pending Review", value: modItems?.length ?? "—", icon: Star },
              { label: "Platinum Clients", value: platinumClients?.length ?? "—", icon: ShoppingBag },
              { label: "Affiliate Codes", value: affiliateStats?.length ?? "—", icon: BarChart3 },
            ].map(({ label, value, icon: Icon }) => (
              <div key={label} className="card-luxury rounded-xl p-4">
                <Icon className="w-5 h-5 text-gold mb-2" />
                <p className="font-serif text-2xl font-bold text-cream">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding pt-0">
        <div className="container">
          <Tabs defaultValue="moderation">
            <TabsList className="bg-dark-surface border border-border mb-6">
              <TabsTrigger value="moderation" className="data-[state=active]:bg-gold/10 data-[state=active]:text-gold">Moderation</TabsTrigger>
              <TabsTrigger value="users" className="data-[state=active]:bg-gold/10 data-[state=active]:text-gold">Users</TabsTrigger>
              <TabsTrigger value="platinum" className="data-[state=active]:bg-gold/10 data-[state=active]:text-gold">Platinum</TabsTrigger>
              <TabsTrigger value="affiliates" className="data-[state=active]:bg-gold/10 data-[state=active]:text-gold">Affiliates</TabsTrigger>
            </TabsList>

            {/* Moderation */}
            <TabsContent value="moderation">
              <h2 className="font-serif text-xl font-bold text-cream mb-4">Pending Moderation</h2>
              {modLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-gold animate-spin" /></div>
              ) : modItems && modItems.length > 0 ? (
                <div className="space-y-3">
                  {modItems.map((item: any) => (
                    <div key={`${item.type}-${item.id}`} className="card-luxury rounded-xl p-4 flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-xs border-gold/30 text-gold">{item.type}</Badge>
                          <span className="font-semibold text-cream text-sm">{item.name}</span>
                        </div>
                        {item.description && <p className="text-xs text-muted-foreground line-clamp-2">{item.description}</p>}
                        {item.story && <p className="text-xs text-muted-foreground line-clamp-2">{item.story}</p>}
                        {item.tribute && <p className="text-xs text-muted-foreground line-clamp-2">{item.tribute}</p>}
                      </div>
                      <div className="flex gap-2 flex-shrink-0">
                        <Button size="sm" className="bg-green-700/20 text-green-400 hover:bg-green-700/30 border border-green-700/30"
                          onClick={() => approveMutation.mutate({ type: item.type, id: item.id, approved: true })}>
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                        <Button size="sm" className="bg-red-700/20 text-red-400 hover:bg-red-700/30 border border-red-700/30"
                          onClick={() => approveMutation.mutate({ type: item.type, id: item.id, approved: false })}>
                          <XCircle className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 card-luxury rounded-xl">
                  <CheckCircle className="w-10 h-10 text-gold/30 mx-auto mb-3" />
                  <p className="text-muted-foreground">No items pending moderation.</p>
                </div>
              )}
            </TabsContent>

            {/* Users */}
            <TabsContent value="users">
              <h2 className="font-serif text-xl font-bold text-cream mb-4">All Users</h2>
              {usersLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-gold animate-spin" /></div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border text-left">
                        <th className="pb-3 text-muted-foreground font-medium">Name</th>
                        <th className="pb-3 text-muted-foreground font-medium">Email</th>
                        <th className="pb-3 text-muted-foreground font-medium">Role</th>
                        <th className="pb-3 text-muted-foreground font-medium">Joined</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {allUsers?.map((u: any) => (
                        <tr key={u.id}>
                          <td className="py-3 text-cream">{u.name ?? "—"}</td>
                          <td className="py-3 text-muted-foreground">{u.email ?? "—"}</td>
                          <td className="py-3">
                            <Badge variant="outline" className={`text-xs ${u.role === "admin" ? "border-gold/40 text-gold" : "border-border text-muted-foreground"}`}>{u.role}</Badge>
                          </td>
                          <td className="py-3 text-muted-foreground text-xs">{new Date(u.createdAt).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </TabsContent>

            {/* Platinum */}
            <TabsContent value="platinum">
              <h2 className="font-serif text-xl font-bold text-cream mb-4">Platinum Clients</h2>
              {platinumLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-gold animate-spin" /></div>
              ) : platinumClients && platinumClients.length > 0 ? (
                <div className="space-y-3">
                  {platinumClients.map((client: any) => (
                    <div key={client.id} className="card-luxury rounded-xl p-4 flex items-center justify-between gap-4">
                      <div>
                        <p className="text-sm font-semibold text-cream">Client #{client.id}</p>
                        <p className="text-xs text-muted-foreground">{client.notes?.slice(0, 80) ?? ""}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={`text-xs ${
                          client.status === "complete" ? "bg-green-700/20 text-green-400" :
                          client.status === "in_progress" ? "bg-gold/20 text-gold" :
                          "bg-dark-elevated text-muted-foreground"
                        }`}>{client.status}</Badge>
                        <select
                          className="text-xs bg-input border border-border rounded px-2 py-1 text-cream"
                          value={client.status}
                          onChange={(e) => updatePlatinumMutation.mutate({ id: client.id, status: e.target.value as any })}
                        >
                          <option value="intake">Intake</option>
                          <option value="in_progress">In Progress</option>
                          <option value="review">Review</option>
                          <option value="complete">Complete</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 card-luxury rounded-xl">
                  <p className="text-muted-foreground">No platinum clients yet.</p>
                </div>
              )}
            </TabsContent>

            {/* Affiliates */}
            <TabsContent value="affiliates">
              <h2 className="font-serif text-xl font-bold text-cream mb-4">Affiliate & Promo Codes</h2>
              {statsLoading ? (
                <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-gold animate-spin" /></div>
              ) : affiliateStats && affiliateStats.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border text-left">
                        <th className="pb-3 text-muted-foreground font-medium">Code</th>
                        <th className="pb-3 text-muted-foreground font-medium">Type</th>
                        <th className="pb-3 text-muted-foreground font-medium">Discount</th>
                        <th className="pb-3 text-muted-foreground font-medium">Uses</th>
                        <th className="pb-3 text-muted-foreground font-medium">Revenue</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {affiliateStats.map((stat: any) => (
                        <tr key={stat.code}>
                          <td className="py-3 font-mono text-gold">{stat.code}</td>
                          <td className="py-3 text-muted-foreground">{stat.type}</td>
                          <td className="py-3 text-cream">{stat.discountPct}%</td>
                          <td className="py-3 text-cream">{stat.useCount}</td>
                          <td className="py-3 text-green-400">${(stat.totalRevenue ?? 0).toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-12 card-luxury rounded-xl">
                  <p className="text-muted-foreground">No affiliate codes yet.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
