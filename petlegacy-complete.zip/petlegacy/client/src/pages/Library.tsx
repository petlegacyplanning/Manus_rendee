import { useEffect } from "react";
import { Link, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, ChevronRight, Loader2, ArrowLeft } from "lucide-react";
import BackToHome from "@/components/BackToHome";

// ─── Hub metadata ─────────────────────────────────────────────────────────────
const hubMeta: Record<string, { label: string; icon: string; desc: string; h2: string }> = {
  // Core SEO / planning hubs
  "pet-trusts":       { label: "Pet Trusts",              icon: "🏦", h2: "Pet Trust Guides",              desc: "Complete guides to pet trusts — how they work, what they cover, and how to set one up." },
  "estate-planning":  { label: "Pet Estate Planning",     icon: "📜", h2: "Pet Estate Planning",           desc: "Protect your pets in your will and estate plan with structured legal tools." },
  guardianship:       { label: "Guardianship",            icon: "📋", h2: "Pet Guardianship Planning",     desc: "Everything you need to know about designating a trusted pet guardian." },
  "legal-resources":  { label: "Legal Resources",         icon: "⚖️", h2: "Pet Inheritance Laws",          desc: "Pet inheritance laws, legal rights, and state-by-state guidance for pet owners." },
  "emergency-planning": { label: "Emergency Pet Care",   icon: "🚨", h2: "Emergency Pet Care",            desc: "Prepare your pet for any emergency with our comprehensive planning guides." },
  "planning-tools":   { label: "Planning Tools",          icon: "🛠️", h2: "Pet Care Directives & Tools",   desc: "Pet care directives, documentation templates, and practical planning tools." },
  "state-laws":       { label: "Pet Trust Laws by State", icon: "🗺️", h2: "Pet Trust Laws by State",      desc: "State-by-state guides to pet trust laws and how they apply where you live." },
  // Behavior & breeds
  behavior:           { label: "Pet Behavior Guides",     icon: "🧠", h2: "Dog Behavior Guides",           desc: "Understanding and addressing common pet behavior issues with positive, proven methods." },
  breeds:             { label: "Dog Breed Guides",        icon: "🐕", h2: "Dog Breed Guides",              desc: "Temperament, training, and care tips for every dog breed." },
  // General care
  dogs:               { label: "Dogs",                    icon: "🐕", h2: "Dog Care Guides",               desc: "Comprehensive guides for dog owners — training, health, breeds, and more." },
  cats:               { label: "Cats",                    icon: "🐈", h2: "Cat Care Guides",               desc: "Everything you need to know about caring for your feline companion." },
  "senior-pets":      { label: "Senior Pets",             icon: "🐾", h2: "Senior Pet Care",               desc: "Specialized care guides for aging pets and their unique needs." },
  "pet-grief":        { label: "Pet Grief",               icon: "💙", h2: "Pet Grief & Loss",              desc: "Compassionate support and resources for coping with pet loss." },
  training:           { label: "Training",                icon: "🎓", h2: "Pet Training Guides",           desc: "Proven training methods and behavioral guidance for all pets." },
  "rescue-adoption":  { label: "Rescue & Adoption",       icon: "🏠", h2: "Rescue & Adoption Guides",     desc: "Guides for adopting rescue pets and supporting rescue organizations." },
  health:             { label: "Health & Wellness",       icon: "🏥", h2: "Pet Health & Wellness",         desc: "Preventive care, nutrition, and health management for all pets." },
};

const defaultHubs = Object.keys(hubMeta);

// ─── JSON-LD schema injector ──────────────────────────────────────────────────
function ArticleSchema({ title, hub }: { title: string; hub: string }) {
  useEffect(() => {
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.id = "article-schema";
    script.text = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Article",
      headline: title,
      author: { "@type": "Organization", name: "Pet Legacy Planning" },
      publisher: {
        "@type": "Organization",
        name: "Pet Legacy Planning",
        logo: { "@type": "ImageObject", url: "https://petlegacyplanning.com/logo.png" },
      },
      mainEntityOfPage: {
        "@type": "WebPage",
        "@id": `https://petlegacyplanning.com/library/${hub}`,
      },
    });
    document.head.appendChild(script);
    return () => { document.getElementById("article-schema")?.remove(); };
  }, [title, hub]);
  return null;
}

// ─── Related Articles ─────────────────────────────────────────────────────────
function RelatedArticles({ hub, excludeSlug }: { hub: string; excludeSlug: string }) {
  const { data: related, isLoading } = trpc.library.related.useQuery({ hub, excludeSlug });
  if (isLoading || !related || related.length === 0) return null;

  return (
    <section className="related-articles mt-12">
      <div className="divider-gold mb-8" />
      <h3 className="font-serif text-xl font-bold text-cream mb-6">Related Articles</h3>
      <ul className="grid md:grid-cols-2 gap-4">
        {related.map((art) => (
          <li key={art.slug}>
            <Link href={`/library/article/${art.slug}`}>
              <div className="card-luxury rounded-xl p-5 hover:border-gold/40 transition-all cursor-pointer group">
                <span className="text-xs text-gold/60 uppercase tracking-wide mb-1 block">
                  {hubMeta[art.hub]?.label ?? art.hub}
                </span>
                <p className="font-serif text-sm font-semibold text-cream group-hover:text-gold transition-colors leading-snug">
                  {art.title}
                </p>
                {art.excerpt && (
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{art.excerpt}</p>
                )}
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

// ─── Article view ─────────────────────────────────────────────────────────────
function ArticleView({ slug }: { slug: string }) {
  const { data: article, isLoading } = trpc.library.bySlug.useQuery({ slug });

  if (isLoading) return (
    <div className="flex justify-center py-12">
      <Loader2 className="w-8 h-8 text-gold animate-spin" />
    </div>
  );
  if (!article) return (
    <div className="text-center py-12 text-muted-foreground">Article not found.</div>
  );

  let tagList: string[] = [];
  try { tagList = JSON.parse(String(article.tags ?? "[]")) as string[]; } catch { tagList = []; }

  const hubLabel = hubMeta[article.hub]?.label ?? article.hub;

  return (
    <div className="max-w-3xl mx-auto">
      <ArticleSchema title={article.title} hub={article.hub} />

      <Link href={`/library/${article.hub}`}>
        <Button variant="ghost" size="sm" className="mb-6 text-muted-foreground hover:text-gold">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to {hubLabel}
        </Button>
      </Link>

      <article className="card-luxury rounded-2xl p-8 md:p-12">
        {/* Breadcrumb */}
        <nav className="text-xs text-muted-foreground mb-6 flex items-center gap-1.5">
          <Link href="/library" className="hover:text-gold transition-colors">Library</Link>
          <ChevronRight className="w-3 h-3" />
          <Link href={`/library/${article.hub}`} className="hover:text-gold transition-colors">{hubLabel}</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-foreground/60 truncate max-w-[200px]">{article.title}</span>
        </nav>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-4">
          {tagList.map((tag) => (
            <Badge key={tag} variant="outline" className="border-gold/30 text-gold/70 text-xs">{tag}</Badge>
          ))}
        </div>

        {/* Title */}
        <h1 className="font-serif text-3xl md:text-4xl font-bold text-cream mb-4">{article.title}</h1>

        {/* Excerpt / lead */}
        {article.excerpt && (
          <p className="text-muted-foreground leading-relaxed mb-8 text-lg">{article.excerpt}</p>
        )}

        <div className="divider-gold mb-8" />

        {/* Body — rendered as plain text markdown */}
        <div className="prose prose-invert prose-lg max-w-none prose-headings:font-serif prose-headings:text-cream prose-p:text-muted-foreground prose-p:leading-relaxed prose-li:text-muted-foreground prose-strong:text-cream">
          {/* Render markdown as plain text sections */}
          {(article.content ?? "")
            .split("\n")
            .map((line, i) => {
              if (line.startsWith("## ")) return <h2 key={i} className="font-serif text-2xl font-bold text-cream mt-8 mb-3">{line.replace("## ", "")}</h2>;
              if (line.startsWith("### ")) return <h3 key={i} className="font-serif text-xl font-semibold text-cream mt-6 mb-2">{line.replace("### ", "")}</h3>;
              if (line.startsWith("# ")) return null; // skip H1 (already shown above)
              if (line.startsWith("**SEO Title:**") || line.startsWith("**SEO Description:**")) return null;
              if (line.startsWith("- ")) return <li key={i} className="ml-4 text-muted-foreground">{line.replace(/^- /, "")}</li>;
              if (line.match(/^\d+\. /)) return <li key={i} className="ml-4 text-muted-foreground list-decimal">{line.replace(/^\d+\. /, "")}</li>;
              if (line.trim() === "") return <div key={i} className="h-2" />;
              return <p key={i} className="text-muted-foreground leading-relaxed mb-3">{line}</p>;
            })}
        </div>

        {/* Related Articles */}
        <RelatedArticles hub={article.hub} excludeSlug={slug} />
      </article>
    </div>
  );
}

// ─── Hub view ─────────────────────────────────────────────────────────────────
function HubView({ hub }: { hub: string }) {
  const meta = hubMeta[hub] ?? { label: hub, icon: "📚", desc: "", h2: hub };
  const { data: articles, isLoading } = trpc.library.byHub.useQuery({ hub });

  return (
    <div>
      <Link href="/library">
        <Button variant="ghost" size="sm" className="mb-6 text-muted-foreground hover:text-gold">
          <ArrowLeft className="w-4 h-4 mr-2" />
          All Hubs
        </Button>
      </Link>

      <div className="flex items-center gap-4 mb-2">
        <div className="text-5xl">{meta.icon}</div>
        <div>
          <h2 className="font-serif text-3xl font-bold text-cream">{meta.h2}</h2>
          <p className="text-muted-foreground">{meta.desc}</p>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 text-gold animate-spin" /></div>
      ) : articles && articles.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {articles.map((article: any) => (
            <Link key={article.id} href={`/library/article/${article.slug}`}>
              <div className="card-luxury rounded-xl p-6 hover:border-gold/40 transition-all cursor-pointer group h-full flex flex-col">
                {article.featured && <Badge className="badge-gold text-xs mb-3 self-start">Featured</Badge>}
                <h3 className="font-serif text-base font-bold text-cream mb-2 group-hover:text-gold transition-colors flex-1">{article.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-3">{article.excerpt}</p>
                <span className="text-xs text-gold flex items-center gap-1 mt-auto">
                  Read Article <ChevronRight className="w-3 h-3" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 card-luxury rounded-2xl mt-8">
          <BookOpen className="w-12 h-12 text-gold/30 mx-auto mb-4" />
          <p className="text-muted-foreground">No articles yet in this hub.</p>
        </div>
      )}
    </div>
  );
}

// ─── Library home ─────────────────────────────────────────────────────────────
function LibraryHome() {
  const { data: featured, isLoading } = trpc.library.featured.useQuery();

  // Ordered sections matching the spec
  const sections: { heading: string; hubs: string[] }[] = [
    {
      heading: "Pet Estate Planning",
      hubs: ["estate-planning", "pet-trusts", "guardianship", "legal-resources", "planning-tools", "state-laws"],
    },
    {
      heading: "Dog Behavior Guides",
      hubs: ["behavior"],
    },
    {
      heading: "Dog Breed Guides",
      hubs: ["breeds"],
    },
    {
      heading: "Emergency Pet Care",
      hubs: ["emergency-planning"],
    },
    {
      heading: "Pet Care Guides",
      hubs: ["dogs", "cats", "senior-pets", "health", "training"],
    },
    {
      heading: "Pet Grief & Loss",
      hubs: ["pet-grief"],
    },
    {
      heading: "Rescue & Adoption",
      hubs: ["rescue-adoption"],
    },
  ];

  return (
    <div>
      {/* Page header */}
      <div className="text-center mb-14">
        <Badge className="badge-gold mb-6 px-4 py-1.5">Pet Library</Badge>
        <h1 className="font-serif text-5xl font-bold text-cream mb-4">
          The Complete Pet Legacy Planning Library
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
          The most authoritative pet planning resource in America — 1,380+ articles covering estate planning, pet trusts, behavior, breeds, emergency care, and more.
        </p>
      </div>

      {/* Structured sections */}
      {sections.map(({ heading, hubs }) => {
        const validHubs = hubs.filter((h) => hubMeta[h]);
        if (validHubs.length === 0) return null;
        return (
          <section key={heading} className="mb-14">
            <h2 className="font-serif text-2xl font-bold text-cream mb-6 flex items-center gap-3">
              <span className="text-gold text-xl">{hubMeta[validHubs[0]]?.icon}</span>
              {heading}
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {validHubs.map((hub) => {
                const meta = hubMeta[hub];
                return (
                  <Link key={hub} href={`/library/${hub}`}>
                    <div className="card-luxury rounded-xl p-5 text-center hover:border-gold/40 transition-all cursor-pointer group h-full flex flex-col items-center justify-center">
                      <div className="text-3xl mb-2">{meta.icon}</div>
                      <p className="text-sm font-medium text-foreground/80 group-hover:text-gold transition-colors">{meta.label}</p>
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        );
      })}

      {/* Featured Articles */}
      {!isLoading && featured && featured.length > 0 && (
        <section className="mt-4">
          <h2 className="font-serif text-2xl font-bold text-cream mb-6">Featured Articles</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featured.map((article: any) => (
              <Link key={article.id} href={`/library/article/${article.slug}`}>
                <div className="card-luxury rounded-xl p-6 hover:border-gold/40 transition-all cursor-pointer group">
                  <div className="text-2xl mb-3">{hubMeta[article.hub]?.icon ?? "📚"}</div>
                  <Badge variant="outline" className="border-gold/30 text-gold/70 text-xs mb-3">
                    {hubMeta[article.hub]?.label ?? article.hub}
                  </Badge>
                  <h3 className="font-serif text-base font-bold text-cream mb-2 group-hover:text-gold transition-colors">{article.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed line-clamp-3">{article.excerpt}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* JSON-LD for library home */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            name: "The Complete Pet Legacy Planning Library",
            description: "1,380+ articles on pet estate planning, pet trusts, dog breeds, behavior, emergency care, and more.",
            url: "https://petlegacyplanning.com/library",
            publisher: { "@type": "Organization", name: "Pet Legacy Planning" },
          }),
        }}
      />
    </div>
  );
}

// ─── Main export ──────────────────────────────────────────────────────────────
export default function Library() {
  const [, hubParams] = useRoute("/library/:hub");
  const [, articleParams] = useRoute("/library/article/:slug");

  const hub = hubParams?.hub;
  const slug = articleParams?.slug;

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding">
        <div className="container">
          {slug ? (
            <ArticleView slug={slug} />
          ) : hub ? (
            <HubView hub={hub} />
          ) : (
            <LibraryHome />
          )}
        </div>
      </section>
      <BackToHome />
    </div>
  );
}
