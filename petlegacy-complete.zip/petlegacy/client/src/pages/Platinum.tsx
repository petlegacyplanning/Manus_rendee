import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle, Star, Shield, Phone, Mail, Loader2 } from "lucide-react";
import { toast } from "sonner";
import BackToHome from "@/components/BackToHome";


const included = [
  "Everything in Ultimate Kit",
  "Done-for-you plan completion",
  "Dedicated pet protection advisor",
  "Custom documentation creation",
  "Final review & delivery",
  "Platinum client portal access",
  "White-glove service experience",
  "Priority phone & email support",
  "Lifetime updates included",
  "Multi-pet coverage",
];

const steps = [
  { n: "01", title: "Purchase Platinum", desc: "Complete your Platinum purchase and receive immediate access to your dedicated advisor portal." },
  { n: "02", title: "Initial Consultation", desc: "Your dedicated advisor reaches out within 24 hours to schedule your intake consultation." },
  { n: "03", title: "We Do the Work", desc: "You provide the information, we complete your entire pet protection plan for you." },
  { n: "04", title: "Review & Delivery", desc: "We deliver your completed plan for your review. Revisions included until you're 100% satisfied." },
];

export default function Platinum() {
  const { isAuthenticated, user } = useAuth();
  const [form, setForm] = useState({ name: "", email: "", phone: "", petCount: "1", notes: "" });
  const [submitted, setSubmitted] = useState(false);

  const submitMutation = trpc.platinum.submitInquiry.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Inquiry submitted! Your advisor will contact you within 24 hours.");
    },
    onError: () => toast.error("Submission failed. Please try again."),
  });

  const handleSubmit = () => {
    if (!form.name.trim() || !form.email.trim()) {
      toast.error("Name and email are required.");
      return;
    }
    submitMutation.mutate(form);
  };

  return (
    <div className="min-h-screen bg-background pt-24">
      {/* Hero */}
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">White-Glove Service</Badge>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-cream mb-6">
            Platinum Done-For-You
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-4">
            The ultimate pet protection experience. We complete your entire plan for you — with a dedicated advisor by your side.
          </p>
          <div className="flex items-center justify-center gap-2 mb-8">
            <span className="font-serif text-5xl font-bold text-gold">$179.95</span>
            <span className="text-muted-foreground">one-time</span>
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="section-padding">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <div>
              <h2 className="font-serif text-2xl font-bold text-cream mb-6">Everything Included</h2>
              <div className="space-y-3">
                {included.map((item) => (
                  <div key={item} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-gold flex-shrink-0" />
                    <span className="text-foreground/80">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* How It Works */}
            <div>
              <h2 className="font-serif text-2xl font-bold text-cream mb-6">How It Works</h2>
              <div className="space-y-4">
                {steps.map((step) => (
                  <div key={step.n} className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-gold/10 border border-gold/30 flex items-center justify-center flex-shrink-0">
                      <span className="text-xs font-bold text-gold">{step.n}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-cream text-sm">{step.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Inquiry Form */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="max-w-lg mx-auto">
            <div className="text-center mb-8">
              <Star className="w-10 h-10 text-gold mx-auto mb-4" />
              <h2 className="font-serif text-3xl font-bold text-cream mb-3">Start Your Platinum Journey</h2>
              <p className="text-muted-foreground">Fill out the form below and your dedicated advisor will contact you within 24 hours.</p>
            </div>

            {submitted ? (
              <div className="card-luxury rounded-2xl p-8 text-center">
                <CheckCircle className="w-12 h-12 text-gold mx-auto mb-4" />
                <h3 className="font-serif text-xl font-bold text-cream mb-2">Inquiry Received!</h3>
                <p className="text-muted-foreground">Your dedicated advisor will reach out within 24 hours to begin your Platinum experience.</p>
              </div>
            ) : (
              <div className="card-luxury rounded-2xl p-8 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Full Name *</label>
                    <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-input border-border" placeholder="Jane Smith" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Email *</label>
                    <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="bg-input border-border" placeholder="jane@example.com" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Phone</label>
                    <Input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="bg-input border-border" placeholder="(555) 000-0000" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Number of Pets</label>
                    <Input type="number" min="1" value={form.petCount} onChange={(e) => setForm({ ...form, petCount: e.target.value })} className="bg-input border-border" />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Tell us about your pets</label>
                  <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="bg-input border-border" placeholder="Species, breeds, ages, any special needs..." rows={3} />
                </div>
                <Button className="w-full bg-gold text-background font-bold hover:opacity-90" onClick={handleSubmit} disabled={submitMutation.isPending}>
                  {submitMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Star className="w-4 h-4 mr-2" />}
                  Submit Platinum Inquiry
                </Button>
                <p className="text-xs text-muted-foreground text-center">Your advisor will contact you within 24 hours.</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="section-padding">
        <div className="container text-center">
          <Shield className="w-10 h-10 text-gold mx-auto mb-4" />
          <h2 className="font-serif text-2xl font-bold text-cream mb-4">Have Questions?</h2>
          <p className="text-muted-foreground mb-6">Our team is here to answer any questions about the Platinum service.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="outline" className="border-gold/40 text-gold hover:bg-gold/10" asChild>
              <a href="mailto:platinum@petlegacyplanning.com">
                <Mail className="w-4 h-4 mr-2" />
                Email Us
              </a>
            </Button>
            <Button variant="outline" className="border-gold/40 text-gold hover:bg-gold/10" asChild>
              <a href="tel:+18005551234">
                <Phone className="w-4 h-4 mr-2" />
                Call Us
              </a>
            </Button>
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
