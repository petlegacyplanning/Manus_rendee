import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ChevronLeft, ChevronRight, Save, Download } from "lucide-react";
import { trpc } from "@/lib/trpc";

const PREMIUM_SECTIONS = [
  { id: "owner", title: "Owner Information", fields: ["ownerName", "phone", "email", "address"] },
  { id: "emergency", title: "Emergency Contact", fields: ["emergencyName", "relationship", "emergencyPhone"] },
  { id: "petId", title: "Pet Identification", fields: ["petName", "species", "breed", "colorMarks", "age", "microchip"] },
  { id: "dailyCare", title: "Daily Care Instructions", fields: ["foodBrand", "feedingSchedule", "exerciseNeeds", "favoriteActivities"] },
  { id: "vet", title: "Veterinarian Information", fields: ["clinicName", "vetPhone", "vetAddress"] },
  { id: "medical", title: "Medical Information", fields: ["medicalConditions", "medications", "allergies"] },
  { id: "guardian", title: "Pet Guardian", fields: ["primaryGuardian", "guardianPhone", "guardianAddress", "alternateGuardian"] },
  { id: "costs", title: "Estimated Monthly Pet Care Costs", fields: ["food", "vetCare", "medications", "grooming", "totalMonthlyCost"] },
  { id: "personality", title: "Personality & Comfort Notes", fields: ["favoriteToys", "fears", "comfortHabits"] },
];

const ULTIMATE_EXTRA_SECTIONS = [
  { id: "routine", title: "Detailed Daily Routine", fields: ["morningRoutine", "afternoonRoutine", "eveningRoutine"] },
  { id: "longTerm", title: "Long-Term Care Planning", fields: ["expectedLifespan", "futureMedicalConcerns", "specialDiet"] },
  { id: "agreement", title: "Guardian Agreement", fields: ["ownerNameAgreement", "guardianNameAgreement", "ownerSignature", "signatureDate", "guardianSignature"] },
  { id: "financialPlan", title: "Financial Planning", fields: ["estimatedMonthlyCost", "estimatedYears", "estimatedLifetimeCost", "fundsSetAside"] },
  { id: "disaster", title: "Disaster Plan", fields: ["hospitalizationPlan", "evacuationInstructions", "emergencySuppliesLocation"] },
  { id: "legacy", title: "Pet Legacy Letter", fields: ["legacyLetter"] },
  { id: "responder", title: "Emergency Responder Awareness Package", fields: ["doorKnobName", "doorKnobPhone", "windowName", "windowPhone", "petNames", "veterinarian"] },
];

interface PlannerData {
  [key: string]: any;
}

export default function PlannerWizard({ projectId }: { projectId: number }) {
  const [location, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<PlannerData>({});
  const [isSaving, setIsSaving] = useState(false);

  const { data: project, isLoading } = trpc.planner.getProject.useQuery(
    { projectId },
    { enabled: !!projectId }
  );

  const updateProjectMutation = trpc.planner.updateProject.useMutation();

  const planTier = project?.planTier || "basic";
  const sections = planTier === "ultimate" ? [...PREMIUM_SECTIONS, ...ULTIMATE_EXTRA_SECTIONS] : PREMIUM_SECTIONS;
  const currentSection = sections[currentStep];

  // Load existing data
  useEffect(() => {
    if (project?.data) {
      setFormData(project.data);
      setCurrentStep(project.currentStep || 0);
    }
  }, [project]);

  // Auto-save on data change
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (Object.keys(formData).length > 0) {
        setIsSaving(true);
        try {
          await updateProjectMutation.mutateAsync({
            projectId,
            currentStep,
            data: formData,
          });
        } finally {
          setIsSaving(false);
        }
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [formData, currentStep, projectId, updateProjectMutation]);

  const handleFieldChange = (fieldName: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [fieldName]: value,
    }));
  };

  const handleNext = () => {
    if (currentStep < sections.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = async () => {
    setIsSaving(true);
    try {
      await updateProjectMutation.mutateAsync({
        projectId,
        status: "completed",
        data: formData,
      });
      setLocation("/planner-dashboard");
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportPDF = async () => {
    // TODO: Implement PDF export
    alert("PDF export coming soon!");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/95 flex items-center justify-center">
        <p className="text-muted-foreground">Loading planner...</p>
      </div>
    );
  }

  if (!currentSection) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/95 flex items-center justify-center">
        <p className="text-muted-foreground">Planner not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground">{project?.title}</h1>
              <p className="text-muted-foreground capitalize">{planTier} Plan</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">
                Step {currentStep + 1} of {sections.length}
              </p>
              <div className="h-2 w-48 bg-muted rounded-full overflow-hidden mt-2">
                <div
                  className="h-full bg-gradient-to-r from-gold to-gold/70 transition-all"
                  style={{ width: `${((currentStep + 1) / sections.length) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Form Section */}
        <Card className="border-border/50 bg-card/50 mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">{currentSection.title}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {currentSection.fields.map((fieldName) => {
              const isTextarea = ["medicalConditions", "medications", "allergies", "morningRoutine", "afternoonRoutine", "eveningRoutine", "futureMedicalConcerns", "specialDiet", "hospitalizationPlan", "evacuationInstructions", "emergencySuppliesLocation", "legacyLetter", "fears", "comfortHabits", "favoriteToys"].includes(fieldName);
              
              const labels: Record<string, string> = {
                ownerName: "Owner Name",
                phone: "Phone",
                email: "Email",
                address: "Address",
                emergencyName: "Emergency Contact Name",
                relationship: "Relationship",
                emergencyPhone: "Emergency Contact Phone",
                petName: "Pet Name",
                species: "Species",
                breed: "Breed",
                colorMarks: "Color / Identifying Marks",
                age: "Age",
                microchip: "Microchip Number",
                foodBrand: "Food Brand",
                feedingSchedule: "Feeding Schedule",
                exerciseNeeds: "Exercise Needs",
                favoriteActivities: "Favorite Activities",
                clinicName: "Clinic Name",
                vetPhone: "Veterinarian Phone",
                vetAddress: "Veterinarian Address",
                medicalConditions: "Medical Conditions",
                medications: "Medications",
                allergies: "Allergies",
                primaryGuardian: "Primary Guardian Name",
                guardianPhone: "Guardian Phone",
                guardianAddress: "Guardian Address",
                alternateGuardian: "Alternate Guardian",
                food: "Food",
                vetCare: "Vet Care",
                grooming: "Grooming",
                totalMonthlyCost: "Total Monthly Cost",
                favoriteToys: "Favorite Toys",
                fears: "Fears or Triggers",
                comfortHabits: "Comfort Habits",
                morningRoutine: "Morning Routine",
                afternoonRoutine: "Afternoon Routine",
                eveningRoutine: "Evening Routine",
                expectedLifespan: "Expected Lifespan",
                futureMedicalConcerns: "Future Medical Concerns",
                specialDiet: "Special Diet Instructions",
                ownerNameAgreement: "Pet Owner Name",
                guardianNameAgreement: "Pet Guardian Name",
                ownerSignature: "Owner Signature",
                signatureDate: "Date",
                guardianSignature: "Guardian Signature",
                estimatedMonthlyCost: "Estimated Monthly Cost",
                estimatedYears: "Estimated Years Remaining",
                estimatedLifetimeCost: "Estimated Lifetime Cost",
                fundsSetAside: "Funds Set Aside for Pet Care",
                hospitalizationPlan: "If Owner is Hospitalized",
                evacuationInstructions: "Evacuation Instructions",
                emergencySuppliesLocation: "Emergency Supplies Location",
                legacyLetter: "Write a personal message to your pet's caregiver",
                doorKnobName: "Door Knob Alert - Emergency Contact Name",
                doorKnobPhone: "Door Knob Alert - Emergency Contact Phone",
                windowName: "Window Notice - Emergency Contact Name",
                windowPhone: "Window Notice - Emergency Contact Phone",
                petNames: "Wallet Card - Pet Names",
                veterinarian: "Wallet Card - Veterinarian",
              };

              return (
                <div key={fieldName}>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    {labels[fieldName] || fieldName}
                  </label>
                  {isTextarea ? (
                    <Textarea
                      value={formData[fieldName] || ""}
                      onChange={(e) => handleFieldChange(fieldName, e.target.value)}
                      placeholder="Enter information..."
                      rows={4}
                      className="bg-background/50 border-border/50"
                    />
                  ) : (
                    <Input
                      type="text"
                      value={formData[fieldName] || ""}
                      onChange={(e) => handleFieldChange(fieldName, e.target.value)}
                      placeholder="Enter information..."
                      className="bg-background/50 border-border/50"
                    />
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between gap-4">
          <Button
            onClick={handlePrev}
            disabled={currentStep === 0}
            variant="outline"
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Previous
          </Button>

          <div className="flex items-center gap-2">
            {isSaving && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Save className="w-3 h-3" />
                Saving...
              </span>
            )}
          </div>

          {currentStep === sections.length - 1 ? (
            <div className="flex gap-2">
              <Button
                onClick={handleExportPDF}
                variant="outline"
                className="gap-2"
              >
                <Download className="w-4 h-4" />
                Export PDF
              </Button>
              <Button
                onClick={handleComplete}
                className="bg-gold text-black hover:bg-gold/90 gap-2"
              >
                Complete
              </Button>
            </div>
          ) : (
            <Button
              onClick={handleNext}
              className="bg-gold text-black hover:bg-gold/90 gap-2"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/planner-dashboard")}
            className="text-muted-foreground hover:text-foreground"
          >
            ← Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
}
