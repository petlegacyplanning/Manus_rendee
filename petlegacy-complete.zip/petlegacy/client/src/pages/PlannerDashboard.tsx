import React, { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Plus, Clock, CheckCircle2, Trash2, Lock } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface PlannerProject {
  id: number;
  title: string;
  planTier: string;
  status: "in_progress" | "completed";
  currentStep: number;
  totalSteps: number;
  updatedAt: Date;
}

export default function PlannerDashboard() {
  const [location, setLocation] = useLocation();
  const { data: authUser } = trpc.auth.me.useQuery();

  // Check if user has made a purchase (based on planTier)
  const hasPurchase = authUser?.planTier && authUser.planTier !== 'free';

  const { data: projects = [], isLoading } = trpc.planner.getUserProjects.useQuery(
    { userId: authUser?.id || 0 },
    { enabled: !!authUser?.id && hasPurchase }
  );

  const createProjectMutation = trpc.planner.createProject.useMutation({
    onSuccess: (project: any) => {
      if (project?.id) {
        setLocation(`/planner/${project.id}`);
      }
    },
  });

  const deleteProjectMutation = trpc.planner.deleteProject.useMutation({
    onSuccess: () => {
      trpc.useUtils().planner.getUserProjects.invalidate();
    },
  });

  const handleCreateProject = (tier: string) => {
    if (!authUser?.id) return;
    createProjectMutation.mutate({
      userId: authUser.id,
      planTier: tier,
      title: `${tier.charAt(0).toUpperCase() + tier.slice(1)} Plan - ${new Date().toLocaleDateString()}`,
    });
  };

  const handleDeleteProject = (projectId: number) => {
    if (confirm("Are you sure you want to delete this planner project?")) {
      deleteProjectMutation.mutate({ projectId });
    }
  };

  if (!authUser) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-muted-foreground mb-6">Please log in to access your planner dashboard.</p>
          <Button onClick={() => setLocation("/")} className="bg-gold text-black hover:bg-gold/90">
            Go to Home
          </Button>
        </div>
      </div>
    );
  }

  // Show message if user hasn't purchased
  if (!hasPurchase) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-2">Pet Protection Planner</h1>
            <p className="text-xl text-muted-foreground">Available for plan holders</p>
          </div>

          <Card className="border-gold/30 bg-card/50 max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <Lock className="w-12 h-12 text-gold" />
              </div>
              <CardTitle className="text-2xl">Unlock Your Pet Protection Planner</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-muted-foreground mb-6">
                The Pet Protection Planner is available exclusively to customers who have purchased a plan. 
                Choose your plan tier below to get started.
              </p>
              <Button 
                onClick={() => setLocation("/plans")}
                className="bg-gold text-black hover:bg-gold/90 px-8 h-11"
              >
                View Our Plans
              </Button>
            </CardContent>
          </Card>

          <div className="text-center mt-8">
            <Button
              variant="ghost"
              onClick={() => setLocation("/")}
              className="text-muted-foreground hover:text-foreground"
            >
              ← Back to Home
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-2">Your Pet Protection Planner</h1>
          <p className="text-xl text-muted-foreground">
            Create and manage your pet protection plans. Save your progress and continue anytime.
          </p>
        </div>

        {/* Active Projects */}
        {projects.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-foreground mb-6">Your Projects</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project: PlannerProject) => (
                <Card key={project.id} className="border-border/50 bg-card/50 hover:border-gold/50 transition-colors">
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg mb-1">{project.title}</CardTitle>
                        <p className="text-sm text-muted-foreground capitalize">{project.planTier} Plan</p>
                      </div>
                      {project.status === "completed" && (
                        <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-xs text-muted-foreground">
                          Step {project.currentStep} of {project.totalSteps}
                        </span>
                        <span className="text-xs font-semibold text-gold">
                          {Math.round((project.currentStep / project.totalSteps) * 100)}%
                        </span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-gold to-gold/70 transition-all"
                          style={{ width: `${(project.currentStep / project.totalSteps) * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* Last Updated */}
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
                      <Clock className="w-3 h-3" />
                      <span>Updated {new Date(project.updatedAt).toLocaleDateString()}</span>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <Button
                        onClick={() => setLocation(`/planner/${project.id}`)}
                        className="flex-1 bg-gold text-black hover:bg-gold/90 h-9"
                      >
                        {project.status === "completed" ? "View" : "Continue"}
                      </Button>
                      <Button
                        onClick={() => handleDeleteProject(project.id)}
                        variant="outline"
                        size="sm"
                        className="h-9"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Create New Project */}
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-6">
            {projects.length > 0 ? "Start a New Planner" : "Create Your First Planner"}
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { tier: "basic", name: "Basic Kit", description: "Core planning documents" },
              { tier: "premium", name: "Premium Kit", description: "Enhanced planning tools" },
              { tier: "ultimate", name: "Ultimate Kit", description: "Comprehensive planning" },
              { tier: "platinum", name: "Platinum Service", description: "Complete planning suite" },
            ].map((plan) => (
              <Card
                key={plan.tier}
                className="border-border/50 bg-card/50 hover:border-gold/50 transition-colors cursor-pointer"
                onClick={() => handleCreateProject(plan.tier)}
              >
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="w-5 h-5 text-gold" />
                    <CardTitle className="text-base">{plan.name}</CardTitle>
                  </div>
                  <p className="text-sm text-muted-foreground">{plan.description}</p>
                </CardHeader>
                <CardContent>
                  <Button
                    onClick={() => handleCreateProject(plan.tier)}
                    className="w-full bg-gold text-black hover:bg-gold/90 h-10"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Planner
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-12">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground"
          >
            ← Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
}
