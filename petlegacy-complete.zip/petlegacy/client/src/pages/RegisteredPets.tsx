import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Loader2 } from "lucide-react";
import BackToHome from "@/components/BackToHome";


export default function RegisteredPets() {
  const { data: pets, isLoading } = trpc.registeredPets.list.useQuery();

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Registered Pets</Badge>
          <h1 className="font-serif text-5xl font-bold text-cream mb-4">Registered Pets</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Pets whose owners have completed a Pet Legacy Protection Plan. These pets are protected, planned for, and loved.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 text-gold animate-spin" />
            </div>
          ) : pets && pets.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {pets.map((pet: any) => (
                <div key={pet.id} className="card-luxury rounded-xl p-5 text-center">
                  <div className="w-14 h-14 rounded-full bg-dark-elevated border border-gold/20 flex items-center justify-center mx-auto mb-3">
                    <Star className="w-6 h-6 text-gold/50" />
                  </div>
                  <h3 className="font-serif text-lg font-bold text-cream mb-1">{pet.petName}</h3>
                  {pet.breed && <p className="text-xs text-gold mb-1">{pet.breed}</p>}
                  {pet.city && pet.state && (
                    <p className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                      <MapPin className="w-3 h-3" /> {pet.city}, {pet.state}
                    </p>
                  )}
                  <div className="mt-2">
                    <Badge className="badge-gold text-xs">Protected</Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 card-luxury rounded-2xl">
              <Star className="w-12 h-12 text-gold/30 mx-auto mb-4" />
              <p className="text-muted-foreground mb-2">No registered pets yet.</p>
              <p className="text-sm text-muted-foreground">Complete a Pet Legacy Protection Plan to register your pet.</p>
            </div>
          )}
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
