import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, Users, Award, Target } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface QuizStats {
  totalResponses: number;
  averageScore: number;
  highestScore: number;
  lowestScore: number;
  scoreDistribution: {
    score: number;
    count: number;
    percentage: number;
  }[];
  tierBreakdown: {
    tier: string;
    count: number;
    percentage: number;
    color: string;
  }[];
}

export default function QuizStats() {
  const [location, setLocation] = useLocation();
  const [stats, setStats] = useState<QuizStats | null>(null);
  const [loading, setLoading] = useState(true);

  const { data: statsData } = trpc.quiz.getStats.useQuery();

  useEffect(() => {
    if (statsData) {
      setStats(statsData);
      setLoading(false);
    }
  }, [statsData]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center">
            <p className="text-muted-foreground">Loading statistics...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center">
            <p className="text-muted-foreground">No quiz data available yet.</p>
            <Button
              onClick={() => setLocation("/quiz")}
              className="mt-6 bg-gold text-black hover:bg-gold/90"
            >
              Take the Quiz
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            Community Quiz Insights
          </h1>
          <p className="text-xl text-muted-foreground">
            See how pet owners across the nation are protecting their pets
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <Card className="border-border/50 bg-card/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Users className="w-4 h-4 text-gold" />
                Total Participants
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">
                {stats.totalResponses.toLocaleString()}
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50 bg-card/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-500" />
                Average Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">
                {stats.averageScore.toFixed(1)}/5
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50 bg-card/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Award className="w-4 h-4 text-green-500" />
                Highest Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">
                {stats.highestScore}/5
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50 bg-card/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Target className="w-4 h-4 text-amber-500" />
                Lowest Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">
                {stats.lowestScore}/5
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Score Distribution */}
        <Card className="mb-12 border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Score Distribution</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              How many people scored at each level
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.scoreDistribution.map((item) => (
                <div key={item.score} className="flex items-center gap-4">
                  <div className="w-12 text-right">
                    <p className="font-semibold text-foreground">{item.score}/5</p>
                  </div>
                  <div className="flex-1">
                    <div className="h-8 bg-muted rounded-lg overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-gold to-gold/70 flex items-center justify-end pr-3 transition-all"
                        style={{ width: `${item.percentage}%` }}
                      >
                        {item.percentage > 10 && (
                          <span className="text-xs font-semibold text-black">
                            {item.percentage.toFixed(0)}%
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="w-16 text-right">
                    <p className="text-sm text-muted-foreground">
                      {item.count} {item.count === 1 ? "person" : "people"}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Tier Breakdown */}
        <Card className="mb-12 border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Recommended Plans</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Distribution of quiz-takers by recommended plan tier
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              {stats.tierBreakdown.map((tier) => (
                <div
                  key={tier.tier}
                  className="p-4 rounded-lg border border-border/50 bg-background/50"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-foreground">{tier.tier}</h3>
                    <span
                      className="px-3 py-1 rounded-full text-sm font-medium text-white"
                      style={{ backgroundColor: tier.color }}
                    >
                      {tier.percentage.toFixed(0)}%
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-foreground">
                    {tier.count.toLocaleString()}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {tier.count === 1 ? "person" : "people"} recommended
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Insights */}
        <Card className="mb-12 border-gold/30 bg-gold/5">
          <CardHeader>
            <CardTitle className="text-gold">Key Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex gap-3">
                <span className="text-gold font-bold">•</span>
                <span className="text-foreground">
                  {stats.averageScore >= 3.5
                    ? "Most pet owners are well-prepared for emergencies!"
                    : "Many pet owners could benefit from additional protection planning."}
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-gold font-bold">•</span>
                <span className="text-foreground">
                  {stats.scoreDistribution[4]?.percentage || 0 > 20
                    ? "A significant portion of participants have excellent pet protection plans."
                    : "There's room for improvement in pet protection planning across the community."}
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-gold font-bold">•</span>
                <span className="text-foreground">
                  {stats.totalResponses > 100
                    ? `Join ${stats.totalResponses.toLocaleString()} pet owners taking steps to protect their pets.`
                    : "Be part of a growing community of responsible pet owners."}
                </span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* CTA */}
        <div className="text-center">
          <Button
            onClick={() => setLocation("/quiz")}
            className="bg-gold text-black hover:bg-gold/90 h-12 px-8 text-base font-semibold"
          >
            Take the Quiz & See How You Compare
          </Button>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground"
          >
            ← Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
}
