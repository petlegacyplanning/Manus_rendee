import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ArrowRight } from "lucide-react";
import BackToHome from "@/components/BackToHome";


const categories = [
  {
    label: "Getting Started",
    faqs: [
      { q: "What is Pet Legacy Planning?", a: "Pet Legacy Planning is the most comprehensive pet protection planning platform in the United States. We help pet owners create complete care plans, designate guardians, document medical histories, and ensure their pets are protected no matter what happens." },
      { q: "Do I need an account to get started?", a: "No. Our free basic checklist is available without an account. However, to access the full workspace, save your plan, and use premium features, you'll need to create a free account." },
      { q: "How long does it take to complete a plan?", a: "Most pet owners complete their core plan in 30–60 minutes. You can save your progress and return anytime — there's no rush." },
      { q: "Is Pet Legacy Planning only for dogs and cats?", a: "No. Our platform supports all pets — dogs, cats, birds, reptiles, horses, rabbits, fish, and any other companion animal." },
    ],
  },
  {
    label: "Plans & Pricing",
    faqs: [
      { q: "What's the difference between the plans?", a: "Our Free plan includes a basic checklist. Premium ($34.95) adds the full workspace and single-pet coverage. Ultimate ($69.95) adds multi-pet coverage, the 50-state framework, and lifetime updates. Platinum ($179.95) is our done-for-you service with a dedicated advisor." },
      { q: "Is there a money-back guarantee?", a: "Yes. We offer a 30-day satisfaction guarantee on all paid plans. If you're not completely satisfied, contact us for a full refund — no questions asked." },
      { q: "Can I upgrade my plan later?", a: "Absolutely. You can upgrade from any tier to a higher tier at any time. Your existing data is preserved." },
      { q: "Do you offer affiliate or promo codes?", a: "Yes. We work with rescue organizations, veterinarians, and pet professionals who share affiliate codes with their communities. Enter your code at checkout for a discount." },
    ],
  },
  {
    label: "The Workspace",
    faqs: [
      { q: "What sections are in the workspace?", a: "The workspace includes 8 sections: Pet Profile, Medical History, Medications, Feeding Routine, Behavioral Notes, Guardian Designation, Emergency Contacts, and End-of-Life Wishes." },
      { q: "Can I add multiple pets?", a: "Yes. Premium and above plans support multiple pets. Each pet gets their own complete workspace." },
      { q: "Can I download my plan as a PDF?", a: "Yes. Once your plan is complete, you can download it as a printable PDF to share with guardians, veterinarians, or attorneys." },
      { q: "How do I share my plan with my guardian?", a: "You can download the PDF and share it directly, or provide your guardian with access instructions. We recommend storing a printed copy with your important documents." },
    ],
  },
  {
    label: "Legal & Privacy",
    faqs: [
      { q: "Is my information secure?", a: "Yes. All data is encrypted in transit and at rest. We use industry-standard security practices and never sell or share your personal information." },
      { q: "What is the 50-state framework?", a: "Our Ultimate and Platinum plans include planning language and guidance that accounts for state-specific legal considerations across all 50 US states." },
      { q: "Does Pet Legacy Planning replace an attorney?", a: "No. Our platform is an educational and organizational tool, not legal advice. For formal legal documents like trusts or wills, we recommend consulting a licensed attorney in your state." },
      { q: "Can I delete my account and data?", a: "Yes. You can request account deletion and data removal at any time by contacting our support team." },
    ],
  },
  {
    label: "Community & Features",
    faqs: [
      { q: "What is the Pet Legacy Weekly newsletter?", a: "Pet Legacy Weekly is our free weekly newsletter covering breed spotlights, pet care tips, trivia, community features, memorials, and more. Subscribe free at any time." },
      { q: "How do I submit my pet for a community spotlight?", a: "Visit our Community section and select the spotlight category you'd like to submit to. Fill out the submission form and our team will review it." },
      { q: "What is the Memorial section?", a: "Our Memorial section is a sacred space to honor pets who have passed. You can submit a tribute to your beloved pet and it will be published after review." },
      { q: "How does the adoption and rehoming section work?", a: "Our Adoption section lists pets from approved rescue organizations. Our Rehoming section allows pet owners to list pets in need of new homes, with safety guidance at every step." },
    ],
  },
];

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="card-luxury rounded-xl overflow-hidden">
      <button
        className="w-full text-left p-5 flex items-center justify-between gap-4"
        onClick={() => setOpen(!open)}
      >
        <span className="font-semibold text-cream text-sm">{q}</span>
        <ChevronDown className={`w-4 h-4 text-gold flex-shrink-0 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="px-5 pb-5 border-t border-border">
          <p className="text-sm text-muted-foreground leading-relaxed pt-4">{a}</p>
        </div>
      )}
    </div>
  );
}

export default function FAQ() {
  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Help Center</Badge>
          <h1 className="font-serif text-5xl font-bold text-cream mb-4">Frequently Asked Questions</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Everything you need to know about Pet Legacy Planning. Can't find your answer? Contact us directly.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="container max-w-3xl mx-auto">
          <div className="space-y-12">
            {categories.map((cat) => (
              <div key={cat.label}>
                <h2 className="font-serif text-2xl font-bold text-cream mb-4">{cat.label}</h2>
                <div className="space-y-3">
                  {cat.faqs.map((faq) => (
                    <FAQItem key={faq.q} q={faq.q} a={faq.a} />
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 card-luxury rounded-2xl p-8 text-center">
            <h2 className="font-serif text-2xl font-bold text-cream mb-3">Still Have Questions?</h2>
            <p className="text-muted-foreground mb-6">Our team is here to help. Reach out and we'll get back to you promptly.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-primary text-primary-foreground" asChild>
                <Link href="/contact">Contact Us <ArrowRight className="w-4 h-4 ml-2" /></Link>
              </Button>
              <Button variant="outline" className="border-gold/40 text-gold hover:bg-gold/10" asChild>
                <Link href="/plans">View Plans</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
