import { Badge } from "@/components/ui/badge";
import { AlertCircle } from "lucide-react";
import BackToHome from "@/components/BackToHome";


export default function Disclaimer() {
  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding">
        <div className="container max-w-3xl mx-auto">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Legal</Badge>
          <div className="flex items-center gap-3 mb-4">
            <AlertCircle className="w-8 h-8 text-gold" />
            <h1 className="font-serif text-4xl font-bold text-cream">Legal Disclaimer</h1>
          </div>
          <p className="text-sm text-muted-foreground mb-8">Last updated: January 1, 2025</p>

          <div className="space-y-6">
            <div className="card-luxury rounded-xl p-6 border-gold/20">
              <h2 className="font-serif text-lg font-bold text-cream mb-3">Not Legal Advice</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                The information provided on PetLegacyPlanning.com is for general educational and organizational purposes only. Nothing on this platform constitutes legal advice, and no attorney-client relationship is formed by your use of this platform. For formal legal documents — including but not limited to pet trusts, wills, powers of attorney, or guardianship designations — please consult a licensed attorney in your state.
              </p>
            </div>

            <div className="card-luxury rounded-xl p-6">
              <h2 className="font-serif text-lg font-bold text-cream mb-3">Not Veterinary Advice</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                The health and medical information provided on this platform is for general educational purposes only. It is not intended to be a substitute for professional veterinary advice, diagnosis, or treatment. Always seek the advice of your veterinarian with any questions you may have regarding your pet's health.
              </p>
            </div>

            <div className="card-luxury rounded-xl p-6">
              <h2 className="font-serif text-lg font-bold text-cream mb-3">50-State Framework Disclaimer</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Our 50-state framework provides general planning language and guidance that is designed to be broadly applicable across all US states. However, laws vary significantly by state and locality. The framework is not a substitute for state-specific legal advice. We recommend consulting a local attorney to ensure your pet protection plan complies with the specific laws of your state.
              </p>
            </div>

            <div className="card-luxury rounded-xl p-6">
              <h2 className="font-serif text-lg font-bold text-cream mb-3">Community Content Disclaimer</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Community submissions, including adoption listings, rehoming listings, memorials, and spotlights, are submitted by users and reviewed by our moderation team. We make reasonable efforts to verify submissions but cannot guarantee the accuracy of user-submitted content. Pet Legacy Planning is not responsible for the actions of third parties, including adopters or rehomers.
              </p>
            </div>

            <div className="card-luxury rounded-xl p-6">
              <h2 className="font-serif text-lg font-bold text-cream mb-3">Affiliate & Partner Disclaimer</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Pet Legacy Planning may have affiliate relationships with certain organizations, businesses, or individuals. Affiliate codes and partnerships are disclosed where applicable. We only partner with organizations we believe provide genuine value to our community.
              </p>
            </div>

            <div className="card-luxury rounded-xl p-6">
              <h2 className="font-serif text-lg font-bold text-cream mb-3">Accuracy of Information</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                While we strive to provide accurate and up-to-date information, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability, or availability with respect to the platform or the information contained on the platform for any purpose.
              </p>
            </div>
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
