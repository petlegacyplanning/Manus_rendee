import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Shield, Star, ArrowRight, Tag, Loader2 } from "lucide-react";
import { toast } from "sonner";
import BackToHome from "@/components/BackToHome";


const tiers = [
  {
    id: "free",
    name: "Free Basic Checklist",
    price: 0,
    priceDisplay: "Free",
    tagline: "Start here. No credit card required.",
    features: [
      "Basic pet care checklist",
      "Emergency contact template",
      "Downloadable PDF",
      "Email support",
    ],
    notIncluded: [
      "Online workspace",
      "Guardian designation forms",
      "Medical history templates",
      "Multi-pet coverage",
    ],
    cta: "Download Free",
    highlight: false,
    color: "border-border",
  },
  {
    id: "premium",
    name: "Premium Kit",
    price: 3495,
    priceDisplay: "$34.95",
    tagline: "A comprehensive kit that goes far beyond the competition.",
    features: [
      "Full care documentation system",
      "Guardian designation forms",
      "Medical history templates",
      "Emergency planning guide",
      "Printable workbook",
      "Online workspace access",
      "Single pet coverage",
      "Email support",
    ],
    notIncluded: [
      "Multi-pet coverage",
      "50-state legal framework",
      "Lifetime updates",
      "Done-for-you service",
    ],
    cta: "Get Premium",
    highlight: false,
    color: "border-border",
  },
  {
    id: "ultimate",
    name: "Ultimate Kit",
    price: 6995,
    priceDisplay: "$69.95",
    tagline: "The complete pet protection system — nothing left out.",
    features: [
      "Everything in Premium",
      "Multi-pet coverage (unlimited)",
      "Legal planning language",
      "50-state framework",
      "Lifetime updates",
      "Priority support",
      "Community access",
      "Advanced workspace features",
      "Printable & digital formats",
    ],
    notIncluded: [
      "Done-for-you service",
      "Dedicated advisor",
    ],
    cta: "Get Ultimate",
    highlight: true,
    color: "border-gold/40",
  },
  {
    id: "platinum",
    name: "Platinum Done-For-You",
    price: 17995,
    priceDisplay: "$179.95",
    tagline: "We complete your entire plan for you — live human help included.",
    features: [
      "Everything in Ultimate",
      "Done-for-you plan completion",
      "Dedicated pet protection advisor",
      "Custom documentation",
      "Final review & delivery",
      "Platinum client portal",
      "White-glove service",
      "Priority phone & email support",
    ],
    notIncluded: [],
    cta: "Get Platinum",
    highlight: false,
    color: "border-burgundy-light/40",
  },
];

const faq = [
  { q: "Is my information secure?", a: "Yes. All data is encrypted and stored securely. We never sell or share your personal information." },
  { q: "Can I upgrade my plan later?", a: "Absolutely. You can upgrade from any tier to a higher tier at any time. Your existing data is preserved." },
  { q: "Does the free checklist require an account?", a: "No. The free checklist is available as a direct download with no account required." },
  { q: "What is the 50-state framework?", a: "Our Ultimate and Platinum plans include planning language and guidance that works across all 50 US states, accounting for state-specific considerations." },
  { q: "What does 'Done-For-You' mean in Platinum?", a: "Our team works with you directly to complete your entire pet protection plan. You provide the information, we do the work." },
  { q: "Is there a money-back guarantee?", a: "Yes. We offer a 30-day satisfaction guarantee on all paid plans. If you're not satisfied, contact us for a full refund." },
];

export default function Plans() {
  const { isAuthenticated } = useAuth();
  const [promoCode, setPromoCode] = useState("");
  const [promoResult, setPromoResult] = useState<{ valid: boolean; discountPct: number } | null>(null);
  const [selectedTier, setSelectedTier] = useState<string | null>(null);
  const [purchasing, setPurchasing] = useState(false);

  const validatePromo = trpc.plans.validatePromo.useMutation({
    onSuccess: (data) => {
      setPromoResult(data);
      if (data.valid) {
        toast.success(`Promo code applied! ${data.discountPct}% off.`);
      } else {
        toast.error("Invalid or expired promo code.");
      }
    },
  });

  const purchase = trpc.plans.purchase.useMutation({
    onSuccess: () => {
      toast.success("Plan activated! Welcome to Pet Legacy Planning.");
      setPurchasing(false);
    },
    onError: () => {
      toast.error("Purchase failed. Please try again.");
      setPurchasing(false);
    },
  });

  const handlePurchase = (tierId: string) => {
    if (tierId === "free") {
      window.open("/downloads/pet-legacy-free-checklist.pdf", "_blank");
      return;
    }
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }
    setPurchasing(true);
    setSelectedTier(tierId);
    purchase.mutate({
      tier: tierId as "premium" | "ultimate" | "platinum",
      promoCode: promoResult?.valid ? promoCode : undefined,
    });
  };

  return (
    <div className="min-h-screen bg-background pt-24">
      {/* Header */}
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Protection Plans</Badge>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-cream mb-6">
            Choose Your Level of Protection
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            From a free checklist to a fully done-for-you platinum service. Every plan is built with the same commitment to quality and compassion.
          </p>

          {/* Promo Code */}
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="flex gap-2 max-w-sm w-full">
              <Input
                placeholder="Promo or affiliate code"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                className="bg-input border-border"
              />
              <Button
                variant="outline"
                className="border-gold/40 text-gold hover:bg-gold/10 flex-shrink-0"
                onClick={() => validatePromo.mutate({ code: promoCode })}
                disabled={!promoCode.trim() || validatePromo.isPending}
              >
                <Tag className="w-4 h-4 mr-1" />
                Apply
              </Button>
            </div>
          </div>
          {promoResult?.valid && (
            <p className="text-sm text-gold font-medium mb-8">
              ✓ {promoResult.discountPct}% discount applied to your order
            </p>
          )}
        </div>
      </section>

      {/* Plans Grid */}
      <section className="section-padding">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {tiers.map((tier) => {
              const discountedPrice = promoResult?.valid
                ? tier.price - Math.round(tier.price * promoResult.discountPct / 100 * 100) / 100
                : tier.price;

              return (
                <div
                  key={tier.id}
                  className={`relative rounded-2xl border-2 ${tier.color} bg-card flex flex-col p-6 ${
                    tier.highlight ? "glow-gold" : ""
                  }`}
                >
                  {tier.highlight && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <span className="badge-gold px-3 py-1 rounded-full text-xs font-semibold">Most Popular</span>
                    </div>
                  )}

                  <div className="mb-6">
                    <h2 className="font-serif text-xl font-bold text-cream mb-2">{tier.name}</h2>
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className="font-serif text-4xl font-bold text-gold">
                        {tier.price === 0 ? "Free" : `$${discountedPrice}`}
                      </span>
                      {promoResult?.valid && tier.price > 0 && (
                        <span className="text-muted-foreground line-through text-sm">{tier.priceDisplay}</span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{tier.tagline}</p>
                  </div>

                  <div className="flex-1 space-y-2 mb-6">
                    {tier.features.map((f) => (
                      <div key={f} className="flex items-start gap-2 text-sm text-foreground/80">
                        <CheckCircle className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                        {f}
                      </div>
                    ))}
                    {tier.notIncluded.map((f) => (
                      <div key={f} className="flex items-start gap-2 text-sm text-muted-foreground/50">
                        <div className="w-4 h-4 flex-shrink-0 mt-0.5 flex items-center justify-center">
                          <div className="w-3 h-px bg-muted-foreground/30" />
                        </div>
                        {f}
                      </div>
                    ))}
                  </div>

                  <Button
                    className={`w-full font-semibold ${
                      tier.highlight
                        ? "bg-gold text-background hover:opacity-90"
                        : "bg-primary text-primary-foreground hover:opacity-90"
                    }`}
                    onClick={() => handlePurchase(tier.id)}
                    disabled={purchasing && selectedTier === tier.id}
                  >
                    {purchasing && selectedTier === tier.id ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : null}
                    {tier.cta}
                  </Button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Guarantee */}
      <section className="py-12 bg-dark-surface">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <Shield className="w-12 h-12 text-gold mx-auto mb-4" />
            <h2 className="font-serif text-2xl font-bold text-cream mb-3">30-Day Satisfaction Guarantee</h2>
            <p className="text-muted-foreground">
              We stand behind every plan we offer. If you're not completely satisfied within 30 days of purchase, contact us for a full refund — no questions asked.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="section-padding">
        <div className="container max-w-3xl mx-auto">
          <h2 className="font-serif text-3xl font-bold text-cream text-center mb-10">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {faq.map((item) => (
              <div key={item.q} className="card-luxury rounded-xl p-6">
                <h3 className="font-semibold text-cream mb-2">{item.q}</h3>
                <p className="text-sm text-muted-foreground">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
