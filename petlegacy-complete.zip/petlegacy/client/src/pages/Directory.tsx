import { useState } from "react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { MapPin, Search, ChevronRight, Shield, Heart, Home, Stethoscope, BookOpen, Users, Star, Phone } from "lucide-react";
import BackToHome from "@/components/BackToHome";


const STATES = [
  "Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware",
  "Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky",
  "Louisiana","Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi",
  "Missouri","Montana","Nebraska","Nevada","New Hampshire","New Jersey","New Mexico",
  "New York","North Carolina","North Dakota","Ohio","Oklahoma","Oregon","Pennsylvania",
  "Rhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah","Vermont",
  "Virginia","Washington","West Virginia","Wisconsin","Wyoming",
];

const STATE_ABBREVS: Record<string, string> = {
  "Alabama":"AL","Alaska":"AK","Arizona":"AZ","Arkansas":"AR","California":"CA",
  "Colorado":"CO","Connecticut":"CT","Delaware":"DE","Florida":"FL","Georgia":"GA",
  "Hawaii":"HI","Idaho":"ID","Illinois":"IL","Indiana":"IN","Iowa":"IA","Kansas":"KS",
  "Kentucky":"KY","Louisiana":"LA","Maine":"ME","Maryland":"MD","Massachusetts":"MA",
  "Michigan":"MI","Minnesota":"MN","Mississippi":"MS","Missouri":"MO","Montana":"MT",
  "Nebraska":"NE","Nevada":"NV","New Hampshire":"NH","New Jersey":"NJ","New Mexico":"NM",
  "New York":"NY","North Carolina":"NC","North Dakota":"ND","Ohio":"OH","Oklahoma":"OK",
  "Oregon":"OR","Pennsylvania":"PA","Rhode Island":"RI","South Carolina":"SC",
  "South Dakota":"SD","Tennessee":"TN","Texas":"TX","Utah":"UT","Vermont":"VT",
  "Virginia":"VA","Washington":"WA","West Virginia":"WV","Wisconsin":"WI","Wyoming":"WY",
};

const CATEGORIES = [
  { icon: Shield, label: "Pet Planning Attorneys", desc: "Estate planning attorneys specializing in pet trusts and guardianship documents." },
  { icon: Stethoscope, label: "Veterinary Clinics", desc: "Licensed veterinary practices accepting new patients across all 50 states." },
  { icon: Heart, label: "Rescue Organizations", desc: "Approved rescue organizations and adoption centers in your state." },
  { icon: Home, label: "Boarding & Kennels", desc: "Licensed boarding facilities, kennels, and pet hotels." },
  { icon: Users, label: "Pet Sitters & Walkers", desc: "Certified pet sitters, dog walkers, and in-home care providers." },
  { icon: BookOpen, label: "Training Schools", desc: "Certified dog trainers, obedience schools, and behavior specialists." },
  { icon: Star, label: "Grooming Services", desc: "Professional groomers and mobile grooming services." },
  { icon: Phone, label: "Emergency Vet Clinics", desc: "24-hour emergency and specialty veterinary hospitals." },
];

const FEATURED_STATES = [
  "California","Texas","Florida","New York","Illinois","Pennsylvania",
  "Ohio","Georgia","North Carolina","Michigan",
];

export default function Directory() {
  const [search, setSearch] = useState("");
  const [selectedState, setSelectedState] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredStates = STATES.filter((s) =>
    s.toLowerCase().includes(search.toLowerCase())
  );

  const stateSlug = (state: string) => state.toLowerCase().replace(/\s+/g, "-");

  return (
    <div className="min-h-screen bg-background pt-24">
      {/* Hero */}
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">National Directory</Badge>
          <h1 className="font-serif text-5xl font-bold text-cream mb-4">
            Pet Legacy National Directory
          </h1>
          <p className="text-muted-foreground max-w-3xl mx-auto text-lg leading-relaxed mb-8">
            The most comprehensive directory of pet-related services, professionals, and resources across all 50 states. Find attorneys, veterinarians, rescues, trainers, groomers, and more — organized by state and category.
          </p>
          <div className="flex items-center gap-3 max-w-xl mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by state name…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 bg-input border-border"
              />
            </div>
            <Button className="bg-primary text-primary-foreground">Search</Button>
          </div>
        </div>
      </section>

      {/* Service Categories */}
      <section className="section-padding">
        <div className="container">
          <div className="text-center mb-10">
            <h2 className="font-serif text-3xl font-bold text-cream mb-3">Browse by Service Category</h2>
            <p className="text-muted-foreground">Select a category to find providers in your state.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {CATEGORIES.map(({ icon: Icon, label, desc }) => (
              <div
                key={label}
                className={`card-luxury rounded-xl p-5 cursor-pointer hover:border-gold/40 transition-all group ${selectedCategory === label ? "border-gold/50 bg-gold/5" : ""}`}
                onClick={() => setSelectedCategory(selectedCategory === label ? null : label)}
              >
                <Icon className={`w-7 h-7 mb-3 transition-colors ${selectedCategory === label ? "text-gold" : "text-gold/60 group-hover:text-gold"}`} />
                <h3 className="font-semibold text-sm text-cream mb-1">{label}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured States */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="text-center mb-10">
            <h2 className="font-serif text-3xl font-bold text-cream mb-3">Featured State Directories</h2>
            <p className="text-muted-foreground">Our most-visited state directories with the most complete listings.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
            {FEATURED_STATES.map((state) => (
              <Link key={state} href={`/directory/${stateSlug(state)}`}>
                <div className="card-luxury rounded-xl p-4 text-center hover:border-gold/40 transition-all cursor-pointer group">
                  <MapPin className="w-5 h-5 text-gold mx-auto mb-2 group-hover:scale-110 transition-transform" />
                  <p className="text-sm font-semibold text-cream">{state}</p>
                  <p className="text-xs text-muted-foreground mt-1">{STATE_ABBREVS[state]}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* All 50 States */}
      <section className="section-padding">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-serif text-3xl font-bold text-cream">All 50 States</h2>
            {search && (
              <p className="text-sm text-muted-foreground">
                Showing {filteredStates.length} of 50 states
              </p>
            )}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {filteredStates.map((state) => (
              <Link key={state} href={`/directory/${stateSlug(state)}`}>
                <div
                  className={`flex items-center justify-between px-4 py-3 rounded-xl border cursor-pointer transition-all hover:border-gold/40 hover:bg-gold/5 group ${selectedState === state ? "border-gold/50 bg-gold/5" : "card-luxury"}`}
                  onClick={() => setSelectedState(state)}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-gold/70 w-6">{STATE_ABBREVS[state]}</span>
                    <span className="text-sm text-foreground/80 group-hover:text-cream transition-colors">{state}</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-gold/40 group-hover:text-gold transition-colors" />
                </div>
              </Link>
            ))}
          </div>
          {filteredStates.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              No states match your search. Try a different name.
            </div>
          )}
        </div>
      </section>

      {/* Partner CTA */}
      <section className="section-padding bg-dark-surface">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center card-luxury rounded-2xl p-10">
            <Badge className="badge-gold mb-6 px-4 py-1.5">For Professionals</Badge>
            <h2 className="font-serif text-3xl font-bold text-cream mb-4">
              List Your Practice or Organization
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Are you a veterinarian, attorney, rescue organization, trainer, or other pet professional? Apply to be listed in the Pet Legacy National Directory and reach thousands of pet families in your state.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-primary text-primary-foreground font-semibold" asChild>
                <Link href="/contact">Apply for Directory Listing</Link>
              </Button>
              <Button variant="outline" className="border-gold/40 text-gold hover:bg-gold/10" asChild>
                <Link href="/plans">Become a Verified Partner</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
