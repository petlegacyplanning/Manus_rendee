import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mail, Phone, CheckCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import BackToHome from "@/components/BackToHome";


const subjects = [
  "General Inquiry",
  "Technical Support",
  "Billing & Plans",
  "Platinum Service",
  "Affiliate Partnership",
  "Rescue Organization Partnership",
  "Media & Press",
  "Other",
];

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const contactMutation = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Message sent! We'll get back to you within 1–2 business days.");
    },
    onError: () => toast.error("Failed to send message. Please try again."),
  });

  const handleSubmit = () => {
    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      toast.error("Please fill in all required fields.");
      return;
    }
    contactMutation.mutate(form);
  };

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Contact Us</Badge>
          <h1 className="font-serif text-5xl font-bold text-cream mb-4">Get in Touch</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            We're here to help. Reach out with any questions, partnership inquiries, or support requests.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            {/* Contact Info */}
            <div>
              <h2 className="font-serif text-2xl font-bold text-cream mb-6">Contact Information</h2>
              <div className="space-y-6">
                <div className="card-luxury rounded-xl p-5 flex items-start gap-4">
                  <Mail className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-cream text-sm mb-1">General Support</p>
                    <a href="mailto:support@petlegacyplanning.com" className="text-muted-foreground hover:text-gold text-sm">support@petlegacyplanning.com</a>
                  </div>
                </div>
                <div className="card-luxury rounded-xl p-5 flex items-start gap-4">
                  <Mail className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-cream text-sm mb-1">Platinum Service</p>
                    <a href="mailto:platinum@petlegacyplanning.com" className="text-muted-foreground hover:text-gold text-sm">platinum@petlegacyplanning.com</a>
                  </div>
                </div>
                <div className="card-luxury rounded-xl p-5 flex items-start gap-4">
                  <Mail className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-cream text-sm mb-1">Rescue Partnerships</p>
                    <a href="mailto:rescues@petlegacyplanning.com" className="text-muted-foreground hover:text-gold text-sm">rescues@petlegacyplanning.com</a>
                  </div>
                </div>
                <div className="card-luxury rounded-xl p-5 flex items-start gap-4">
                  <Phone className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-cream text-sm mb-1">Phone Support</p>
                    <p className="text-muted-foreground text-sm">Available for Platinum clients</p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <h3 className="font-serif text-lg font-bold text-cream mb-3">Response Times</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>General inquiries: 1–2 business days</p>
                  <p>Technical support: 1 business day</p>
                  <p>Platinum clients: Within 24 hours</p>
                </div>
              </div>
            </div>

            {/* Form */}
            <div>
              <h2 className="font-serif text-2xl font-bold text-cream mb-6">Send a Message</h2>
              {submitted ? (
                <div className="card-luxury rounded-2xl p-8 text-center">
                  <CheckCircle className="w-12 h-12 text-gold mx-auto mb-4" />
                  <h3 className="font-serif text-xl font-bold text-cream mb-2">Message Sent!</h3>
                  <p className="text-muted-foreground">We'll get back to you within 1–2 business days.</p>
                </div>
              ) : (
                <div className="card-luxury rounded-2xl p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Name *</label>
                      <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-input border-border" placeholder="Jane Smith" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Email *</label>
                      <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="bg-input border-border" placeholder="jane@example.com" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Subject</label>
                    <Select value={form.subject} onValueChange={(v) => setForm({ ...form, subject: v })}>
                      <SelectTrigger className="bg-input border-border">
                        <SelectValue placeholder="Select a subject" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        {subjects.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Message *</label>
                    <Textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="bg-input border-border" placeholder="Tell us how we can help..." rows={5} />
                  </div>
                  <Button className="w-full bg-primary text-primary-foreground" onClick={handleSubmit} disabled={contactMutation.isPending}>
                    {contactMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Mail className="w-4 h-4 mr-2" />}
                    Send Message
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
