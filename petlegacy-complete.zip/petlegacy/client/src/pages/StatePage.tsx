import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, CheckCircle, ArrowRight, MapPin } from "lucide-react";
import BackToHome from "@/components/BackToHome";


const STATE_NAMES: Record<string, string> = {
  AL: "Alabama", AK: "Alaska", AZ: "Arizona", AR: "Arkansas", CA: "California",
  CO: "Colorado", CT: "Connecticut", DE: "Delaware", FL: "Florida", GA: "Georgia",
  HI: "Hawaii", ID: "Idaho", IL: "Illinois", IN: "Indiana", IA: "Iowa",
  KS: "Kansas", KY: "Kentucky", LA: "Louisiana", ME: "Maine", MD: "Maryland",
  MA: "Massachusetts", MI: "Michigan", MN: "Minnesota", MS: "Mississippi", MO: "Missouri",
  MT: "Montana", NE: "Nebraska", NV: "Nevada", NH: "New Hampshire", NJ: "New Jersey",
  NM: "New Mexico", NY: "New York", NC: "North Carolina", ND: "North Dakota", OH: "Ohio",
  OK: "Oklahoma", OR: "Oregon", PA: "Pennsylvania", RI: "Rhode Island", SC: "South Carolina",
  SD: "South Dakota", TN: "Tennessee", TX: "Texas", UT: "Utah", VT: "Vermont",
  VA: "Virginia", WA: "Washington", WV: "West Virginia", WI: "Wisconsin", WY: "Wyoming",
};

const MAJOR_CITIES: Record<string, string[]> = {
  CA: ["Los Angeles", "San Francisco", "San Diego", "Sacramento", "San Jose"],
  TX: ["Houston", "Dallas", "Austin", "San Antonio", "Fort Worth"],
  FL: ["Miami", "Orlando", "Tampa", "Jacksonville", "Fort Lauderdale"],
  NY: ["New York City", "Buffalo", "Albany", "Rochester", "Syracuse"],
  IL: ["Chicago", "Springfield", "Naperville", "Rockford", "Peoria"],
  PA: ["Philadelphia", "Pittsburgh", "Allentown", "Erie", "Reading"],
  OH: ["Columbus", "Cleveland", "Cincinnati", "Toledo", "Akron"],
  GA: ["Atlanta", "Savannah", "Augusta", "Columbus", "Macon"],
  NC: ["Charlotte", "Raleigh", "Greensboro", "Durham", "Winston-Salem"],
  MI: ["Detroit", "Grand Rapids", "Lansing", "Ann Arbor", "Flint"],
};

const features = [
  "Complete pet care documentation",
  "Guardian designation forms",
  "Medical history templates",
  "50-state legal framework",
  "Emergency planning guide",
  "Lifetime updates",
];

export default function StatePage() {
  const [, params] = useRoute("/pet-protection/:state");
  const stateCode = (params?.state ?? "").toUpperCase();
  const stateName = STATE_NAMES[stateCode] ?? stateCode;
  const cities = MAJOR_CITIES[stateCode] ?? [];

  if (!STATE_NAMES[stateCode]) {
    return (
      <div className="min-h-screen bg-background pt-24 flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">State not found.</p>
          <Button className="mt-4" asChild><Link href="/plans">View Plans</Link></Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
            <Link href="/" className="hover:text-gold">Home</Link>
            <span>/</span>
            <span>Pet Protection</span>
            <span>/</span>
            <span className="text-gold">{stateName}</span>
          </div>
          <Badge className="badge-gold mb-4 px-4 py-1.5">
            <MapPin className="w-3 h-3 mr-1" />
            {stateName}
          </Badge>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-cream mb-6">
            Pet Protection Planning in {stateName}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-8">
            Pet Legacy Planning serves pet families across {stateName}. Our comprehensive pet protection system includes planning language and guidance that works within {stateName}'s legal framework.
          </p>
          <Button size="lg" className="bg-primary text-primary-foreground font-bold px-10 py-6" asChild>
            <Link href="/plans">
              Start Your {stateName} Plan <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Why Pet Protection Matters */}
      <section className="section-padding">
        <div className="container max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="font-serif text-3xl font-bold text-cream mb-4">
                Why Pet Families in {stateName} Need a Plan
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Across {stateName}, thousands of pets end up in shelters each year not because their owners stopped loving them, but because there was no plan in place when something unexpected happened.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                A Pet Legacy Protection Plan ensures your pets are cared for exactly as you intend — no matter what happens. Our system is designed to work with {stateName}'s specific legal and regulatory framework.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Whether you're in {cities[0] ?? stateName} or anywhere else in the state, our platform gives you the tools to protect the pets you love.
              </p>
            </div>
            <div className="space-y-3">
              <h3 className="font-serif text-xl font-bold text-cream mb-4">What's Included</h3>
              {features.map((f) => (
                <div key={f} className="flex items-center gap-3 card-luxury rounded-xl p-3">
                  <CheckCircle className="w-4 h-4 text-gold flex-shrink-0" />
                  <span className="text-sm text-foreground/80">{f}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Cities */}
      {cities.length > 0 && (
        <section className="section-padding bg-dark-surface">
          <div className="container">
            <h2 className="font-serif text-2xl font-bold text-cream mb-6 text-center">
              Serving Pet Families Across {stateName}
            </h2>
            <div className="flex flex-wrap gap-3 justify-center">
              {cities.map((city) => (
                <Link key={city} href={`/pet-protection/${stateCode.toLowerCase()}/${city.toLowerCase().replace(/\s+/g, "-")}`}>
                  <Badge variant="outline" className="border-gold/30 text-gold/70 hover:border-gold hover:text-gold cursor-pointer px-4 py-2 text-sm">
                    <MapPin className="w-3 h-3 mr-1" />
                    {city}, {stateCode}
                  </Badge>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="section-padding">
        <div className="container text-center">
          <Shield className="w-12 h-12 text-gold mx-auto mb-6" />
          <h2 className="font-serif text-3xl font-bold text-cream mb-4">
            Protect Your Pets in {stateName} Today
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Start with our free checklist or choose a complete protection plan. Your pets deserve the best.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary text-primary-foreground font-bold" asChild>
              <Link href="/plans">View Protection Plans</Link>
            </Button>
            <Button size="lg" variant="outline" className="border-gold/40 text-gold hover:bg-gold/10" asChild>
              <Link href="/how-it-works">How It Works</Link>
            </Button>
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
