import { Badge } from "@/components/ui/badge";
import BackToHome from "@/components/BackToHome";


export default function Terms() {
  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding">
        <div className="container max-w-3xl mx-auto">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Legal</Badge>
          <h1 className="font-serif text-4xl font-bold text-cream mb-4">Terms of Service</h1>
          <p className="text-sm text-muted-foreground mb-8">Last updated: January 1, 2025</p>

          <div className="space-y-6">
            {[
              { title: "1. Acceptance of Terms", body: "By accessing and using PetLegacyPlanning.com, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service." },
              { title: "2. Description of Service", body: "Pet Legacy Planning provides an online platform for creating, storing, and managing pet protection plans. Our service includes educational content, planning tools, community features, and related services. We are an organizational and educational tool — not a legal, veterinary, or financial advisor." },
              { title: "3. Not Legal Advice", body: "The information and tools provided on this platform are for educational and organizational purposes only. Nothing on this platform constitutes legal advice. For formal legal documents such as trusts, wills, or powers of attorney, please consult a licensed attorney in your state." },
              { title: "4. User Accounts", body: "You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account." },
              { title: "5. User Content", body: "By submitting content to our platform (including community submissions, memorials, and listings), you grant us a non-exclusive, worldwide, royalty-free license to use, display, and distribute that content in connection with our services. You represent that you have the right to submit such content." },
              { title: "6. Prohibited Uses", body: "You may not use our service for any unlawful purpose, to solicit others to perform unlawful acts, to violate any regulations, rules, laws, or local ordinances, to infringe upon or violate our intellectual property rights or the intellectual property rights of others, to harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate." },
              { title: "7. Payment Terms", body: "Paid plans are billed as one-time purchases. We offer a 30-day satisfaction guarantee. Refund requests must be submitted within 30 days of purchase. Refunds are processed within 5–10 business days." },
              { title: "8. Disclaimer of Warranties", body: "This service is provided 'as is' without any representations or warranties, express or implied. We make no representations or warranties in relation to this platform or the information and materials provided on this platform." },
              { title: "9. Limitation of Liability", body: "In no event shall Pet Legacy Planning, its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses." },
              { title: "10. Governing Law", body: "These Terms shall be governed and construed in accordance with the laws of the United States, without regard to its conflict of law provisions." },
              { title: "11. Changes to Terms", body: "We reserve the right to modify or replace these Terms at any time. If a revision is material, we will provide at least 30 days' notice prior to any new terms taking effect." },
              { title: "12. Contact", body: "If you have any questions about these Terms, please contact us at legal@petlegacyplanning.com." },
            ].map(({ title, body }) => (
              <div key={title} className="card-luxury rounded-xl p-6">
                <h2 className="font-serif text-lg font-bold text-cream mb-3">{title}</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
