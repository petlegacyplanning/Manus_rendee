import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, Download, Plus, Trash2 } from "lucide-react";
import BackToHome from "@/components/BackToHome";
import { usStatesMajorCities, usStates } from "@shared/usStatesMajorCities";
import { petLawReferences } from "@shared/petLawReferences";

interface StateCompliance {
  state: string;
  stateLaws: string;
  cities: Record<string, string>;
  customCity: string;
  customCityName: string;
  animalControlContact: string;
}

export default function CompliancePlanner() {
  const [selectedState, setSelectedState] = useState<string | null>(null);
  const [complianceData, setComplianceData] = useState<Record<string, StateCompliance>>({});
  const [expandedStates, setExpandedStates] = useState<Set<string>>(new Set());

  const toggleState = (state: string) => {
    const newExpanded = new Set(expandedStates);
    if (newExpanded.has(state)) {
      newExpanded.delete(state);
    } else {
      newExpanded.add(state);
    }
    setExpandedStates(newExpanded);
  };

  const updateStateData = (state: string, field: string, value: string) => {
    setComplianceData((prev) => ({
      ...prev,
      [state]: {
        ...prev[state],
        state,
        [field]: value,
      },
    }));
  };

  const updateCityData = (state: string, city: string, value: string) => {
    setComplianceData((prev) => ({
      ...prev,
      [state]: {
        ...prev[state],
        state,
        cities: {
          ...prev[state]?.cities,
          [city]: value,
        },
      },
    }));
  };

  const downloadPDF = () => {
    // Simple text-based PDF generation
    let content = "NATIONAL PET LAW & CITY COMPLIANCE PLANNER\n\n";
    
    Object.entries(complianceData).forEach(([state, data]) => {
      if (data.stateLaws || Object.keys(data.cities || {}).length > 0) {
        content += `\n${state.toUpperCase()}\n`;
        content += "=".repeat(state.length) + "\n\n";
        
        if (data.stateLaws) {
          content += `State Pet Laws:\n${data.stateLaws}\n\n`;
        }
        
        Object.entries(data.cities || {}).forEach(([city, notes]) => {
          if (notes) {
            content += `${city}:\n${notes}\n\n`;
          }
        });
        
        if (data.customCityName && data.customCity) {
          content += `${data.customCityName}:\n${data.customCity}\n\n`;
        }
        
        if (data.animalControlContact) {
          content += `Animal Control Contact: ${data.animalControlContact}\n\n`;
        }
      }
    });

    // Create blob and download
    const blob = new Blob([content], { type: "text/plain" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "pet-compliance-planner.txt";
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="badge-gold mb-4">Free Resource</Badge>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-cream mb-4">
            National Pet Law & City Compliance Planner
          </h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-8">
            Record your state laws and important city ordinances that may affect pet ownership and care. 
            This free resource helps you understand local regulations for all 50 states and major cities.
          </p>
          <Button
            onClick={downloadPDF}
            className="bg-gold text-black hover:bg-gold/90"
          >
            <Download className="w-4 h-4 mr-2" />
            Download as Text File
          </Button>
        </div>

        {/* States Grid */}
        <div className="space-y-4">
          {usStates.map((state: string) => {
            const majorCities = usStatesMajorCities[state] || [];
            const data = complianceData[state] || {};
            const isExpanded = expandedStates.has(state);

            return (
              <Card key={state} className="border-border/50 bg-card/50">
                <button
                  onClick={() => toggleState(state)}
                  className="w-full text-left p-6 flex items-center justify-between gap-4 hover:bg-card/70 transition"
                >
                  <div>
                    <h2 className="text-2xl font-bold text-cream">{state}</h2>
                    <p className="text-sm text-muted-foreground">
                      {majorCities.length} major cities
                    </p>
                  </div>
                  <ChevronDown
                    className={`w-6 h-6 text-gold transition-transform ${
                      isExpanded ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {isExpanded && (
                  <CardContent className="space-y-6 border-t border-border/50 pt-6">
                    {/* Pet Trust Law Reference */}
                    {petLawReferences[state] && (
                      <div className="bg-gold/10 border border-gold/30 rounded-lg p-4">
                        <h4 className="text-sm font-semibold text-gold mb-2">Pet Trust Law Reference</h4>
                        <p className="text-sm text-cream font-mono mb-2">{petLawReferences[state].petTrustLaw}</p>
                        <p className="text-sm text-muted-foreground">{petLawReferences[state].notes}</p>
                      </div>
                    )}

                    {/* State Laws */}
                    <div>
                      <label className="block text-sm font-semibold text-cream mb-2">
                        State Pet Laws Notes
                      </label>
                      <textarea
                        value={data.stateLaws || ""}
                        onChange={(e) => updateStateData(state, "stateLaws", e.target.value)}
                        placeholder="Record important state-level pet laws and regulations..."
                        className="w-full h-24 bg-background/50 border border-border/50 rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:border-gold/50"
                      />
                    </div>

                    {/* Major Cities */}
                    <div>
                      <h3 className="text-lg font-semibold text-cream mb-4">Major Cities</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {majorCities.map((city: string) => (
                          <div key={city}>
                            <label className="block text-sm font-medium text-muted-foreground mb-1">
                              {city} Pet Regulations
                            </label>
                            <textarea
                              value={data.cities?.[city] || ""}
                              onChange={(e) => updateCityData(state, city, e.target.value)}
                              placeholder={`${city} regulations...`}
                              className="w-full h-16 bg-background/50 border border-border/50 rounded-lg px-3 py-2 text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:border-gold/50"
                            />
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Custom City */}
                    <div className="border-t border-border/50 pt-6">
                      <h3 className="text-lg font-semibold text-cream mb-4">Your Local Area</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-muted-foreground mb-2">
                            Local City or Town
                          </label>
                          <Input
                            value={data.customCityName || ""}
                            onChange={(e) => updateStateData(state, "customCityName", e.target.value)}
                            placeholder="Enter your city or town name"
                            className="bg-background/50 border-border/50 text-foreground"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-muted-foreground mb-2">
                            Local Pet Regulations & Ordinances
                          </label>
                          <textarea
                            value={data.customCity || ""}
                            onChange={(e) => updateStateData(state, "customCity", e.target.value)}
                            placeholder="Record your local pet regulations..."
                            className="w-full h-20 bg-background/50 border border-border/50 rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:border-gold/50"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-muted-foreground mb-2">
                            Animal Control Contact Information
                          </label>
                          <Input
                            value={data.animalControlContact || ""}
                            onChange={(e) => updateStateData(state, "animalControlContact", e.target.value)}
                            placeholder="Phone, email, or website"
                            className="bg-background/50 border-border/50 text-foreground"
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>

        {/* Footer CTA */}
        <div className="mt-16 text-center">
          <Card className="border-gold/40 bg-card/50">
            <CardContent className="py-8">
              <h3 className="text-2xl font-bold text-cream mb-4">Ready to Complete Your Pet Protection Plan?</h3>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Use this compliance information as part of your comprehensive pet protection planning. 
                Our Premium, Ultimate, and Platinum plans include guided workspace to organize all your pet's information.
              </p>
              <Button
                onClick={() => window.location.href = "/plans"}
                className="bg-gold text-black hover:bg-gold/90"
              >
                View Our Plans
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <BackToHome />
    </div>
  );
}
