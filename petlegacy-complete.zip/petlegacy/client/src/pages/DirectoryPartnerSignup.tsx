import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, CheckCircle2 } from "lucide-react";

const SERVICE_CATEGORIES = [
  "Veterinarians",
  "Pet Groomers",
  "Dog Trainers",
  "Pet Boarding",
  "Pet Sitters",
  "Animal Hospitals",
  "Dog Daycare",
  "Pet Transport",
  "Pet Cremation",
];

const STATES = [
  "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut",
  "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa",
  "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan",
  "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire",
  "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio",
  "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota",
  "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia",
  "Wisconsin", "Wyoming"
];

export default function DirectoryPartnerSignup() {
  const [formData, setFormData] = useState({
    businessName: "",
    businessType: "",
    businessEmail: "",
    businessPhone: "",
    businessWebsite: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    description: "",
    services: "",
    listingTier: "basic" as "basic" | "premium",
  });

  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const createListingMutation = (trpc.directory?.createListing as any)?.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setFormData({
        businessName: "",
        businessType: "",
        businessEmail: "",
        businessPhone: "",
        businessWebsite: "",
        address: "",
        city: "",
        state: "",
        zipCode: "",
        description: "",
        services: "",
        listingTier: "basic",
      });
      setError("");
    },
    onError: (err: any) => {
      setError(err.message || "Failed to create listing. Please try again.");
    },
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!formData.businessName || !formData.businessType || !formData.businessEmail || !formData.businessPhone) {
      setError("Please fill in all required fields.");
      return;
    }

    createListingMutation.mutate(formData);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
        <div className="max-w-2xl mx-auto">
          <Card className="border-gold/20 bg-card/50 backdrop-blur">
            <CardContent className="pt-12 text-center">
              <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-6" />
              <h2 className="text-2xl font-bold mb-4">Thank You for Registering!</h2>
              <p className="text-lg text-muted-foreground mb-6">
                Your directory listing has been submitted for approval. We'll review your information and contact you within 24 hours.
              </p>
              <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-6 mb-6 text-left">
                <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-3">What's Next?</h3>
                <ul className="space-y-2 text-blue-800 dark:text-blue-200">
                  <li>✓ We'll verify your business information</li>
                  <li>✓ Your listing will be approved and published to the directory</li>
                  <li>✓ You'll receive login credentials to manage your listing</li>
                  <li>✓ Your business will be visible to pet owners nationwide</li>
                </ul>
              </div>
              <Button onClick={() => setSubmitted(false)} className="bg-gold hover:bg-gold/90">
                Submit Another Listing
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Join the National Pet Directory</h1>
          <p className="text-xl text-muted-foreground">
            Connect with pet owners nationwide. Choose your listing tier and get started today.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Card
            className={`cursor-pointer transition-all ${
              formData.listingTier === "basic"
                ? "border-gold/50 bg-gold/5"
                : "border-border hover:border-gold/30"
            }`}
            onClick={() => setFormData((prev) => ({ ...prev, listingTier: "basic" }))}
          >
            <CardHeader>
              <CardTitle>Basic Listing</CardTitle>
              <CardDescription>FREE</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>✓ Business profile</li>
                <li>✓ Contact information</li>
                <li>✓ Service categories</li>
                <li>✓ Listed in directory</li>
              </ul>
            </CardContent>
          </Card>

          <Card
            className={`cursor-pointer transition-all ${
              formData.listingTier === "premium"
                ? "border-gold/50 bg-gold/5"
                : "border-border hover:border-gold/30"
            }`}
            onClick={() => setFormData((prev) => ({ ...prev, listingTier: "premium" }))}
          >
            <CardHeader>
              <CardTitle>Premium Featured Listing</CardTitle>
              <CardDescription className="text-gold font-semibold">
                <span className="line-through text-muted-foreground">$99/year</span> $49/year (50% OFF)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>✓ Everything in Basic</li>
                <li>✓ Featured placement</li>
                <li>✓ Verified Partner Seal</li>
                <li>✓ Priority visibility</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Registration Form */}
        <Card className="border-gold/20 bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle>Business Registration</CardTitle>
            <CardDescription>Fill in your business details to get listed</CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <div className="mb-6 p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg flex gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                <p className="text-red-700 dark:text-red-200">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Business Name */}
              <div>
                <label className="block text-sm font-medium mb-2">Business Name *</label>
                <input
                  type="text"
                  name="businessName"
                  value={formData.businessName}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50"
                  placeholder="Your business name"
                  required
                />
              </div>

              {/* Service Category */}
              <div>
                <label className="block text-sm font-medium mb-2">Service Category *</label>
                <select
                  name="businessType"
                  value={formData.businessType}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50"
                  required
                >
                  <option value="">Select a category</option>
                  {SERVICE_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium mb-2">Email Address *</label>
                <input
                  type="email"
                  name="businessEmail"
                  value={formData.businessEmail}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50"
                  placeholder="contact@business.com"
                  required
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-medium mb-2">Phone Number *</label>
                <input
                  type="tel"
                  name="businessPhone"
                  value={formData.businessPhone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50"
                  placeholder="(555) 123-4567"
                  required
                />
              </div>

              {/* Website */}
              <div>
                <label className="block text-sm font-medium mb-2">Website (Optional)</label>
                <input
                  type="url"
                  name="businessWebsite"
                  value={formData.businessWebsite}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50"
                  placeholder="https://yourbusiness.com"
                />
              </div>

              {/* Address */}
              <div>
                <label className="block text-sm font-medium mb-2">Street Address *</label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50"
                  placeholder="123 Main St"
                  required
                />
              </div>

              {/* City, State, Zip */}
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">City *</label>
                  <input
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50"
                    placeholder="City"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">State *</label>
                  <select
                    name="state"
                    value={formData.state}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50"
                    required
                  >
                    <option value="">Select state</option>
                    {STATES.map((state) => (
                      <option key={state} value={state}>
                        {state}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Zip Code</label>
                  <input
                    type="text"
                    name="zipCode"
                    value={formData.zipCode}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50"
                    placeholder="12345"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium mb-2">Business Description</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50 resize-none"
                  placeholder="Tell pet owners about your business..."
                  rows={4}
                />
              </div>

              {/* Services */}
              <div>
                <label className="block text-sm font-medium mb-2">Services Offered</label>
                <textarea
                  name="services"
                  value={formData.services}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-gold/50 resize-none"
                  placeholder="List your services (comma-separated)"
                  rows={3}
                />
              </div>

              {/* Submit */}
              <Button
                type="submit"
                disabled={createListingMutation.isPending}
                className="w-full bg-gold hover:bg-gold/90 text-black font-semibold py-3"
              >
                {createListingMutation.isPending ? "Submitting..." : "Submit Your Listing"}
              </Button>

              <p className="text-sm text-muted-foreground text-center">
                By submitting, you agree to our terms and conditions. Your listing will be reviewed within 24 hours.
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
