import React, { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface QuizQuestion {
  id: number;
  question: string;
  answers: string[];
}

const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "Do you currently have a written plan for who will care for your pets if something happens to you?",
    answers: ["Yes", "No"],
  },
  {
    id: 2,
    question: "Have you chosen a trusted pet guardian?",
    answers: ["Yes", "No"],
  },
  {
    id: 3,
    question: "Do you have emergency instructions for pet caregivers?",
    answers: ["Yes", "No"],
  },
  {
    id: 4,
    question: "Do you have money set aside for pet care?",
    answers: ["Yes", "No"],
  },
  {
    id: 5,
    question: "Do your family members know your pet care wishes?",
    answers: ["Yes", "No"],
  },
];

export default function Quiz() {
  const [currentStep, setCurrentStep] = useState(0);
  const [score, setScore] = useState(0);
  const [, setLocation] = useLocation();

  const handleAnswer = (answer: string) => {
    if (answer === "Yes") {
      setScore(score + 1);
    }

    if (currentStep < quizQuestions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Navigate to results page with score
      setLocation(`/quiz-results?score=${score + (answer === "Yes" ? 1 : 0)}`);
    }
  };

  const progress = ((currentStep + 1) / quizQuestions.length) * 100;
  const currentQuestion = quizQuestions[currentStep];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Pet Protection Readiness Quiz
          </h1>
          <p className="text-lg text-muted-foreground">
            Discover how prepared you are to protect your pet's future
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-muted-foreground">
              Question {currentStep + 1} of {quizQuestions.length}
            </span>
            <span className="text-sm font-medium text-gold">{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className="bg-gold h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Question Card */}
        <Card className="border-border/50 bg-card/50 backdrop-blur-sm mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-foreground">
              {currentQuestion.question}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {currentQuestion.answers.map((answer) => (
                <Button
                  key={answer}
                  onClick={() => handleAnswer(answer)}
                  variant="outline"
                  className="w-full h-12 text-base font-medium hover:bg-gold hover:text-black hover:border-gold transition-all"
                >
                  {answer}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button
            variant="ghost"
            onClick={() => {
              if (currentStep > 0) {
                setCurrentStep(currentStep - 1);
              }
            }}
            disabled={currentStep === 0}
            className="text-muted-foreground hover:text-foreground"
          >
            ← Previous
          </Button>
          <span className="text-sm text-muted-foreground">
            {currentStep + 1} / {quizQuestions.length}
          </span>
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground"
          >
            Exit Quiz
          </Button>
        </div>
      </div>
    </div>
  );
}
