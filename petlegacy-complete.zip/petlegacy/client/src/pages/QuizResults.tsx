import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, AlertCircle, Star, Facebook, Twitter, Linkedin, Mail } from "lucide-react";

interface Recommendation {
  tier: string;
  price: string;
  description: string;
  features: string[];
  cta: string;
  ctaLink: string;
  highlight?: boolean;
}

export default function QuizResults() {
  const [location, setLocation] = useLocation();
  const [score, setScore] = useState(0);
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null);

  useEffect(() => {
    // Extract score from URL query parameter
    const searchParams = new URLSearchParams(window.location.search);
    const scoreParam = parseInt(searchParams.get("score") || "0", 10);
    setScore(scoreParam);

    // Determine recommendation based on score
    let rec: Recommendation;
    if (scoreParam === 5) {
      rec = {
        tier: "Platinum Service",
        price: "$179.95",
        description:
          "You're already well-prepared! Our Platinum Service provides comprehensive legal review, personalized guardianship matching, and ongoing support.",
        features: [
          "Complete legal document review",
          "Personalized guardian matching",
          "Quarterly check-ins and updates",
          "Priority support & consultation",
          "State-specific legal guidance",
        ],
        cta: "Explore Platinum Service",
        ctaLink: "/plans",
        highlight: true,
      };
    } else if (scoreParam >= 4) {
      rec = {
        tier: "Ultimate Kit",
        price: "$69.95",
        description:
          "You're almost there! Our Ultimate Kit includes comprehensive planning templates, emergency guides, and state-specific resources.",
        features: [
          "Complete planning templates",
          "Emergency care instructions",
          "50-state legal framework",
          "Veterinary contact database",
          "Digital asset organization",
        ],
        cta: "Get Ultimate Kit",
        ctaLink: "/plans",
        highlight: true,
      };
    } else if (scoreParam >= 2) {
      rec = {
        tier: "Premium Kit",
        price: "$34.95",
        description:
          "You're on the right track! Our Premium Kit provides essential planning templates and emergency guides to get you started.",
        features: [
          "Pet profile templates",
          "Basic emergency instructions",
          "Guardian selection guide",
          "Care routine documentation",
          "Quick reference cards",
        ],
        cta: "Get Premium Kit",
        ctaLink: "/plans",
      };
    } else {
      rec = {
        tier: "Free Checklist",
        price: "Free",
        description:
          "Start your pet protection journey with our free checklist. It covers the essential first steps to protect your pet's future.",
        features: [
          "5-step protection checklist",
          "Guardian selection worksheet",
          "Emergency contact template",
          "Care routine guide",
          "Access to library resources",
        ],
        cta: "Get Free Checklist",
        ctaLink: "/plans",
      };
    }
    setRecommendation(rec);
  }, []);

  const getScoreMessage = (currentScore: number) => {
    if (currentScore === 5) {
      return "Outstanding! You're exceptionally well-prepared for your pet's future.";
    } else if (currentScore === 4) {
      return "Excellent! You've covered most of the important bases.";
    } else if (currentScore === 3) {
      return "Good start! You're on the right track with pet protection planning.";
    } else if (currentScore === 2) {
      return "You're making progress! A few more steps will give you peace of mind.";
    } else {
      return "Getting started is the first step. Let's build your pet protection plan together.";
    }
  };

  const shareUrl = `${window.location.origin}/quiz-results?score=${score}`;
  const shareMessage = `I scored ${score}/5 on the Pet Protection Readiness Quiz! ${
    score >= 4
      ? "I'm well on my way to comprehensive pet protection."
      : "I'm working on creating a complete pet protection plan."
  }`;

  const handleShare = (platform: string) => {
    let url = "";
    switch (platform) {
      case "facebook":
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareMessage)}`;
        break;
      case "twitter":
        url = `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareMessage)}`;
        break;
      case "linkedin":
        url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
        break;
      case "email":
        url = `mailto:?subject=Check out my Pet Protection Score&body=${encodeURIComponent(shareMessage + "\n\n" + shareUrl)}`;
        break;
    }
    if (url) window.open(url, "_blank");
  };

  if (!recommendation) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/95 flex items-center justify-center py-12 px-4">
        <div className="text-center">
          <div className="animate-spin mb-4">
            <Star className="w-12 h-12 text-gold mx-auto" />
          </div>
          <p className="text-muted-foreground">Loading your results...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Score Display */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gold/10 border-2 border-gold mb-6">
            <span className="text-5xl font-bold text-gold">{score}</span>
            <span className="text-2xl text-gold ml-1">/5</span>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-3">Your Pet Protection Score</h1>
          <p className="text-xl text-muted-foreground">{getScoreMessage(score)}</p>
        </div>

        {/* Recommendation Card */}
        <Card className={`border-2 mb-12 ${recommendation.highlight ? "border-gold/50 bg-card/80" : "border-border/50 bg-card/50"}`}>
          <CardHeader className="text-center pb-4">
            <div className="flex items-center justify-center gap-2 mb-2">
              {recommendation.highlight && <Star className="w-5 h-5 text-gold" />}
              <CardTitle className="text-2xl">{recommendation.tier}</CardTitle>
              {recommendation.highlight && <Star className="w-5 h-5 text-gold" />}
            </div>
            <p className="text-3xl font-bold text-gold">{recommendation.price}</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-foreground/80">{recommendation.description}</p>

            <div>
              <h3 className="font-semibold text-foreground mb-3">What's Included:</h3>
              <ul className="space-y-2">
                {recommendation.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-foreground/80">
                    <CheckCircle2 className="w-4 h-4 text-gold flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            <Button
              onClick={() => setLocation(recommendation.ctaLink)}
              className="w-full bg-gold text-black hover:bg-gold/90 h-12 font-semibold"
            >
              {recommendation.cta}
            </Button>
          </CardContent>
        </Card>

        {/* Share Section */}
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold text-foreground mb-6">Share Your Results</h2>
          <div className="flex flex-wrap gap-3 justify-center">
            <Button
              onClick={() => handleShare("facebook")}
              variant="outline"
              className="border-gold/40 text-gold hover:bg-gold/10"
            >
              <Facebook className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Facebook</span>
            </Button>
            <Button
              onClick={() => handleShare("twitter")}
              variant="outline"
              className="border-gold/40 text-gold hover:bg-gold/10"
            >
              <Twitter className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Twitter</span>
            </Button>
            <Button
              onClick={() => handleShare("linkedin")}
              variant="outline"
              className="border-gold/40 text-gold hover:bg-gold/10"
            >
              <Linkedin className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">LinkedIn</span>
            </Button>
            <Button
              onClick={() => handleShare("email")}
              variant="outline"
              className="border-gold/40 text-gold hover:bg-gold/10"
            >
              <Mail className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Email</span>
            </Button>
          </div>
        </div>

        {/* Next Steps */}
        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-gold" />
              Next Steps
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-foreground/80">
              Ready to create your complete pet protection plan? Here's what we recommend:
            </p>
            <ol className="space-y-3 list-decimal list-inside text-foreground/80">
              <li>Review your recommended plan above</li>
              <li>Explore our library for additional resources and guidance</li>
              <li>Set up your pet protection plan with your chosen tier</li>
              <li>Schedule a consultation if you need personalized help</li>
            </ol>
            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <Button
                onClick={() => setLocation("/library")}
                variant="outline"
                className="border-gold/40 text-gold hover:bg-gold/10"
              >
                Explore Library
              </Button>
              <Button
                onClick={() => setLocation("/plans")}
                className="bg-gold text-black hover:bg-gold/90"
              >
                View All Plans
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Back Button */}
        <div className="text-center mt-12">
          <Button
            variant="ghost"
            onClick={() => setLocation("/quiz")}
            className="text-muted-foreground hover:text-foreground"
          >
            ← Retake Quiz
          </Button>
        </div>
      </div>
    </div>
  );
}
