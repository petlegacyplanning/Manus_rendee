import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle, Home, MapPin, Loader2, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import BackToHome from "@/components/BackToHome";


const US_STATES = ["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"];

const safetyNotices = [
  "Never accept payment for rehoming a pet — this is a red flag for pet flipping.",
  "Meet potential adopters in a public place first before allowing a home visit.",
  "Ask for references and verify them before transferring your pet.",
  "Ensure the new home is a good match for your pet's needs and personality.",
  "Consider a trial period to ensure the placement is a good fit.",
];

export default function Rehome() {
  const { isAuthenticated } = useAuth();
  const [filterState, setFilterState] = useState("");
  const [form, setForm] = useState({ petName: "", species: "", breed: "", age: "", description: "", reason: "", city: "", state: "", contactEmail: "" });
  const [submitted, setSubmitted] = useState(false);

  const { data: listings, isLoading } = trpc.rehoming.list.useQuery({ state: filterState || undefined });

  const submitMutation = trpc.rehoming.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Listing submitted for review. We'll notify you when it's approved.");
    },
    onError: () => toast.error("Submission failed. Please try again."),
  });

  const handleSubmit = () => {
    if (!form.petName.trim()) { toast.error("Pet name is required."); return; }
    if (!form.contactEmail.trim()) { toast.error("Contact email is required."); return; }
    submitMutation.mutate(form);
  };

  return (
    <div className="min-h-screen bg-background pt-24">
      <section className="section-padding pb-0">
        <div className="container text-center">
          <Badge className="badge-gold mb-6 px-4 py-1.5">Rehoming Support</Badge>
          <h1 className="font-serif text-5xl font-bold text-cream mb-4">Rehome a Pet</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
            Life circumstances change. Our safe, moderated rehoming system helps connect pets with loving new families — with safety guidance at every step.
          </p>
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <AlertCircle className="w-4 h-4 text-gold" />
            <span>All listings are reviewed before publishing. Your pet's safety is our priority.</span>
          </div>
        </div>
      </section>

      {/* Safety Notices */}
      <section className="py-8 bg-dark-surface">
        <div className="container max-w-3xl mx-auto">
          <h2 className="font-serif text-xl font-bold text-cream mb-4 text-center">Safety Guidelines</h2>
          <div className="space-y-2">
            {safetyNotices.map((notice) => (
              <div key={notice} className="flex items-start gap-3 text-sm text-muted-foreground">
                <CheckCircle className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                {notice}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Submit Form */}
      <section className="section-padding">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Form */}
            <div>
              <h2 className="font-serif text-2xl font-bold text-cream mb-6">Submit a Rehoming Listing</h2>
              {!isAuthenticated ? (
                <div className="card-luxury rounded-2xl p-8 text-center">
                  <Home className="w-12 h-12 text-gold/40 mx-auto mb-4" />
                  <p className="text-muted-foreground mb-4">You need to be signed in to submit a rehoming listing.</p>
                  <Button className="bg-primary text-primary-foreground" asChild>
                    <a href={getLoginUrl()}>Sign In to Submit</a>
                  </Button>
                </div>
              ) : submitted ? (
                <div className="card-luxury rounded-2xl p-8 text-center">
                  <CheckCircle className="w-12 h-12 text-gold mx-auto mb-4" />
                  <h3 className="font-serif text-xl font-bold text-cream mb-2">Listing Submitted!</h3>
                  <p className="text-muted-foreground">Your listing is under review. We'll notify you when it's approved and published.</p>
                </div>
              ) : (
                <div className="card-luxury rounded-2xl p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Pet Name *</label>
                      <Input value={form.petName} onChange={(e) => setForm({ ...form, petName: e.target.value })} className="bg-input border-border" placeholder="Buddy" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Species</label>
                      <Input value={form.species} onChange={(e) => setForm({ ...form, species: e.target.value })} className="bg-input border-border" placeholder="Dog" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Breed</label>
                      <Input value={form.breed} onChange={(e) => setForm({ ...form, breed: e.target.value })} className="bg-input border-border" placeholder="Golden Retriever" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Age</label>
                      <Input value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} className="bg-input border-border" placeholder="3 years" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Description</label>
                    <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-input border-border" placeholder="Describe your pet's personality, needs, and what makes them special..." rows={3} />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Reason for Rehoming</label>
                    <Textarea value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} className="bg-input border-border" placeholder="Please share why you need to rehome your pet..." rows={2} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">City</label>
                      <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="bg-input border-border" placeholder="Austin" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">State</label>
                      <Select value={form.state} onValueChange={(v) => setForm({ ...form, state: v })}>
                        <SelectTrigger className="bg-input border-border">
                          <SelectValue placeholder="State" />
                        </SelectTrigger>
                        <SelectContent className="bg-card border-border">
                          {US_STATES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Contact Email *</label>
                    <Input type="email" value={form.contactEmail} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })} className="bg-input border-border" placeholder="your@email.com" />
                    <p className="text-xs text-muted-foreground mt-1">Your email is not shown publicly. Inquiries are routed through our system.</p>
                  </div>
                  <Button className="w-full bg-primary text-primary-foreground" onClick={handleSubmit} disabled={submitMutation.isPending}>
                    {submitMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                    Submit for Review
                  </Button>
                </div>
              )}
            </div>

            {/* Listings */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-serif text-2xl font-bold text-cream">Current Listings</h2>
                <Select value={filterState} onValueChange={setFilterState}>
                  <SelectTrigger className="w-32 bg-input border-border text-xs">
                    <SelectValue placeholder="All States" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="all">All States</SelectItem>
                    {US_STATES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {isLoading ? (
                <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 text-gold animate-spin" /></div>
              ) : listings && listings.length > 0 ? (
                <div className="space-y-4">
                  {listings.map((listing: any) => (
                    <div key={listing.id} className="card-luxury rounded-xl p-5">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-cream">{listing.petName}</h3>
                          {listing.breed && <p className="text-xs text-gold">{listing.species} — {listing.breed}</p>}
                        </div>
                        {listing.age && <span className="text-xs text-muted-foreground">{listing.age}</span>}
                      </div>
                      {listing.description && <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{listing.description}</p>}
                      {listing.city && listing.state && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {listing.city}, {listing.state}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 card-luxury rounded-2xl">
                  <Home className="w-10 h-10 text-gold/30 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">No listings available at this time.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
          <BackToHome />
      </div>
  );
}
