import { Link } from "wouter";
import { Heart, ExternalLink } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/logo-and-seal_8422082b.png";

export default function Footer() {
  return (
    <footer className="bg-dark-base border-t border-border">
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            {/* Logo shield (left half) + Partner Seal (right half) side by side */}
            <div className="flex items-center gap-4 mb-4">
              {/* Shield logo */}
              <div className="overflow-hidden flex-shrink-0" style={{ width: 56, height: 56 }}>
                <img src={LOGO_URL} alt="Pet Legacy Planning" style={{ height: 56, width: "auto", maxWidth: "none" }} />
              </div>
              {/* Partner seal — right half of same image */}
              <div className="overflow-hidden flex-shrink-0" style={{ width: 56, height: 56 }}>
                <img
                  src={LOGO_URL}
                  alt="Verified Partner Seal"
                  className="partner-seal"
                  style={{ height: 56, width: "auto", maxWidth: "none", transform: "translateX(-56px)" }}
                />
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              The nation's structured pet protection authority. Built to serve the people — because your pets deserve real planning.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Heart className="w-3.5 h-3.5 text-burgundy-light" />
              <span>Proud supporter of shelters and rescue missions</span>
            </div>
          </div>

          {/* Plans */}
          <div>
            <h4 className="font-serif text-sm font-semibold text-gold mb-4 uppercase tracking-wider">Plans</h4>
            <ul className="space-y-2">
              {[
                { label: "Free Basic Checklist", href: "/plans" },
                { label: "Premium Kit", href: "/plans/premium" },
                { label: "Ultimate Kit", href: "/plans/ultimate" },
                { label: "Platinum Done-For-You", href: "/plans/platinum" },
                { label: "How It Works", href: "/how-it-works" },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href}>
                    <span className="text-sm text-muted-foreground hover:text-gold transition-colors cursor-pointer">{item.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Community */}
          <div>
            <h4 className="font-serif text-sm font-semibold text-gold mb-4 uppercase tracking-wider">Community</h4>
            <ul className="space-y-2">
              {[
                { label: "Pet of the Week", href: "/community/pet-of-the-week" },
                { label: "Adopt a Pet", href: "/adopt" },
                { label: "Rehome a Pet", href: "/rehome" },
                { label: "Rescues & Shelters", href: "/rescues" },
                { label: "Memorials", href: "/community/memorials" },
                { label: "Registered Pets", href: "/community/registered-pets" },
                { label: "Newsletter", href: "/newsletter" },
                { label: "Pet Library", href: "/library" },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href}>
                    <span className="text-sm text-muted-foreground hover:text-gold transition-colors cursor-pointer">{item.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal & Support */}
          <div>
            <h4 className="font-serif text-sm font-semibold text-gold mb-4 uppercase tracking-wider">Support</h4>
            <ul className="space-y-2">
              {[
                { label: "FAQ", href: "/faq" },
                { label: "Contact Us", href: "/contact" },
                { label: "Founder Story", href: "/founder-story" },
                { label: "Terms of Service", href: "/terms" },
                { label: "Privacy Policy", href: "/privacy" },
                { label: "Disclaimer", href: "/disclaimer" },
                { label: "Accessibility", href: "/accessibility" },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href}>
                    <span className="text-sm text-muted-foreground hover:text-gold transition-colors cursor-pointer">{item.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="divider-gold my-10" />

        {/* Bottom */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-xs text-muted-foreground text-center md:text-left">
            <p>© {new Date().getFullYear()} PetLegacyPlanning.com — All rights reserved.</p>
            <p className="mt-1">
              PetLegacyPlanning.com provides educational planning resources and is not a law firm. Content is for informational purposes only. Consult a licensed attorney for legal advice.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>Sister brand:</span>
            <a
              href="https://lifelegacyplanner.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-gold hover:text-gold-light transition-colors"
            >
              LifeLegacyPlanner.com
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
