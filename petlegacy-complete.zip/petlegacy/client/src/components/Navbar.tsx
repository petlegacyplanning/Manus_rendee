import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Menu, X, ChevronDown, MapPin } from "lucide-react";

// Real logo: left half of the logo-and-seal image (shield crest)
const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/logo-and-seal_8422082b.png";

const navLinks = [
  { label: "Plans", href: "/plans" },
  {
    label: "Community",
    href: "/community",
    children: [
      { label: "Pet of the Week", href: "/community/pet-of-the-week" },
      { label: "Cutest Pet", href: "/community/cutest-pet" },
      { label: "Hero Pet", href: "/community/hero-pet" },
      { label: "Breed of the Week", href: "/community/breed-of-the-week" },
      { label: "Rescue of the Week", href: "/community/rescue-of-the-week" },
      { label: "Pet of the Month", href: "/community/pet-of-the-month" },
      { label: "Memorials", href: "/community/memorials" },
      { label: "Registered Pets", href: "/community/registered-pets" },
    ],
  },
  {
    label: "Resources",
    href: "/library",
    children: [
      { label: "Pet Library", href: "/library" },
      { label: "Protection Quiz", href: "/quiz" },
      { label: "Compliance Planner", href: "/compliance-planner" },
      { label: "Pet Guardian Registry", href: "/pet-guardian-registry" },
      { label: "Adopt a Pet", href: "/adopt" },
      { label: "Rehome a Pet", href: "/rehome" },
      { label: "Rescues & Shelters", href: "/rescues" },
      { label: "Newsletter", href: "/newsletter" },
    ],
  },
  { label: "How It Works", href: "/how-it-works" },
  { label: "Directory", href: "/directory" },
  { label: "Founder Story", href: "/founder-story" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "nav-scrolled" : "bg-transparent"
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo — show only the left shield crest (image is 2-up: shield + seal) */}
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer overflow-hidden" style={{ width: 64, height: 64 }}>
              <img
                src={LOGO_URL}
                alt="Pet Legacy Planning"
                style={{
                  height: 64,
                  width: "auto",
                  maxWidth: "none",
                  objectFit: "none",
                  objectPosition: "left center",
                  // The image is ~1320×660 (2:1 ratio, two badges side by side)
                  // We show only the left half by clipping via the parent overflow:hidden
                  transform: "scale(1)",
                }}
              />
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) =>
              link.children ? (
                <DropdownMenu key={link.href}>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-1 px-3 py-2 text-sm text-foreground/80 hover:text-gold transition-colors rounded-md">
                      {link.label}
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    className="bg-card border-border min-w-[200px]"
                    align="start"
                  >
                    {link.children.map((child) => (
                      <DropdownMenuItem key={child.href} asChild>
                        <Link href={child.href}>
                          <span className="text-foreground/80 hover:text-gold cursor-pointer w-full">{child.label}</span>
                        </Link>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link key={link.href} href={link.href}>
                  <span className="px-3 py-2 text-sm text-foreground/80 hover:text-gold transition-colors rounded-md cursor-pointer">
                    {link.label}
                  </span>
                </Link>
              )
            )}
          </nav>

          {/* CTA / Auth */}
          <div className="hidden lg:flex items-center gap-3">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="border-gold text-gold hover:bg-gold hover:text-background">
                    {user?.name?.split(" ")[0] ?? "My Account"}
                    <ChevronDown className="w-3.5 h-3.5 ml-1" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-card border-border" align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/my-plan"><span className="cursor-pointer w-full">My Plan</span></Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/planner-dashboard"><span className="cursor-pointer w-full">Pet Planner</span></Link>
                  </DropdownMenuItem>
                  {user?.role === "admin" && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin"><span className="cursor-pointer w-full">Admin Dashboard</span></Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={logout} className="text-destructive cursor-pointer">
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <a href={getLoginUrl()} className="text-sm text-foreground/70 hover:text-gold transition-colors">
                  Sign In
                </a>
                <Button
                  size="sm"
                  className="bg-primary text-primary-foreground hover:opacity-90 font-semibold"
                  asChild
                >
                  <Link href="/plans">Get Started</Link>
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="lg:hidden p-2 text-foreground/80 hover:text-gold"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-card border-t border-border">
          <div className="container py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <div key={link.href}>
                <Link href={link.href}>
                  <span className="block px-3 py-2 text-sm font-medium text-foreground/80 hover:text-gold cursor-pointer">
                    {link.label}
                  </span>
                </Link>
                {link.children && (
                  <div className="pl-6">
                    {link.children.map((child) => (
                      <Link key={child.href} href={child.href}>
                        <span className="block px-3 py-1.5 text-xs text-muted-foreground hover:text-gold cursor-pointer">
                          {child.label}
                        </span>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="pt-3 border-t border-border flex flex-col gap-2">
              {isAuthenticated ? (
                <>
                  <Link href="/my-plan">
                    <Button variant="outline" size="sm" className="w-full border-gold text-gold">My Plan</Button>
                  </Link>
                  <Link href="/planner-dashboard">
                    <Button variant="outline" size="sm" className="w-full border-gold text-gold">Pet Planner</Button>
                  </Link>
                  <Button variant="ghost" size="sm" className="w-full text-destructive" onClick={logout}>Sign Out</Button>
                </>
              ) : (
                <>
                  <a href={getLoginUrl()}>
                    <Button variant="outline" size="sm" className="w-full">Sign In</Button>
                  </a>
                  <Link href="/plans">
                    <Button size="sm" className="w-full bg-primary text-primary-foreground">Get Started</Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
