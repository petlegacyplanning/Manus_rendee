import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, RotateCcw, Trophy } from "lucide-react";

// ─── CROSSWORD ────────────────────────────────────────────────────────────────

type CellData = {
  letter: string;
  row: number;
  col: number;
  across?: number;
  down?: number;
  isBlack?: boolean;
};

// 10×10 pet-themed crossword
const CROSSWORD_ANSWERS: string[][] = [
  ["P", "A", "W", " ", "C", "A", "T", " ", " ", " "],
  ["E", " ", "A", " ", "A", " ", "R", " ", " ", " "],
  ["T", "R", "I", "C", "K", " ", "A", "I", "L", " "],
  [" ", " ", "L", " ", " ", " ", "I", " ", "E", " "],
  [" ", "B", " ", "F", "E", "T", "C", "H", " ", " "],
  [" ", "O", " ", "L", " ", " ", "K", " ", " ", " "],
  ["V", "N", "E", "T", " ", " ", " ", " ", " ", " "],
  ["E", "E", " ", "E", " ", "P", "U", "P", " ", " "],
  ["T", " ", " ", " ", " ", " ", " ", " ", " ", " "],
  [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
];

const CLUES = {
  across: [
    { num: 1, clue: "A dog's foot (3)", row: 0, col: 0 },
    { num: 4, clue: "A feline pet (3)", row: 0, col: 4 },
    { num: 6, clue: "A dog's appendage (4)", row: 0, col: 6 },
    { num: 7, clue: "A command dogs learn (5)", row: 2, col: 0 },
    { num: 8, clue: "What dogs love to do with a ball (5)", row: 4, col: 1 },
    { num: 9, clue: "Animal doctor (3)", row: 6, col: 0 },
    { num: 10, clue: "Young dog (3)", row: 7, col: 5 },
  ],
  down: [
    { num: 1, clue: "Companion animal (3)", row: 0, col: 0 },
    { num: 2, clue: "Dog's wagging part (4)", row: 0, col: 6 },
    { num: 3, clue: "Dog's loyal quality (4)", row: 2, col: 2 },
    { num: 5, clue: "Dog breed group (6)", row: 4, col: 1 },
    { num: 6, clue: "Flat-faced dog breed trait (5)", row: 4, col: 3 },
  ],
};

export function PetCrossword() {
  const [userGrid, setUserGrid] = useState<string[][]>(
    CROSSWORD_ANSWERS.map((row) => row.map((c) => (c === " " ? " " : "")))
  );
  const [selected, setSelected] = useState<{ row: number; col: number } | null>(null);
  const [direction, setDirection] = useState<"across" | "down">("across");
  const [revealed, setRevealed] = useState(false);
  const [checked, setChecked] = useState(false);

  const isBlack = (r: number, c: number) => CROSSWORD_ANSWERS[r][c] === " ";

  const handleCellClick = (r: number, c: number) => {
    if (isBlack(r, c)) return;
    if (selected?.row === r && selected?.col === c) {
      setDirection((d) => (d === "across" ? "down" : "across"));
    } else {
      setSelected({ row: r, col: c });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent, r: number, c: number) => {
    if (isBlack(r, c)) return;
    const letter = e.key.toUpperCase();
    if (/^[A-Z]$/.test(letter)) {
      const newGrid = userGrid.map((row) => [...row]);
      newGrid[r][c] = letter;
      setUserGrid(newGrid);
      setChecked(false);
      // Advance cursor
      if (direction === "across" && c < 9 && !isBlack(r, c + 1)) setSelected({ row: r, col: c + 1 });
      else if (direction === "down" && r < 9 && !isBlack(r + 1, c)) setSelected({ row: r + 1, col: c });
    } else if (e.key === "Backspace") {
      const newGrid = userGrid.map((row) => [...row]);
      newGrid[r][c] = "";
      setUserGrid(newGrid);
      setChecked(false);
    } else if (e.key === "ArrowRight") setSelected({ row: r, col: Math.min(c + 1, 9) });
    else if (e.key === "ArrowLeft") setSelected({ row: r, col: Math.max(c - 1, 0) });
    else if (e.key === "ArrowDown") setSelected({ row: Math.min(r + 1, 9), col: c });
    else if (e.key === "ArrowUp") setSelected({ row: Math.max(r - 1, 0), col: c });
  };

  const isCorrect = useCallback(
    (r: number, c: number) =>
      !isBlack(r, c) && userGrid[r][c] !== "" && userGrid[r][c] === CROSSWORD_ANSWERS[r][c],
    [userGrid]
  );

  const isWrong = (r: number, c: number) =>
    checked && !isBlack(r, c) && userGrid[r][c] !== "" && userGrid[r][c] !== CROSSWORD_ANSWERS[r][c];

  const allCorrect = CROSSWORD_ANSWERS.every((row, r) =>
    row.every((cell, c) => cell === " " || userGrid[r][c] === cell)
  );

  const reset = () => {
    setUserGrid(CROSSWORD_ANSWERS.map((row) => row.map((c) => (c === " " ? " " : ""))));
    setRevealed(false);
    setChecked(false);
    setSelected(null);
  };

  const reveal = () => {
    setUserGrid(CROSSWORD_ANSWERS.map((row) => [...row]));
    setRevealed(true);
  };

  // Clue number labels
  const clueNumbers: Record<string, number> = {};
  [...CLUES.across, ...CLUES.down].forEach((c) => {
    clueNumbers[`${c.row}-${c.col}`] = c.num;
  });

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      {/* Grid */}
      <div className="flex-shrink-0">
        {allCorrect && !revealed && (
          <div className="flex items-center gap-2 text-gold mb-4 justify-center">
            <Trophy className="w-5 h-5" />
            <span className="font-semibold">Puzzle Complete! Well done!</span>
          </div>
        )}
        <div className="inline-grid gap-0.5 bg-border p-0.5 rounded-lg" style={{ gridTemplateColumns: "repeat(10, 36px)" }}>
          {CROSSWORD_ANSWERS.map((row, r) =>
            row.map((_, c) => {
              const black = isBlack(r, c);
              const isSel = selected?.row === r && selected?.col === c;
              const correct = isCorrect(r, c);
              const wrong = isWrong(r, c);
              const clueNum = clueNumbers[`${r}-${c}`];
              return (
                <div
                  key={`${r}-${c}`}
                  className={`relative w-9 h-9 flex items-center justify-center cursor-pointer select-none
                    ${black ? "bg-foreground/90" : isSel ? "bg-gold/30 border border-gold" : correct ? "bg-green-900/30 border border-green-600/40" : wrong ? "bg-red-900/30 border border-red-500/40" : "bg-card border border-border"}
                  `}
                  onClick={() => handleCellClick(r, c)}
                  onKeyDown={(e) => handleKeyDown(e, r, c)}
                  tabIndex={black ? -1 : 0}
                >
                  {clueNum && !black && (
                    <span className="absolute top-0.5 left-0.5 text-[8px] text-gold/70 leading-none font-bold">{clueNum}</span>
                  )}
                  {!black && (
                    <span className={`text-sm font-bold ${correct ? "text-green-400" : wrong ? "text-red-400" : "text-cream"}`}>
                      {revealed ? CROSSWORD_ANSWERS[r][c] : userGrid[r][c]}
                    </span>
                  )}
                </div>
              );
            })
          )}
        </div>
        <div className="flex gap-2 mt-4 justify-center">
          <Button size="sm" variant="outline" className="border-gold/30 text-gold" onClick={() => setChecked(true)}>
            <CheckCircle className="w-4 h-4 mr-1" /> Check
          </Button>
          <Button size="sm" variant="outline" className="border-gold/30 text-muted-foreground" onClick={reveal}>
            Reveal
          </Button>
          <Button size="sm" variant="outline" className="border-gold/30 text-muted-foreground" onClick={reset}>
            <RotateCcw className="w-4 h-4 mr-1" /> Reset
          </Button>
        </div>
      </div>

      {/* Clues */}
      <div className="flex-1 grid sm:grid-cols-2 gap-6 text-sm">
        <div>
          <h3 className="font-serif text-lg font-bold text-gold mb-3">Across</h3>
          <ul className="space-y-1.5">
            {CLUES.across.map((c) => (
              <li
                key={c.num}
                className="text-muted-foreground hover:text-foreground cursor-pointer"
                onClick={() => { setSelected({ row: c.row, col: c.col }); setDirection("across"); }}
              >
                <span className="text-gold font-semibold mr-1">{c.num}.</span>{c.clue}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="font-serif text-lg font-bold text-gold mb-3">Down</h3>
          <ul className="space-y-1.5">
            {CLUES.down.map((c) => (
              <li
                key={c.num}
                className="text-muted-foreground hover:text-foreground cursor-pointer"
                onClick={() => { setSelected({ row: c.row, col: c.col }); setDirection("down"); }}
              >
                <span className="text-gold font-semibold mr-1">{c.num}.</span>{c.clue}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

// ─── WORD SEARCH ──────────────────────────────────────────────────────────────

const WORD_LIST = ["PAWS", "FETCH", "LEASH", "COLLAR", "KENNEL", "PUPPY", "KITTEN", "RESCUE", "GUARDIAN", "LEGACY"];

// 12×12 grid with words hidden inside
const WORD_GRID: string[][] = [
  ["G","U","A","R","D","I","A","N","X","K","L","E"],
  ["P","A","W","S","F","E","T","C","H","E","E","G"],
  ["U","X","K","I","T","T","E","N","Z","N","A","C"],
  ["P","L","E","G","A","C","Y","Q","R","N","S","O"],
  ["P","E","A","X","B","O","M","V","E","E","H","L"],
  ["Y","A","Z","C","O","L","L","A","R","L","X","L"],
  ["X","S","K","E","N","N","E","L","P","X","Q","A"],
  ["R","H","X","Q","Z","X","P","U","P","P","Y","R"],
  ["E","X","F","E","T","C","H","X","Z","X","X","X"],
  ["S","X","X","X","X","X","X","X","X","X","X","X"],
  ["C","X","X","X","X","X","X","X","X","X","X","X"],
  ["U","E","X","X","X","X","X","X","X","X","X","X"],
];

// Word positions: [word, startRow, startCol, direction]
const WORD_POSITIONS: Record<string, { cells: [number, number][] }> = {
  PAWS:     { cells: [[1,0],[1,1],[1,2],[1,3]] },
  FETCH:    { cells: [[1,4],[1,5],[1,6],[1,7],[1,8]] },
  LEASH:    { cells: [[3,1],[4,1],[5,1],[6,1],[7,1]] },
  COLLAR:   { cells: [[5,2],[5,3],[5,4],[5,5],[5,6],[5,7]] },
  KENNEL:   { cells: [[6,2],[6,3],[6,4],[6,5],[6,6],[6,7]] },
  PUPPY:    { cells: [[0,0],[1,0],[2,0],[3,0],[4,0]] },
  KITTEN:   { cells: [[2,2],[2,3],[2,4],[2,5],[2,6],[2,7]] },
  RESCUE:   { cells: [[8,0],[9,0],[10,0],[11,0],[11,1],[11,2]] },
  GUARDIAN: { cells: [[0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7]] },
  LEGACY:   { cells: [[3,1],[3,2],[3,3],[3,4],[3,5],[3,6]] },
};

export function PetWordSearch() {
  const [firstClick, setFirstClick] = useState<[number, number] | null>(null);
  const [foundWords, setFoundWords] = useState<string[]>([]);
  const [highlightedCells, setHighlightedCells] = useState<Set<string>>(new Set());
  const [wrongCells, setWrongCells] = useState<Set<string>>(new Set());

  const handleCellClick = (r: number, c: number) => {
    if (!firstClick) {
      setFirstClick([r, c]);
      setWrongCells(new Set());
    } else {
      const [fr, fc] = firstClick;
      // Check if this selection matches any word
      let matched = false;
      for (const [word, { cells }] of Object.entries(WORD_POSITIONS)) {
        if (foundWords.includes(word)) continue;
        const first = cells[0];
        const last = cells[cells.length - 1];
        if (
          (fr === first[0] && fc === first[1] && r === last[0] && c === last[1]) ||
          (fr === last[0] && fc === last[1] && r === first[0] && c === first[1])
        ) {
          setFoundWords((prev) => [...prev, word]);
          setHighlightedCells((prev) => {
            const next = new Set(prev);
            cells.forEach(([cr, cc]) => next.add(`${cr}-${cc}`));
            return next;
          });
          matched = true;
          break;
        }
      }
      if (!matched) {
        setWrongCells(new Set([`${fr}-${fc}`, `${r}-${c}`]));
        setTimeout(() => setWrongCells(new Set()), 800);
      }
      setFirstClick(null);
    }
  };

  const reset = () => {
    setFoundWords([]);
    setHighlightedCells(new Set());
    setFirstClick(null);
    setWrongCells(new Set());
  };

  const allFound = foundWords.length === WORD_LIST.length;

  return (
    <div className="flex flex-col lg:flex-row gap-8 items-start">
      {/* Grid */}
      <div className="flex-shrink-0">
        {allFound && (
          <div className="flex items-center gap-2 text-gold mb-4 justify-center">
            <Trophy className="w-5 h-5" />
            <span className="font-semibold">All words found! Amazing!</span>
          </div>
        )}
        <div className="inline-grid gap-0.5" style={{ gridTemplateColumns: "repeat(12, 32px)" }}>
          {WORD_GRID.map((row, r) =>
            row.map((letter, c) => {
              const key = `${r}-${c}`;
              const isHighlighted = highlightedCells.has(key);
              const isFirst = firstClick?.[0] === r && firstClick?.[1] === c;
              const isWrong = wrongCells.has(key);
              return (
                <div
                  key={key}
                  className={`w-8 h-8 flex items-center justify-center rounded cursor-pointer select-none text-sm font-bold transition-all
                    ${isHighlighted ? "bg-gold/30 text-gold border border-gold/50" : isFirst ? "bg-primary/30 text-primary border border-primary/50" : isWrong ? "bg-red-900/40 text-red-400" : "bg-card border border-border/50 text-foreground/70 hover:bg-gold/10 hover:text-gold"}
                  `}
                  onClick={() => handleCellClick(r, c)}
                >
                  {letter}
                </div>
              );
            })
          )}
        </div>
        <div className="flex gap-2 mt-4 justify-center">
          <Button size="sm" variant="outline" className="border-gold/30 text-muted-foreground" onClick={reset}>
            <RotateCcw className="w-4 h-4 mr-1" /> Reset
          </Button>
        </div>
        <p className="text-xs text-muted-foreground text-center mt-2">
          Click the first letter of a word, then click the last letter.
        </p>
      </div>

      {/* Word list */}
      <div className="flex-1">
        <h3 className="font-serif text-lg font-bold text-gold mb-4">Find These Words</h3>
        <div className="grid grid-cols-2 gap-2">
          {WORD_LIST.map((word) => (
            <div
              key={word}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                foundWords.includes(word)
                  ? "bg-gold/20 border border-gold/40 text-gold line-through"
                  : "bg-card border border-border text-foreground/70"
              }`}
            >
              {foundWords.includes(word) && <CheckCircle className="w-4 h-4 text-gold flex-shrink-0" />}
              {word}
            </div>
          ))}
        </div>
        <p className="text-sm text-muted-foreground mt-4">
          {foundWords.length} of {WORD_LIST.length} words found
        </p>
      </div>
    </div>
  );
}
