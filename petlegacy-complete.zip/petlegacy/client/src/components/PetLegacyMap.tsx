import { useEffect, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

// US state abbreviations for geocoding lookup
const STATE_CENTERS: Record<string, [number, number]> = {
  AL: [32.806671, -86.791130], AK: [61.370716, -152.404419], AZ: [33.729759, -111.431221],
  AR: [34.969704, -92.373123], CA: [36.116203, -119.681564], CO: [39.059811, -105.311104],
  CT: [41.597782, -72.755371], DE: [39.318523, -75.507141], FL: [27.766279, -81.686783],
  GA: [33.040619, -83.643074], HI: [21.094318, -157.498337], ID: [44.240459, -114.478828],
  IL: [40.349457, -88.986137], IN: [39.849426, -86.258278], IA: [42.011539, -93.210526],
  KS: [38.526600, -96.726486], KY: [37.668140, -84.670067], LA: [31.169960, -91.867805],
  ME: [44.693947, -69.381927], MD: [39.063946, -76.802101], MA: [42.230171, -71.530106],
  MI: [43.326618, -84.536095], MN: [45.694454, -93.900192], MS: [32.741646, -89.678696],
  MO: [38.456085, -92.288368], MT: [46.921925, -110.454353], NE: [41.125370, -98.268082],
  NV: [38.313515, -117.055374], NH: [43.452492, -71.563896], NJ: [40.298904, -74.521011],
  NM: [34.840515, -106.248482], NY: [42.165726, -74.948051], NC: [35.630066, -79.806419],
  ND: [47.528912, -99.784012], OH: [40.388783, -82.764915], OK: [35.565342, -96.928917],
  OR: [44.572021, -122.070938], PA: [40.590752, -77.209755], RI: [41.680893, -71.511780],
  SC: [33.856892, -80.945007], SD: [44.299782, -99.438828], TN: [35.747845, -86.692345],
  TX: [31.054487, -97.563461], UT: [40.150032, -111.862434], VT: [44.045876, -72.710686],
  VA: [37.769337, -78.169968], WA: [47.400902, -121.490494], WV: [38.491226, -80.954453],
  WI: [44.268543, -89.616508], WY: [42.755966, -107.302490],
};

export default function PetLegacyMap() {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<import("leaflet").Map | null>(null);
  const [form, setForm] = useState({ petName: "", breed: "", city: "", state: "", story: "" });
  const [submitting, setSubmitting] = useState(false);

  const { data: pins = [], refetch } = trpc.petMap.listPins.useQuery();
  const addPin = trpc.petMap.addPin.useMutation({
    onSuccess: () => {
      toast.success("Your pet has been added to the map!");
      setForm({ petName: "", breed: "", city: "", state: "", story: "" });
      refetch();
    },
    onError: () => toast.error("Could not add your pet. Please try again."),
  });

  // Initialize Leaflet map
  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    import("leaflet").then((L) => {
      // Fix default icon paths for bundlers
      delete (L.Icon.Default.prototype as unknown as Record<string, unknown>)._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
        iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
        shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      });

      const map = L.map(mapRef.current!, {
        center: [39.5, -98.35],
        zoom: 4,
        zoomControl: true,
        scrollWheelZoom: false,
      });

      // Dark tile layer (CartoDB Dark Matter)
      L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
        attribution: '&copy; <a href="https://carto.com/">CARTO</a>',
        maxZoom: 18,
      }).addTo(map);

      mapInstanceRef.current = map;
    });

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Add/update markers when pins change
  useEffect(() => {
    if (!mapInstanceRef.current || pins.length === 0) return;

    import("leaflet").then((L) => {
      const map = mapInstanceRef.current!;

      // Remove old markers
      map.eachLayer((layer) => {
        if (layer instanceof L.Marker) map.removeLayer(layer);
      });

      // Gold custom icon
      const goldIcon = L.divIcon({
        className: "",
        html: `<div style="
          width:28px;height:28px;
          background:linear-gradient(135deg,#d4af37,#b88a18);
          border:2px solid #f7f1df;
          border-radius:50% 50% 50% 0;
          transform:rotate(-45deg);
          box-shadow:0 2px 8px rgba(212,175,55,0.5);
        "></div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 28],
        popupAnchor: [0, -30],
      });

      pins.forEach((pin) => {
        L.marker([pin.lat, pin.lng], { icon: goldIcon })
          .addTo(map)
          .bindPopup(`
            <div style="font-family:serif;min-width:160px;color:#111;">
              <strong style="font-size:1rem;color:#8B6914;">${pin.petName}</strong>
              ${pin.breed ? `<div style="font-size:0.8rem;color:#555;">${pin.breed}</div>` : ""}
              <div style="font-size:0.8rem;margin-top:4px;color:#333;">${pin.city}, ${pin.state}</div>
              ${pin.story ? `<div style="font-size:0.78rem;margin-top:6px;color:#444;line-height:1.4;">${pin.story}</div>` : ""}
            </div>
          `);
      });
    });
  }, [pins]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.petName || !form.city || !form.state) {
      toast.error("Please fill in Pet Name, City, and State.");
      return;
    }

    setSubmitting(true);
    // Geocode: use state center as fallback, add small jitter for city variation
    const stateKey = form.state.toUpperCase().trim();
    const center = STATE_CENTERS[stateKey] ?? [39.5, -98.35];
    const lat = center[0] + (Math.random() - 0.5) * 2;
    const lng = center[1] + (Math.random() - 0.5) * 2;

    await addPin.mutateAsync({
      petName: form.petName,
      breed: form.breed || undefined,
      city: form.city,
      state: form.state,
      story: form.story || undefined,
      lat,
      lng,
    });
    setSubmitting(false);
  };

  return (
    <div className="plp-map-wrapper">
      {/* Leaflet CSS */}
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

      <div className="plp-map-inner">
        <div ref={mapRef} className="plp-map-canvas" />
      </div>

      <div className="plp-pin-form">
        <h3 className="plp-pin-form-title">Add Your Pet to the Map</h3>
        <form onSubmit={handleSubmit} className="plp-pin-fields">
          <div className="plp-pin-row">
            <input
              className="plp-pin-input"
              placeholder="Pet Name *"
              value={form.petName}
              onChange={(e) => setForm({ ...form, petName: e.target.value })}
              maxLength={100}
            />
            <input
              className="plp-pin-input"
              placeholder="Breed"
              value={form.breed}
              onChange={(e) => setForm({ ...form, breed: e.target.value })}
              maxLength={100}
            />
          </div>
          <div className="plp-pin-row">
            <input
              className="plp-pin-input"
              placeholder="City *"
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
              maxLength={100}
            />
            <input
              className="plp-pin-input"
              placeholder="State (e.g. TX) *"
              value={form.state}
              onChange={(e) => setForm({ ...form, state: e.target.value })}
              maxLength={50}
            />
          </div>
          <textarea
            className="plp-pin-input plp-pin-textarea"
            placeholder="Short story about your pet…"
            value={form.story}
            onChange={(e) => setForm({ ...form, story: e.target.value })}
            maxLength={1000}
            rows={3}
          />
          <button type="submit" className="plp-pin-submit" disabled={submitting}>
            {submitting ? "Adding…" : "Add Pet Pin"}
          </button>
        </form>
      </div>
    </div>
  );
}
