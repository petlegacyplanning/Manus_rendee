/**
 * LuxuryBorder — fixed viewport frame with baroque ornamental corners
 * and delicate filigree edge lines in gold/cream/burgundy.
 *
 * Rendered as a fixed overlay (pointer-events: none) so it never
 * blocks clicks or scrolling. Corner images are rotated CSS transforms
 * of the single top-left asset.
 */

const CORNER_SRC =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/corner-ornament-final_af38b953.png";

export default function LuxuryBorder() {
  return (
    <>
      {/* ── Fixed frame overlay ─────────────────────────────────────── */}
      <div
        aria-hidden="true"
        className="luxury-border-frame"
        style={{ pointerEvents: "none" }}
      >
        {/* Edge lines — top, bottom, left, right */}
        <span className="luxury-edge luxury-edge-top" />
        <span className="luxury-edge luxury-edge-bottom" />
        <span className="luxury-edge luxury-edge-left" />
        <span className="luxury-edge luxury-edge-right" />

        {/* Corner appliqués */}
        <img
          src={CORNER_SRC}
          alt=""
          className="luxury-corner luxury-corner-tl"
          draggable={false}
        />
        <img
          src={CORNER_SRC}
          alt=""
          className="luxury-corner luxury-corner-tr"
          draggable={false}
        />
        <img
          src={CORNER_SRC}
          alt=""
          className="luxury-corner luxury-corner-bl"
          draggable={false}
        />
        <img
          src={CORNER_SRC}
          alt=""
          className="luxury-corner luxury-corner-br"
          draggable={false}
        />
      </div>
    </>
  );
}
