import { useEffect } from "react";
import { useLocation } from "wouter";

/**
 * Forces every page to load at the very top.
 * - Strips any hash from the URL on first load
 * - Instantly scrolls to 0,0 on every route change
 * - Mobile safety: extra scroll after 100ms to override browser restore
 */
export default function ScrollToTop() {
  const [location] = useLocation();

  useEffect(() => {
    // Strip hash anchor from URL so the browser doesn't jump to an anchor
    if (window.location.hash) {
      history.replaceState(null, "", window.location.pathname + window.location.search);
    }

    // Instant scroll — no animation, no smooth behavior
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });

    // Mobile safety: some browsers restore scroll position after paint
    const t = setTimeout(() => {
      window.scrollTo({ top: 0, left: 0, behavior: "instant" });
    }, 100);

    return () => clearTimeout(t);
  }, [location]);

  return null;
}
