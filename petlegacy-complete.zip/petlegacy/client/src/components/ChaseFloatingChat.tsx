import { useState, useRef, useEffect, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, MessageCircle, Send, Loader2 } from "lucide-react";

/**
 * Floating chat widget for Chase Q&A
 * Accessible from any page on the site
 * Queries the knowledge base for accurate answers
 */
export function ChaseFloatingChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [question, setQuestion] = useState("");
  const [chatHistory, setChatHistory] = useState<Array<{ role: "user" | "chase"; text: string }>>([]);
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const speechSynthRef = useRef(window.speechSynthesis);
  const mouthAnimRef = useRef(0);

  const askMutation = trpc.chase.askWithKnowledge.useMutation();

  // Auto-scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory]);

  // Get voices on component mount
  useEffect(() => {
    const loadVoices = () => {
      speechSynthRef.current.getVoices();
    };
    speechSynthRef.current.onvoiceschanged = loadVoices;
    loadVoices();
  }, []);

  const speak = useCallback((text: string) => {
    speechSynthRef.current.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = 1.15;
    utter.pitch = 0.82;
    utter.volume = 1;

    const voices = speechSynthRef.current.getVoices();
    const premiumMale = [
      "Google US English Male",
      "Microsoft Guy Online (Natural) - English (United States)",
      "Microsoft Christopher Online (Natural) - English (United States)",
      "Microsoft Ryan Online (Natural) - English (United States)",
    ];
    const desktopMale = ["David", "Alex", "Daniel", "George"];
    const allMale = [...premiumMale, ...desktopMale];

    const selectedVoice = voices.find((v) => allMale.includes(v.name)) || voices[0];
    if (selectedVoice) utter.voice = selectedVoice;

    speechSynthRef.current.speak(utter);
  }, []);

  const handleAsk = async () => {
    if (!question.trim()) return;

    const userMsg = question;
    setQuestion("");
    setChatHistory((prev) => [...prev, { role: "user", text: userMsg }]);
    setIsLoading(true);

    try {
      const res = await askMutation.mutateAsync({ question: userMsg });
      const reply = String(res.answer ?? "");
      setChatHistory((prev) => [...prev, { role: "chase", text: reply }]);
      speak(reply);
    } catch (error) {
      const fallback = "I'm sorry, I had a little trouble with that one. Could you try asking again?";
      setChatHistory((prev) => [...prev, { role: "chase", text: fallback }]);
      speak(fallback);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleAsk();
    }
  };

  return (
    <>
      {/* Floating button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-br from-amber-500 to-amber-600 text-white shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-200"
          aria-label="Open Chase chat"
        >
          <MessageCircle className="w-6 h-6" />
        </button>
      )}

      {/* Chat widget */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-2rem)] bg-white rounded-2xl shadow-2xl flex flex-col max-h-[600px] border border-gray-200">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-amber-50 to-amber-100 rounded-t-2xl">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-white text-sm font-bold">
                C
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Chase</h3>
                <p className="text-xs text-gray-600">Pet Legacy Guide</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="h-8 w-8 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Chat history */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
            {chatHistory.length === 0 && (
              <div className="text-center py-8">
                <p className="text-sm text-gray-600">
                  Hi! I'm Chase, your Pet Legacy Planning guide. Ask me anything about pet trusts, guardianship, emergency planning, or our library resources.
                </p>
              </div>
            )}
            {chatHistory.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-lg ${
                    msg.role === "user"
                      ? "bg-amber-500 text-white rounded-br-none"
                      : "bg-white text-gray-900 border border-gray-200 rounded-bl-none"
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white text-gray-900 border border-gray-200 px-4 py-2 rounded-lg rounded-bl-none flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">Chase is thinking...</span>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input area */}
          <div className="p-4 border-t border-gray-200 bg-white rounded-b-2xl">
            <div className="flex gap-2">
              <Input
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask Chase anything..."
                className="flex-1 text-sm"
                disabled={isLoading}
              />
              <Button
                onClick={handleAsk}
                disabled={isLoading || !question.trim()}
                size="sm"
                className="bg-amber-500 hover:bg-amber-600 text-white"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
