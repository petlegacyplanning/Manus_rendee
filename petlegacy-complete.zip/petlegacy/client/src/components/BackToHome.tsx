import { Link } from "wouter";
import { Home } from "lucide-react";

/**
 * BackToHome — a fixed, luxury-styled button that appears on every non-home page.
 * Sits in the bottom-left corner, above the luxury border, and links back to "/".
 */
export default function BackToHome() {
  return (
    <Link
      href="/"
      style={{
        position: "fixed",
        bottom: "28px",
        left: "28px",
        zIndex: 9000,
        display: "inline-flex",
        alignItems: "center",
        gap: "8px",
        padding: "10px 20px",
        borderRadius: "999px",
        textDecoration: "none",
        fontFamily: "inherit",
        fontWeight: 700,
        fontSize: "0.88rem",
        letterSpacing: "0.06em",
        textTransform: "uppercase",
        color: "#111",
        background: "linear-gradient(135deg, #d4af37 0%, #b88a18 100%)",
        border: "1px solid rgba(212,175,55,0.6)",
        boxShadow:
          "0 4px 18px rgba(0,0,0,0.45), 0 0 0 2px rgba(212,175,55,0.18), inset 0 1px 0 rgba(255,255,255,0.18)",
        transition: "transform 0.22s ease, box-shadow 0.22s ease, opacity 0.22s ease",
        backdropFilter: "blur(4px)",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.transform = "translateY(-2px) scale(1.03)";
        (e.currentTarget as HTMLAnchorElement).style.boxShadow =
          "0 8px 28px rgba(0,0,0,0.55), 0 0 0 2px rgba(212,175,55,0.35), inset 0 1px 0 rgba(255,255,255,0.22)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.transform = "translateY(0) scale(1)";
        (e.currentTarget as HTMLAnchorElement).style.boxShadow =
          "0 4px 18px rgba(0,0,0,0.45), 0 0 0 2px rgba(212,175,55,0.18), inset 0 1px 0 rgba(255,255,255,0.18)";
      }}
    >
      <Home size={15} strokeWidth={2.5} />
      Homepage
    </Link>
  );
}
