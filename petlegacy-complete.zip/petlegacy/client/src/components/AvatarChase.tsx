import { useState, useRef, useEffect, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mic, MicOff, Volume2, VolumeX, Send, Play, Pause, Loader2, X } from "lucide-react";

// Real photo of Chase Brent Sawyer (young man in pink shirt, professional headshot)
const CHASE_AVATAR_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663426867735/fsfXd3zRR8wTvv9UGhd55p/chase-avatar_0e1d3426.jpg";

const INTRO_SCRIPT =
  "Hi, I'm Chase — your personal pet protection guide at Pet Legacy Planning. I'm here to help you understand your options, answer your questions, and make sure your pets are protected no matter what life brings. Ask me anything about pet planning, our packages, or how to get started.";

const SUGGESTED_QUESTIONS = [
  "What is Pet Legacy Planning?",
  "What's included in the Ultimate Kit?",
  "How does the Platinum service work?",
  "Why do I need a pet protection plan?",
  "What happens to my pets if I'm hospitalized?",
];

type Message = { role: "user" | "chase"; text: string };

interface AvatarChaseProps {
  compact?: boolean;
  initialMessage?: string;
}

export default function AvatarChase({ compact = false, initialMessage }: AvatarChaseProps) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: "chase", text: initialMessage ?? INTRO_SCRIPT },
  ]);
  const [input, setInput] = useState("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [mouthOpen, setMouthOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);
  const mouthIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const askMutation = trpc.avatar.ask.useMutation({
    onSuccess: (data) => {
      const answer = String(data.answer);
      setMessages((prev) => [...prev, { role: "chase", text: answer }]);
      setIsTyping(false);
      if (voiceEnabled) speak(answer);
    },
    onError: () => {
      const fallback = "I'm sorry, I had trouble answering that. Please try again.";
      setMessages((prev) => [...prev, { role: "chase", text: fallback }]);
      setIsTyping(false);
      if (voiceEnabled) speak(fallback);
    },
  });

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const startMouthAnimation = useCallback(() => {
    if (mouthIntervalRef.current) clearInterval(mouthIntervalRef.current);
    mouthIntervalRef.current = setInterval(() => {
      setMouthOpen((v) => !v);
    }, 180);
  }, []);

  const stopMouthAnimation = useCallback(() => {
    if (mouthIntervalRef.current) clearInterval(mouthIntervalRef.current);
    setMouthOpen(false);
  }, []);

  const speak = useCallback(
    (text: string) => {
      if (!("speechSynthesis" in window)) return;
      synthRef.current = window.speechSynthesis;
      synthRef.current.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      utterance.volume = 1;
      const voices = synthRef.current.getVoices();
      const preferred = voices.find(
        (v) =>
          v.name.toLowerCase().includes("male") ||
          v.name.toLowerCase().includes("david") ||
          v.name.toLowerCase().includes("alex") ||
          v.name.toLowerCase().includes("daniel")
      );
      if (preferred) utterance.voice = preferred;
      utterance.onstart = () => { setIsSpeaking(true); startMouthAnimation(); };
      utterance.onend = () => { setIsSpeaking(false); stopMouthAnimation(); };
      utterance.onerror = () => { setIsSpeaking(false); stopMouthAnimation(); };
      synthRef.current.speak(utterance);
    },
    [startMouthAnimation, stopMouthAnimation]
  );

  useEffect(() => {
    if (voiceEnabled) {
      const t = setTimeout(() => speak(INTRO_SCRIPT), 900);
      return () => clearTimeout(t);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const stopSpeaking = useCallback(() => {
    synthRef.current?.cancel();
    setIsSpeaking(false);
    stopMouthAnimation();
  }, [stopMouthAnimation]);

  const toggleVoice = () => {
    if (voiceEnabled) stopSpeaking();
    setVoiceEnabled((v) => !v);
  };

  const startListening = () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const w = window as any;
    const SpeechRecognitionAPI = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
      alert("Voice input is not supported in this browser. Please type your question.");
      return;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const recognition: any = new SpeechRecognitionAPI();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognitionRef.current = recognition;
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onresult = (event: any) => {
      setInput(event.results[0][0].transcript);
    };
    recognition.onerror = () => setIsListening(false);
    recognition.start();
  };

  const stopListening = () => { recognitionRef.current?.stop(); setIsListening(false); };

  const handleSend = (question?: string) => {
    const q = (question ?? input).trim();
    if (!q) return;
    stopSpeaking();
    setMessages((prev) => [...prev, { role: "user", text: q }]);
    setInput("");
    setIsTyping(true);
    askMutation.mutate({ question: q });
  };

  const avatarPanel = (
    <div className="flex-shrink-0 flex flex-col items-center gap-3">
      <div
        className={`relative rounded-2xl overflow-hidden border-2 transition-all duration-300 ${isSpeaking ? "border-gold" : "border-gold/40"}`}
        style={{ width: 180, height: 220, boxShadow: isSpeaking ? "0 0 32px rgba(212,175,55,0.35)" : "0 0 16px rgba(212,175,55,0.12)" }}
      >
        <img
          src={CHASE_AVATAR_URL}
          alt="Chase — Your Pet Protection Guide"
          className="w-full h-full object-cover object-top"
        />
        {/* Mouth animation */}
        {isSpeaking && (
          <div
            className="absolute bottom-7 left-1/2 -translate-x-1/2 transition-all duration-100"
            style={{
              width: mouthOpen ? 26 : 20,
              height: mouthOpen ? 9 : 3,
              borderRadius: "50%",
              background: "rgba(0,0,0,0.5)",
              border: "1.5px solid rgba(212,175,55,0.45)",
            }}
          />
        )}
        {/* Sound bars */}
        {isSpeaking && (
          <div className="absolute top-3 right-3 flex gap-0.5 items-end h-4">
            {[1, 2, 3, 2, 1].map((h, i) => (
              <div
                key={i}
                className="w-1 bg-gold rounded-full animate-pulse"
                style={{ height: `${h * 5}px`, animationDelay: `${i * 80}ms` }}
              />
            ))}
          </div>
        )}
      </div>
      <p className="text-sm font-semibold text-gold">Chase</p>
      <p className="text-xs text-muted-foreground">Your Pet Protection Guide</p>
      <div className="flex gap-2">
        <Button
          size="sm"
          variant="outline"
          className={`border-gold/30 ${voiceEnabled ? "text-gold" : "text-muted-foreground"} hover:border-gold/60`}
          onClick={toggleVoice}
          title={voiceEnabled ? "Mute Chase" : "Unmute Chase"}
        >
          {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </Button>
        {isSpeaking ? (
          <Button size="sm" variant="outline" className="border-gold/30 text-gold hover:border-gold/60" onClick={stopSpeaking} title="Stop">
            <Pause className="w-4 h-4" />
          </Button>
        ) : (
          <Button
            size="sm"
            variant="outline"
            className="border-gold/30 text-muted-foreground hover:border-gold/60 hover:text-gold"
            onClick={() => {
              const last = [...messages].reverse().find((m) => m.role === "chase");
              if (last && voiceEnabled) speak(last.text);
            }}
            title="Replay"
          >
            <Play className="w-4 h-4" />
          </Button>
        )}
      </div>
    </div>
  );

  const chatPanel = (
    <div className="flex-1 flex flex-col gap-3 min-w-0">
      {/* Suggested questions */}
      <div className="flex flex-wrap gap-2">
        {SUGGESTED_QUESTIONS.map((q) => (
          <button
            key={q}
            onClick={() => handleSend(q)}
            className="text-xs px-3 py-1.5 rounded-full border border-gold/30 text-gold/80 hover:bg-gold/10 hover:text-gold transition-colors"
          >
            {q}
          </button>
        ))}
      </div>
      {/* Messages */}
      <div className="flex flex-col gap-3 overflow-y-auto pr-1" style={{ maxHeight: 300, minHeight: 140 }}>
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
            {msg.role === "chase" && (
              <img src={CHASE_AVATAR_URL} alt="Chase" className="w-8 h-8 rounded-full object-cover object-top flex-shrink-0 border border-gold/30" />
            )}
            <div
              className={`rounded-2xl px-4 py-3 text-sm leading-relaxed max-w-[80%] ${
                msg.role === "chase"
                  ? "bg-dark-elevated border border-gold/20 text-foreground/90"
                  : "bg-primary/20 border border-primary/30 text-foreground/90"
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex gap-2">
            <img src={CHASE_AVATAR_URL} alt="Chase" className="w-8 h-8 rounded-full object-cover object-top flex-shrink-0 border border-gold/30" />
            <div className="bg-dark-elevated border border-gold/20 rounded-2xl px-4 py-3 flex gap-1 items-center">
              {[0, 1, 2].map((i) => (
                <div key={i} className="w-2 h-2 rounded-full bg-gold/60 animate-bounce" style={{ animationDelay: `${i * 150}ms` }} />
              ))}
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>
      {/* Input */}
      <div className="flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Ask Chase anything about pet planning…"
          className="bg-input border-border text-sm"
        />
        <Button
          size="icon"
          variant="outline"
          className={`border-gold/30 flex-shrink-0 ${isListening ? "text-red-400 border-red-400/50 animate-pulse" : "text-gold hover:border-gold/60"}`}
          onClick={isListening ? stopListening : startListening}
          title={isListening ? "Stop listening" : "Speak your question"}
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </Button>
        <Button
          size="icon"
          className="bg-primary text-primary-foreground flex-shrink-0"
          onClick={() => handleSend()}
          disabled={askMutation.isPending || !input.trim()}
        >
          {askMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </Button>
      </div>
    </div>
  );

  if (compact) {
    return (
      <div className="relative">
        <button
          onClick={() => setOpen(!open)}
          className="flex items-center gap-2 px-4 py-2 rounded-full bg-dark-elevated border border-gold/30 text-sm text-gold hover:border-gold/60 transition-all"
        >
          <img src={CHASE_AVATAR_URL} alt="Chase" className="w-6 h-6 rounded-full object-cover object-top border border-gold/30" />
          <div className={`w-2 h-2 rounded-full bg-gold ${isSpeaking ? "animate-pulse" : ""}`} />
          Ask Chase
        </button>
        {open && (
          <div className="absolute bottom-12 right-0 w-96 bg-card border border-border rounded-xl shadow-2xl z-50 overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <div className="flex items-center gap-2">
                <img src={CHASE_AVATAR_URL} alt="Chase" className="w-7 h-7 rounded-full object-cover object-top border border-gold/30" />
                <span className="text-sm font-semibold text-gold">Chase — Pet Protection Guide</span>
              </div>
              <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4">{chatPanel}</div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row gap-8 items-start">
      {avatarPanel}
      {chatPanel}
    </div>
  );
}
