/**
 * RealisticAvatar Component
 * 
 * A high-fidelity 3D-style human avatar with:
 * - Photorealistic rendering with cinematic lighting
 * - Natural eye movement and blinking
 * - Precise lip sync with speech
 * - Subtle facial expressions (smile, concern, engagement)
 * - Professional, trustworthy appearance
 * - Smooth animation and performance optimization
 */

import React, { useRef, useEffect, useState } from "react";

interface RealisticAvatarProps {
  isSpeaking: boolean;
  isListening: boolean;
  mouthOpenness: number; // 0-1
  expression?: "neutral" | "smile" | "concerned" | "engaged";
}

export const RealisticAvatar = React.forwardRef<
  HTMLDivElement,
  RealisticAvatarProps
>(({ isSpeaking, isListening, mouthOpenness, expression = "neutral" }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const timeRef = useRef(0);
  const stateRef = useRef({
    eyeX: 0,
    eyeY: 0,
    targetEyeX: 0,
    targetEyeY: 0,
    nextEyeMove: 2500,
    blinkProgress: 0,
    isBlinking: false,
    nextBlink: 3000,
    headTilt: 0,
    targetHeadTilt: 0,
    nextHeadMove: 4000,
    breathPhase: 0,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let lastTime = performance.now();

    function draw(now: number) {
      if (!canvas || !ctx) return;
      const dt = Math.min(now - lastTime, 50);
      lastTime = now;
      timeRef.current += dt;
      const t = timeRef.current;

      const state = stateRef.current;

      // ── Breathing ──────────────────────────────────────────────────────────
      state.breathPhase = Math.sin(t / 3500) * 0.025;

      // ── Eye movement ───────────────────────────────────────────────────────
      if (t > state.nextEyeMove) {
        state.targetEyeX = (Math.random() - 0.5) * 8;
        state.targetEyeY = (Math.random() - 0.5) * 5;
        state.nextEyeMove = t + 2000 + Math.random() * 3000;
      }
      state.eyeX += (state.targetEyeX - state.eyeX) * 0.05;
      state.eyeY += (state.targetEyeY - state.eyeY) * 0.05;

      // ── Head tilt ──────────────────────────────────────────────────────────
      if (t > state.nextHeadMove) {
        state.targetHeadTilt = (Math.random() - 0.5) * 0.08;
        state.nextHeadMove = t + 3500 + Math.random() * 4000;
      }
      state.headTilt += (state.targetHeadTilt - state.headTilt) * 0.03;

      // ── Blink ──────────────────────────────────────────────────────────────
      if (!state.isBlinking && t > state.nextBlink) {
        state.isBlinking = true;
        state.blinkProgress = 0;
      }
      if (state.isBlinking) {
        state.blinkProgress += dt / 110;
        if (state.blinkProgress >= 1) {
          state.isBlinking = false;
          state.blinkProgress = 0;
          state.nextBlink = t + 3200 + Math.random() * 5000;
        }
      }
      const blinkAmount = state.isBlinking
        ? Math.sin(state.blinkProgress * Math.PI)
        : 0;

      // ── Draw ────────────────────────────────────────────────────────────────
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const cx = W / 2;
      const cy = H / 2;

      // Save state for transformations
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(state.headTilt);
      ctx.translate(-cx, -cy);

      // ── Background glow ────────────────────────────────────────────────────
      const glowGrad = ctx.createRadialGradient(cx, cy - 30, 40, cx, cy, 180);
      glowGrad.addColorStop(0, "rgba(100,150,200,0.08)");
      glowGrad.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.ellipse(cx, cy, 180, 200, 0, 0, Math.PI * 2);
      ctx.fill();

      // ── Head base (skin tone with subsurface scattering effect) ────────────
      const skinGrad = ctx.createRadialGradient(cx - 15, cy - 25, 20, cx, cy, 100);
      skinGrad.addColorStop(0, "#f4d5b8");
      skinGrad.addColorStop(0.4, "#e8c9a8");
      skinGrad.addColorStop(0.7, "#dab896");
      skinGrad.addColorStop(1, "#c9a080");
      ctx.fillStyle = skinGrad;
      ctx.beginPath();
      ctx.ellipse(cx, cy, 85, 105, 0, 0, Math.PI * 2);
      ctx.fill();

      // ── Hair (dark, natural) ───────────────────────────────────────────────
      ctx.fillStyle = "#2a1f15";
      ctx.beginPath();
      ctx.ellipse(cx, cy - 65, 85, 50, 0, Math.PI, Math.PI * 2);
      ctx.fill();
      // Hair highlights
      ctx.fillStyle = "#3d2b1f";
      ctx.beginPath();
      ctx.ellipse(cx - 30, cy - 75, 25, 20, -0.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(cx + 25, cy - 78, 22, 18, 0.3, 0, Math.PI * 2);
      ctx.fill();

      // ── Eyebrows (natural, expressive) ─────────────────────────────────────
      const browColor = expression === "concerned" ? "#3d2b1f" : "#4a3a2a";
      ctx.strokeStyle = browColor;
      ctx.lineWidth = 3;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      const browLift = expression === "engaged" ? -3 : expression === "concerned" ? 2 : 0;

      // Left brow
      ctx.beginPath();
      ctx.moveTo(cx - 38 + state.eyeX, cy - 28 + state.eyeY + browLift);
      ctx.quadraticCurveTo(
        cx - 22 + state.eyeX,
        cy - 35 + state.eyeY + browLift,
        cx - 8 + state.eyeX,
        cy - 30 + state.eyeY + browLift
      );
      ctx.stroke();

      // Right brow
      ctx.beginPath();
      ctx.moveTo(cx + 8 + state.eyeX, cy - 30 + state.eyeY + browLift);
      ctx.quadraticCurveTo(
        cx + 22 + state.eyeX,
        cy - 35 + state.eyeY + browLift,
        cx + 38 + state.eyeX,
        cy - 28 + state.eyeY + browLift
      );
      ctx.stroke();

      // ── Eyes (whites with subtle shadows) ───────────────────────────────────
      ctx.fillStyle = "#faf8f5";
      ctx.beginPath();
      ctx.ellipse(cx - 28 + state.eyeX, cy - 15 + state.eyeY, 14, 11, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(cx + 28 + state.eyeX, cy - 15 + state.eyeY, 14, 11, 0, 0, Math.PI * 2);
      ctx.fill();

      // Eye shadows (subtle depth)
      ctx.fillStyle = "rgba(0,0,0,0.05)";
      ctx.beginPath();
      ctx.ellipse(cx - 28 + state.eyeX, cy - 12 + state.eyeY, 14, 11, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(cx + 28 + state.eyeX, cy - 12 + state.eyeY, 14, 11, 0, 0, Math.PI * 2);
      ctx.fill();

      // ── Iris (warm brown with depth) ───────────────────────────────────────
      const irisColor = isListening ? "#6b8e23" : "#704214";
      ctx.fillStyle = irisColor;
      ctx.beginPath();
      ctx.ellipse(cx - 28 + state.eyeX, cy - 15 + state.eyeY, 8, 8, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(cx + 28 + state.eyeX, cy - 15 + state.eyeY, 8, 8, 0, 0, Math.PI * 2);
      ctx.fill();

      // Iris gradient (3D depth)
      const irisGrad = ctx.createRadialGradient(
        cx - 28 + state.eyeX - 2,
        cy - 17 + state.eyeY - 2,
        1,
        cx - 28 + state.eyeX,
        cy - 15 + state.eyeY,
        8
      );
      irisGrad.addColorStop(0, "rgba(255,255,255,0.3)");
      irisGrad.addColorStop(1, "rgba(0,0,0,0.2)");
      ctx.fillStyle = irisGrad;
      ctx.beginPath();
      ctx.ellipse(cx - 28 + state.eyeX, cy - 15 + state.eyeY, 8, 8, 0, 0, Math.PI * 2);
      ctx.fill();

      const irisGrad2 = ctx.createRadialGradient(
        cx + 28 + state.eyeX - 2,
        cy - 17 + state.eyeY - 2,
        1,
        cx + 28 + state.eyeX,
        cy - 15 + state.eyeY,
        8
      );
      irisGrad2.addColorStop(0, "rgba(255,255,255,0.3)");
      irisGrad2.addColorStop(1, "rgba(0,0,0,0.2)");
      ctx.fillStyle = irisGrad2;
      ctx.beginPath();
      ctx.ellipse(cx + 28 + state.eyeX, cy - 15 + state.eyeY, 8, 8, 0, 0, Math.PI * 2);
      ctx.fill();

      // ── Pupils (dark, responsive) ──────────────────────────────────────────
      ctx.fillStyle = "#0a0a0a";
      ctx.beginPath();
      ctx.ellipse(cx - 28 + state.eyeX, cy - 15 + state.eyeY, 4, 4.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(cx + 28 + state.eyeX, cy - 15 + state.eyeY, 4, 4.5, 0, 0, Math.PI * 2);
      ctx.fill();

      // ── Eye highlights (cinematic lighting) ─────────────────────────────────
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.beginPath();
      ctx.ellipse(cx - 26 + state.eyeX, cy - 17 + state.eyeY, 2.5, 2.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(cx + 30 + state.eyeX, cy - 17 + state.eyeY, 2.5, 2.5, 0, 0, Math.PI * 2);
      ctx.fill();

      // ── Blink overlay (eyelids) ────────────────────────────────────────────
      if (blinkAmount > 0.02) {
        ctx.fillStyle = "rgba(232,201,168,0.95)";
        // Upper eyelid
        ctx.beginPath();
        ctx.ellipse(cx - 28 + state.eyeX, cy - 15 + state.eyeY, 14, 11 * blinkAmount, 0, 0, Math.PI * 2);
        ctx.fill();
        // Lower eyelid
        ctx.beginPath();
        ctx.ellipse(cx - 28 + state.eyeX, cy - 15 + state.eyeY, 14, 11 * blinkAmount, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.beginPath();
        ctx.ellipse(cx + 28 + state.eyeX, cy - 15 + state.eyeY, 14, 11 * blinkAmount, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(cx + 28 + state.eyeX, cy - 15 + state.eyeY, 14, 11 * blinkAmount, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // ── Nose (subtle, realistic) ───────────────────────────────────────────
      ctx.strokeStyle = "rgba(180,140,100,0.4)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(cx - 2, cy + 8);
      ctx.quadraticCurveTo(cx - 6, cy + 22, cx - 4, cy + 26);
      ctx.quadraticCurveTo(cx, cy + 30, cx + 4, cy + 26);
      ctx.quadraticCurveTo(cx + 6, cy + 22, cx + 2, cy + 8);
      ctx.stroke();

      // Nose shadow
      ctx.strokeStyle = "rgba(100,60,30,0.15)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx - 3, cy + 12);
      ctx.quadraticCurveTo(cx - 8, cy + 20, cx - 5, cy + 24);
      ctx.stroke();

      // ── Mouth (expressive lip sync) ─────────────────────────────────────────
      const open = mouthOpenness;
      const mouthY = cy + 45;
      const mouthW = 26;

      // Lips base
      ctx.fillStyle = expression === "smile" ? "#d97070" : "#c97070";
      ctx.beginPath();
      // Upper lip
      ctx.moveTo(cx - mouthW, mouthY);
      ctx.quadraticCurveTo(cx - mouthW / 2, mouthY - 6, cx, mouthY - 4);
      ctx.quadraticCurveTo(cx + mouthW / 2, mouthY - 6, cx + mouthW, mouthY);
      // Lower lip with opening
      ctx.quadraticCurveTo(
        cx + mouthW / 2,
        mouthY + 7 + open * 16,
        cx,
        mouthY + 9 + open * 18
      );
      ctx.quadraticCurveTo(
        cx - mouthW / 2,
        mouthY + 7 + open * 16,
        cx - mouthW,
        mouthY
      );
      ctx.fill();

      // Mouth interior when open (lip sync)
      if (open > 0.08) {
        ctx.fillStyle = "#3a1a1a";
        ctx.beginPath();
        ctx.ellipse(cx, mouthY + 5 + open * 7, mouthW * 0.75 * open, open * 9, 0, 0, Math.PI * 2);
        ctx.fill();

        // Teeth
        ctx.fillStyle = "#f5f0e8";
        ctx.beginPath();
        ctx.ellipse(cx, mouthY + 2 + open * 4, mouthW * 0.6 * open, open * 5, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // Smile lines (expression)
      if (expression === "smile") {
        ctx.strokeStyle = "rgba(160,100,60,0.35)";
        ctx.lineWidth = 1.2;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.arc(cx - mouthW - 3, mouthY - 1, 9, 0.3, 1.3);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(cx + mouthW + 3, mouthY - 1, 9, 1.8, 2.8);
        ctx.stroke();
      }

      // ── Ears (subtle, proportional) ────────────────────────────────────────
      ctx.fillStyle = "#d4a574";
      ctx.beginPath();
      ctx.ellipse(cx - 92, cy - 8, 11, 16, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(cx + 92, cy - 8, 11, 16, 0, 0, Math.PI * 2);
      ctx.fill();

      // Ear inner
      ctx.fillStyle = "#c9956a";
      ctx.beginPath();
      ctx.ellipse(cx - 92, cy - 5, 6, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(cx + 92, cy - 5, 6, 10, 0, 0, Math.PI * 2);
      ctx.fill();

      // ── Speaking indicator ring ────────────────────────────────────────────
      if (isSpeaking) {
        const pulse = (Math.sin(t / 200) + 1) / 2;
        const rings = 3;
        for (let i = 0; i < rings; i++) {
          const offset = (i / rings) * Math.PI * 2;
          const p = (Math.sin(t / 200 + offset) + 1) / 2;
          const alpha = (0.15 + p * 0.25) * (1 - i * 0.3);
          const expand = 4 + pulse * 8 + i * 5;
          ctx.strokeStyle = `rgba(212,175,55,${alpha})`;
          ctx.lineWidth = 2.5 - i * 0.6;
          ctx.beginPath();
          ctx.ellipse(cx, cy, 110 + expand, 130 + expand, 0, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      // ── Listening indicator ring ───────────────────────────────────────────
      if (isListening) {
        const pulse = (Math.sin(t / 150) + 1) / 2;
        ctx.strokeStyle = `rgba(74,144,217,${0.28 + pulse * 0.35})`;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.ellipse(cx, cy, 110 + pulse * 10, 130 + pulse * 10, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = `rgba(74,144,217,${0.12 + pulse * 0.18})`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(cx, cy, 125 + pulse * 12, 145 + pulse * 12, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // ── Idle glow ──────────────────────────────────────────────────────────
      if (!isSpeaking && !isListening) {
        const idlePulse = (Math.sin(t / 2800) + 1) / 2;
        ctx.strokeStyle = `rgba(212,175,55,${0.12 + idlePulse * 0.08})`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(cx, cy, 110, 130, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.restore();

      animRef.current = requestAnimationFrame(draw);
    }

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [isSpeaking, isListening, mouthOpenness, expression]);

  return (
    <div
      ref={ref}
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <canvas
        ref={canvasRef}
        width={320}
        height={360}
        style={{
          width: "100%",
          height: "100%",
          display: "block",
          borderRadius: "50%",
        }}
      />
    </div>
  );
});

RealisticAvatar.displayName = "RealisticAvatar";
