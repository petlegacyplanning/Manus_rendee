declare module '@sage-rsc/narrator-avatar' {
  import { ForwardRefExoticComponent, RefAttributes } from 'react';

  export interface NarratorAvatarRef {
    speakText(text: string, options?: Record<string, unknown>): void;
    pauseSpeaking(): void;
    resumeSpeaking(): void;
    stopSpeaking(): void;
    isReady: boolean;
    isSpeaking: boolean;
  }

  export interface NarratorAvatarProps {
    avatarUrl?: string;
    avatarBody?: 'M' | 'F';
    cameraView?: 'full' | 'upper' | 'mid' | 'head';
    cameraRotateEnable?: boolean;
    cameraZoomEnable?: boolean;
    cameraPanEnable?: boolean;
    ttsService?: 'google' | 'deepgram';
    ttsVoice?: string;
    ttsApiKey?: string;
    lipsyncModules?: string[];
    lipsyncLang?: string;
    accurateLipSync?: boolean;
    speechRate?: number;
    speechGestures?: boolean;
    onReady?: () => void;
    onError?: (err: Error) => void;
    onSpeechStart?: (text: string) => void;
    onSpeechEnd?: () => void;
    onSubtitle?: (text: string) => void;
  }

  const NarratorAvatar: ForwardRefExoticComponent<NarratorAvatarProps & RefAttributes<NarratorAvatarRef>>;
  export default NarratorAvatar;
}
