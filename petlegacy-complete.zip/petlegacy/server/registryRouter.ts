import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import {
  createRegistryRecord,
  deleteRegistryRecord,
  getRegistryRecord,
  getUserRegistryRecords,
  searchRegistryByPetName,
  updateRegistryRecord,
} from "./db";

export const registryRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        petName: z.string(),
        petSpecies: z.string(),
        petBreed: z.string().optional(),
        petAge: z.number().optional(),
        petMicrochipId: z.string().optional(),
        petMedicalNotes: z.string().optional(),
        guardianName: z.string(),
        guardianPhone: z.string(),
        guardianEmail: z.string().optional(),
        guardianAddress: z.string().optional(),
        emergencyContactName: z.string().optional(),
        emergencyContactPhone: z.string().optional(),
        emergencyContactRelationship: z.string().optional(),
        state: z.string(),
        city: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check if user has purchased a plan
      if (ctx.user.planTier === "free") {
        throw new Error("FORBIDDEN: Registry requires Premium plan or higher");
      }
      return createRegistryRecord({ userId: ctx.user.id, ...input });
    }),

  list: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.planTier === "free") {
      throw new Error("FORBIDDEN: Registry requires Premium plan or higher");
    }
    return getUserRegistryRecords(ctx.user.id);
  }),

  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      if (ctx.user.planTier === "free") {
        throw new Error("FORBIDDEN: Registry requires Premium plan or higher");
      }
      return getRegistryRecord(input.id, ctx.user.id);
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        petName: z.string().optional(),
        petSpecies: z.string().optional(),
        petBreed: z.string().optional(),
        petAge: z.number().optional(),
        petMicrochipId: z.string().optional(),
        petMedicalNotes: z.string().optional(),
        guardianName: z.string().optional(),
        guardianPhone: z.string().optional(),
        guardianEmail: z.string().optional(),
        guardianAddress: z.string().optional(),
        emergencyContactName: z.string().optional(),
        emergencyContactPhone: z.string().optional(),
        emergencyContactRelationship: z.string().optional(),
        state: z.string().optional(),
        city: z.string().optional(),
        registrationStatus: z.enum(["active", "inactive", "pending"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.planTier === "free") {
        throw new Error("FORBIDDEN: Registry requires Premium plan or higher");
      }
      const { id, ...data } = input;
      return updateRegistryRecord(id, ctx.user.id, data);
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.planTier === "free") {
        throw new Error("FORBIDDEN: Registry requires Premium plan or higher");
      }
      return deleteRegistryRecord(input.id, ctx.user.id);
    }),

  search: protectedProcedure
    .input(z.object({ petName: z.string() }))
    .query(async ({ ctx, input }) => {
      if (ctx.user.planTier === "free") {
        throw new Error("FORBIDDEN: Registry requires Premium plan or higher");
      }
      return searchRegistryByPetName(ctx.user.id, input.petName);
    }),
});
