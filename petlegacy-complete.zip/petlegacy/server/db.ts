import { and, desc, eq, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  adoptionListings,
  affiliateCodes,
  campaignLeads,
  communityEntries,
  directoryListings,
  libraryArticles,
  memorialEntries,
  newsletterIssues,
  newsletterSubscribers,
  orders,
  organizations,
  outreachCampaigns,
  petGuardianRegistry,
  pets,
  planSections,
  plannerProjects,
  planWorkspaces,
  platinumClients,
  promoCodes,
  quizResponses,
  registeredPets,
  rehomingListings,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { sql } from "drizzle-orm";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach((field) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ─── Promo Codes ──────────────────────────────────────────────────────────────
// ─── Quiz Responses ──────────────────────────────────────────────────────────
export async function recordQuizResponse(userId: number | null, score: number, answers: Record<string, boolean>) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(quizResponses).values({
    userId: userId || null,
    score,
    answers: JSON.stringify(answers),
  });
  return result;
}

// ─── Planner Projects ────────────────────────────────────────────────────────
export async function createPlannerProject(userId: number, planTier: string, title: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(plannerProjects).values({
    userId,
    planTier: planTier as any,
    title,
    status: "in_progress",
    currentStep: 0,
    totalSteps: 8,
    data: {},
  });
  return result;
}

export async function getUserPlannerProjects(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(plannerProjects).where(sql`userId = ${userId}`);
}

export async function getPlannerProject(projectId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(plannerProjects).where(sql`id = ${projectId}`);
  return result[0] || null;
}

export async function updatePlannerProject(projectId: number, updates: { currentStep?: number; data?: any; status?: string }) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .update(plannerProjects)
    .set({
      currentStep: updates.currentStep,
      data: updates.data,
      status: updates.status as any,
      updatedAt: new Date(),
    })
    .where(sql`id = ${projectId}`);
  return result;
}

export async function deletePlannerProject(projectId: number) {
  const db = await getDb();
  if (!db) return null;
  return await db.delete(plannerProjects).where(sql`id = ${projectId}`);
}

export async function getQuizStats() {
  const db = await getDb();
  if (!db) return null;

  // Get all responses
  const allResponses = await db.select().from(quizResponses);
  
  if (allResponses.length === 0) {
    return {
      totalResponses: 0,
      averageScore: 0,
      highestScore: 0,
      lowestScore: 0,
      scoreDistribution: [],
      tierBreakdown: [],
    };
  }

  const scores = allResponses.map(r => r.score);
  const totalResponses = scores.length;
  const averageScore = scores.reduce((a, b) => a + b, 0) / totalResponses;
  const highestScore = Math.max(...scores);
  const lowestScore = Math.min(...scores);

  // Score distribution
  const distribution: Record<number, number> = {};
  for (let i = 0; i <= 5; i++) {
    distribution[i] = scores.filter(s => s === i).length;
  }

  const scoreDistribution = Object.entries(distribution)
    .filter(([_, count]) => count > 0)
    .map(([score, count]) => ({
      score: parseInt(score),
      count,
      percentage: (count / totalResponses) * 100,
    }))
    .sort((a, b) => a.score - b.score);

  // Tier breakdown
  const tierCounts = {
    "Free Checklist": scores.filter(s => s <= 1).length,
    "Basic Kit": scores.filter(s => s === 2 || s === 3).length,
    "Ultimate Kit": scores.filter(s => s === 4).length,
    "Platinum Service": scores.filter(s => s === 5).length,
  };

  const tierBreakdown = [
    { tier: "Free Checklist", count: tierCounts["Free Checklist"], color: "#6B7280" },
    { tier: "Basic Kit", count: tierCounts["Basic Kit"], color: "#3B82F6" },
    { tier: "Ultimate Kit", count: tierCounts["Ultimate Kit"], color: "#F59E0B" },
    { tier: "Platinum Service", count: tierCounts["Platinum Service"], color: "#10B981" },
  ].map(tier => ({
    ...tier,
    percentage: (tier.count / totalResponses) * 100,
  }));

  return {
    totalResponses,
    averageScore,
    highestScore,
    lowestScore,
    scoreDistribution,
    tierBreakdown,
  };
}

export async function validatePromoCode(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(promoCodes).where(
    and(eq(promoCodes.code, code.toUpperCase()), eq(promoCodes.active, true))
  ).limit(1);
  const promo = result[0];
  if (!promo) return null;
  if (promo.maxUses && promo.uses >= promo.maxUses) return null;
  if (promo.expiresAt && promo.expiresAt < new Date()) return null;
  return promo;
}

export async function usePromoCode(code: string) {
  const db = await getDb();
  if (!db) return;
  const promo = await validatePromoCode(code);
  if (!promo) return;
  await db.update(promoCodes).set({ uses: promo.uses + 1 }).where(eq(promoCodes.code, code.toUpperCase()));
}

// ─── Affiliate Codes ──────────────────────────────────────────────────────────
export async function validateAffiliateCode(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(affiliateCodes).where(
    and(eq(affiliateCodes.code, code.toUpperCase()), eq(affiliateCodes.active, true))
  ).limit(1);
  return result[0] ?? null;
}

export async function trackAffiliateVisit(code: string) {
  const db = await getDb();
  if (!db) return;
  const aff = await validateAffiliateCode(code);
  if (!aff) return;
  await db.update(affiliateCodes).set({ visits: aff.visits + 1 }).where(eq(affiliateCodes.code, code.toUpperCase()));
}

export async function trackAffiliateConversion(code: string, amount: number) {
  const db = await getDb();
  if (!db) return;
  const aff = await validateAffiliateCode(code);
  if (!aff) return;
  const newRevenue = parseFloat(aff.totalRevenue ?? "0") + amount;
  await db.update(affiliateCodes).set({
    conversions: aff.conversions + 1,
    totalRevenue: newRevenue.toFixed(2),
  }).where(eq(affiliateCodes.code, code.toUpperCase()));
}

// ─── Newsletter ───────────────────────────────────────────────────────────────
export async function getPublishedNewsletterIssues() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(newsletterIssues).where(eq(newsletterIssues.published, true)).orderBy(desc(newsletterIssues.issueNumber));
}

export async function getNewsletterIssueByNumber(issueNumber: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(newsletterIssues).where(
    and(eq(newsletterIssues.issueNumber, issueNumber), eq(newsletterIssues.published, true))
  ).limit(1);
  return result[0] ?? null;
}

export async function subscribeNewsletter(email: string, name?: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(newsletterSubscribers).values({ email, name, active: true }).onDuplicateKeyUpdate({ set: { active: true } });
}

// ─── Library ──────────────────────────────────────────────────────────────────
export async function getLibraryHubs() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({ hub: libraryArticles.hub }).from(libraryArticles).where(eq(libraryArticles.published, true));
  const hubs = Array.from(new Set(rows.map((r) => r.hub)));
  return hubs;
}

export async function getLibraryArticlesByHub(hub: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(libraryArticles).where(
    and(eq(libraryArticles.hub, hub), eq(libraryArticles.published, true))
  ).orderBy(desc(libraryArticles.featured), desc(libraryArticles.createdAt));
}

export async function getLibraryArticleBySlug(slug: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(libraryArticles).where(
    and(eq(libraryArticles.slug, slug), eq(libraryArticles.published, true))
  ).limit(1);
  return result[0] ?? null;
}

export async function getFeaturedLibraryArticles() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(libraryArticles).where(
    and(eq(libraryArticles.published, true), eq(libraryArticles.featured, true))
  ).limit(6);
}

export async function getRelatedArticles(hub: string, excludeSlug: string) {
  const db = await getDb();
  if (!db) return [];
  // Get 4 articles from the same hub, excluding the current one
  const results = await db
    .select({
      id: libraryArticles.id,
      slug: libraryArticles.slug,
      title: libraryArticles.title,
      excerpt: libraryArticles.excerpt,
      hub: libraryArticles.hub,
    })
    .from(libraryArticles)
    .where(and(eq(libraryArticles.hub, hub), eq(libraryArticles.published, true)))
    .orderBy(desc(libraryArticles.featured), libraryArticles.id)
    .limit(5);
  // Filter out current article
  const filtered = results.filter((a) => a.slug !== excludeSlug).slice(0, 4);
  // If fewer than 4 from same hub, pad with articles from other hubs
  if (filtered.length < 4) {
    const extra = await db
      .select({
        id: libraryArticles.id,
        slug: libraryArticles.slug,
        title: libraryArticles.title,
        excerpt: libraryArticles.excerpt,
        hub: libraryArticles.hub,
      })
      .from(libraryArticles)
      .where(eq(libraryArticles.published, true))
      .orderBy(desc(libraryArticles.featured))
      .limit(8);
    const slugsSeen = new Set([excludeSlug, ...filtered.map((a) => a.slug)]);
    for (const a of extra) {
      if (!slugsSeen.has(a.slug)) {
        filtered.push(a);
        slugsSeen.add(a.slug);
      }
      if (filtered.length >= 4) break;
    }
  }
  return filtered;
}

export async function searchLibraryArticles(query: string, limit = 20) {
  const db = await getDb();
  if (!db || !query.trim()) return [];
  const q = `%${query.trim()}%`;
  return db
    .select({
      id: libraryArticles.id,
      slug: libraryArticles.slug,
      title: libraryArticles.title,
      excerpt: libraryArticles.excerpt,
      hub: libraryArticles.hub,
      featured: libraryArticles.featured,
    })
    .from(libraryArticles)
    .where(
      and(
        eq(libraryArticles.published, true),
        or(
          like(libraryArticles.title, q),
          like(libraryArticles.excerpt, q),
          like(libraryArticles.metaDesc, q)
        )
      )
    )
    .orderBy(desc(libraryArticles.featured), desc(libraryArticles.createdAt))
    .limit(limit);
}

export async function getAllLibraryArticleSlugs() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ slug: libraryArticles.slug, hub: libraryArticles.hub, updatedAt: libraryArticles.updatedAt })
    .from(libraryArticles)
    .where(eq(libraryArticles.published, true))
    .orderBy(libraryArticles.hub, libraryArticles.id);
}

// ─── Community ────────────────────────────────────────────────────────────────
export async function getFeaturedCommunityEntries(category: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(communityEntries).where(
    and(
      eq(communityEntries.category, category as any),
      eq(communityEntries.approved, true),
      eq(communityEntries.featured, true)
    )
  ).orderBy(desc(communityEntries.createdAt)).limit(4);
}

export async function getCommunityEntriesByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(communityEntries).where(
    and(eq(communityEntries.category, category as any), eq(communityEntries.approved, true))
  ).orderBy(desc(communityEntries.createdAt)).limit(20);
}

export async function submitCommunityEntry(data: {
  userId?: number;
  category: string;
  petName: string;
  ownerName?: string;
  species?: string;
  breed?: string;
  story?: string;
  city?: string;
  state?: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(communityEntries).values({ ...data, category: data.category as any, approved: false, featured: false });
}

// ─── Adoption ─────────────────────────────────────────────────────────────────
export async function getApprovedAdoptionListings(state?: string) {
  const db = await getDb();
  if (!db) return [];
  if (state) {
    return db.select().from(adoptionListings).where(and(eq(adoptionListings.approved, true), eq(adoptionListings.status, "available"), eq(adoptionListings.state, state))).orderBy(desc(adoptionListings.featured), desc(adoptionListings.createdAt)).limit(20);
  }
  return db.select().from(adoptionListings).where(and(eq(adoptionListings.approved, true), eq(adoptionListings.status, "available"))).orderBy(desc(adoptionListings.featured), desc(adoptionListings.createdAt)).limit(20);
}

// ─── Rehoming ─────────────────────────────────────────────────────────────────
export async function getApprovedRehomingListings(state?: string) {
  const db = await getDb();
  if (!db) return [];
  if (state) {
    return db.select().from(rehomingListings).where(and(eq(rehomingListings.approved, true), eq(rehomingListings.status, "active"), eq(rehomingListings.state, state))).orderBy(desc(rehomingListings.createdAt)).limit(20);
  }
  return db.select().from(rehomingListings).where(and(eq(rehomingListings.approved, true), eq(rehomingListings.status, "active"))).orderBy(desc(rehomingListings.createdAt)).limit(20);
}

export async function submitRehomingListing(data: {
  userId: number;
  petName: string;
  species?: string;
  breed?: string;
  age?: string;
  description?: string;
  reason?: string;
  city?: string;
  state?: string;
  contactEmail?: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(rehomingListings).values({ ...data, status: "pending_review", approved: false });
}

// ─── Memorials ────────────────────────────────────────────────────────────────
export async function getApprovedMemorials() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(memorialEntries).where(eq(memorialEntries.approved, true)).orderBy(desc(memorialEntries.featured), desc(memorialEntries.createdAt)).limit(20);
}

export async function submitMemorial(data: {
  userId?: number;
  petName: string;
  species?: string;
  breed?: string;
  birthDate?: string;
  passDate?: string;
  tribute?: string;
  submitterName?: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(memorialEntries).values({ ...data, approved: false, featured: false });
}

// ─── Registered Pets ──────────────────────────────────────────────────────────
export async function getRegisteredPets() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(registeredPets).where(eq(registeredPets.approved, true)).orderBy(desc(registeredPets.createdAt)).limit(20);
}

// ─── Plan Workspace ───────────────────────────────────────────────────────────
export async function getOrCreateWorkspace(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const existing = await db.select().from(planWorkspaces).where(eq(planWorkspaces.userId, userId)).limit(1);
  if (existing[0]) return existing[0];
  await db.insert(planWorkspaces).values({ userId, tier: "free", completionPct: 0 });
  const created = await db.select().from(planWorkspaces).where(eq(planWorkspaces.userId, userId)).limit(1);
  return created[0] ?? null;
}

export async function getWorkspaceSections(workspaceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(planSections).where(eq(planSections.workspaceId, workspaceId));
}

export async function saveWorkspaceSection(workspaceId: number, sectionKey: string, data: unknown) {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(planSections).where(
    and(eq(planSections.workspaceId, workspaceId), eq(planSections.sectionKey, sectionKey))
  ).limit(1);
  if (existing[0]) {
    await db.update(planSections).set({ data: data as any, completed: true }).where(eq(planSections.id, existing[0].id));
  } else {
    await db.insert(planSections).values({ workspaceId, sectionKey, data: data as any, completed: true });
  }
  // Update completion percentage
  const allSections = await db.select().from(planSections).where(eq(planSections.workspaceId, workspaceId));
  const completed = allSections.filter((s) => s.completed).length;
  const total = 8; // 8 sections total
  const pct = Math.round((completed / total) * 100);
  await db.update(planWorkspaces).set({ completionPct: pct, lastSaved: new Date() }).where(eq(planWorkspaces.id, workspaceId));
}

// ─── Platinum ─────────────────────────────────────────────────────────────────
export async function getPlatinumClients() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(platinumClients).orderBy(desc(platinumClients.createdAt));
}

export async function getPlatinumClientByUserId(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(platinumClients).where(eq(platinumClients.userId, userId)).limit(1);
  return result[0] ?? null;
}

export async function updatePlatinumClientStatus(id: number, status: string, notes?: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(platinumClients).set({ status: status as any, notes: notes ?? undefined }).where(eq(platinumClients.id, id));
}

// ─── Orders ───────────────────────────────────────────────────────────────────
export async function createOrder(data: {
  userId: number;
  tier: "premium" | "ultimate" | "platinum";
  amount: number;
  promoCode?: string;
  affiliateCode?: string;
  discountApplied?: number;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(orders).values({
    ...data,
    amount: data.amount.toFixed(2) as any,
    discountApplied: (data.discountApplied ?? 0).toFixed(2) as any,
    status: "complete",
  });
  // Upgrade user tier
  await db.update(users).set({ planTier: data.tier }).where(eq(users.id, data.userId));
  // If platinum, create platinum client record
  if (data.tier === "platinum") {
    await db.insert(platinumClients).values({ userId: data.userId, status: "intake" }).onDuplicateKeyUpdate({ set: { status: "intake" } });
  }
  // Track affiliate conversion
  if (data.affiliateCode) {
    await trackAffiliateConversion(data.affiliateCode, data.amount);
  }
  // Use promo code
  if (data.promoCode) {
    await usePromoCode(data.promoCode);
  }
}

export async function getUserOrders(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const { eq } = await import("drizzle-orm");
  return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

// ─── Admin ────────────────────────────────────────────────────────────────────
export async function getAllUsers(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt)).limit(limit);
}

export async function getPendingModerationItems() {
  const db = await getDb();
  if (!db) return { community: [], rehoming: [], memorials: [], adoptions: [] };
  const [community, rehoming, memorials, adoptions] = await Promise.all([
    db.select().from(communityEntries).where(eq(communityEntries.approved, false)).limit(20),
    db.select().from(rehomingListings).where(eq(rehomingListings.approved, false)).limit(20),
    db.select().from(memorialEntries).where(eq(memorialEntries.approved, false)).limit(20),
    db.select().from(adoptionListings).where(eq(adoptionListings.approved, false)).limit(20),
  ]);
  return { community, rehoming, memorials, adoptions };
}

export async function getAffiliateStats() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(affiliateCodes).orderBy(desc(affiliateCodes.conversions));
}


// ─── Pet Guardian Registry ────────────────────────────────────────────────────
export async function createRegistryRecord(data: {
  userId: number;
  petName: string;
  petSpecies: string;
  petBreed?: string;
  petAge?: number;
  petMicrochipId?: string;
  petMedicalNotes?: string;
  guardianName: string;
  guardianPhone: string;
  guardianEmail?: string;
  guardianAddress?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelationship?: string;
  state: string;
  city: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  
  const result = await db.insert(petGuardianRegistry).values(data);
  return result;
}

export async function getUserRegistryRecords(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(petGuardianRegistry).where(eq(petGuardianRegistry.userId, userId));
}

export async function getRegistryRecord(id: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const record = await db.select().from(petGuardianRegistry).where(
    and(eq(petGuardianRegistry.id, id), eq(petGuardianRegistry.userId, userId))
  );
  
  return record[0] || null;
}

export async function updateRegistryRecord(id: number, userId: number, data: Partial<{
  petName: string;
  petSpecies: string;
  petBreed: string;
  petAge: number;
  petMicrochipId: string;
  petMedicalNotes: string;
  guardianName: string;
  guardianPhone: string;
  guardianEmail: string;
  guardianAddress: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  emergencyContactRelationship: string;
  state: string;
  city: string;
  registrationStatus: "active" | "inactive" | "pending";
}>) {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  
  return db.update(petGuardianRegistry).set(data).where(
    and(eq(petGuardianRegistry.id, id), eq(petGuardianRegistry.userId, userId))
  );
}

export async function deleteRegistryRecord(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not connected");
  
  return db.delete(petGuardianRegistry).where(
    and(eq(petGuardianRegistry.id, id), eq(petGuardianRegistry.userId, userId))
  );
}

export async function searchRegistryByPetName(userId: number, petName: string) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(petGuardianRegistry).where(
    and(
      eq(petGuardianRegistry.userId, userId),
      like(petGuardianRegistry.petName, `%${petName}%`)
    )
  );
}

// ─── Directory Listings ────────────────────────────────────────────────────────
export async function createDirectoryListing(data: any) {
  const db = await getDb();
  if (!db) return null;
  return await db.insert(directoryListings).values(data);
}

export async function getDirectoryListings(limit: number = 10, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(directoryListings).limit(limit).offset(offset);
}

export async function getDirectoryListingById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(directoryListings).where(eq(directoryListings.id, id));
  return result[0] || null;
}

export async function updateDirectoryListing(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return await db.update(directoryListings).set(data).where(eq(directoryListings.id, id));
}

export async function deleteDirectoryListing(id: number) {
  const db = await getDb();
  if (!db) return null;
  return await db.delete(directoryListings).where(eq(directoryListings.id, id));
}

export async function searchListingsByCity(city: string) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(directoryListings)
    .where(and(eq(directoryListings.city, city), eq(directoryListings.approvalStatus, "approved")));
}

export async function searchListingsByService(service: string) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(directoryListings)
    .where(and(like(directoryListings.businessType, `%${service}%`), eq(directoryListings.approvalStatus, "approved")));
}

export async function getApprovedListings(filters: any) {
  const db = await getDb();
  if (!db) return [];
  
  let conditions = [eq(directoryListings.approvalStatus, "approved")];

  if (filters.city) {
    conditions.push(eq(directoryListings.city, filters.city));
  }

  if (filters.service) {
    conditions.push(like(directoryListings.businessType, `%${filters.service}%`));
  }

  return await db
    .select()
    .from(directoryListings)
    .where(and(...conditions))
    .limit(filters.limit || 20);
}

// ─── Outreach Campaigns ────────────────────────────────────────────────────────
export async function createOutreachCampaign(data: any) {
  const db = await getDb();
  if (!db) return null;
  return await db.insert(outreachCampaigns).values(data);
}

export async function getOutreachCampaigns() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(outreachCampaigns);
}

export async function getOutreachCampaignById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(outreachCampaigns).where(eq(outreachCampaigns.id, id));
  return result[0] || null;
}

export async function updateOutreachCampaign(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return await db.update(outreachCampaigns).set(data).where(eq(outreachCampaigns.id, id));
}

// ─── Campaign Leads ────────────────────────────────────────────────────────────
export async function createCampaignLead(data: any) {
  const db = await getDb();
  if (!db) return null;
  return await db.insert(campaignLeads).values(data);
}

export async function getCampaignLeads(campaignId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(campaignLeads).where(eq(campaignLeads.campaignId, campaignId));
}

export async function updateCampaignLead(id: number, data: any) {
  const db = await getDb();
  if (!db) return null;
  return await db.update(campaignLeads).set(data).where(eq(campaignLeads.id, id));
}
