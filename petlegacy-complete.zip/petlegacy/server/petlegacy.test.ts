import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

// ─── Helpers ────────────────────────────────────────────────────────────────

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createAuthContext(overrides: Partial<AuthenticatedUser> = {}): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-openid",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createAdminContext(): TrpcContext {
  return createAuthContext({ role: "admin", openId: "admin-openid" });
}

// ─── Auth Tests ──────────────────────────────────────────────────────────────

describe("auth.me", () => {
  it("returns null for unauthenticated users", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user for authenticated users", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const result = await caller.auth.me();
    expect(result).not.toBeNull();
    expect(result?.email).toBe("test@example.com");
  });
});

describe("auth.logout", () => {
  it("clears session cookie and returns success", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(ctx.res.clearCookie).toHaveBeenCalledWith(
      COOKIE_NAME,
      expect.objectContaining({ maxAge: -1, httpOnly: true })
    );
  });
});

// ─── Plans Tests ─────────────────────────────────────────────────────────────

describe("plans.validatePromo", () => {
  it("returns invalid for unknown promo codes", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.plans.validatePromo({ code: "INVALID_CODE_XYZ" });
    expect(result.valid).toBe(false);
  });
});

// ─── Avatar Tests ─────────────────────────────────────────────────────────────

describe("avatar.ask", () => {
  it("returns an answer string", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.avatar.ask({ question: "What is pet protection planning?" });
    expect(result).toHaveProperty("answer");
    expect(typeof result.answer).toBe("string");
    expect(result.answer.length).toBeGreaterThan(0);
  });
});

// ─── Contact Tests ────────────────────────────────────────────────────────────

describe("contact.submit", () => {
  it("accepts valid contact form submissions", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.contact.submit({
      name: "Jane Smith",
      email: "jane@example.com",
      subject: "General Inquiry",
      message: "I have a question about your plans.",
    });
    expect(result).toHaveProperty("success", true);
  });

  it("rejects invalid email addresses", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(
      caller.contact.submit({
        name: "Jane Smith",
        email: "not-an-email",
        message: "Test message",
      })
    ).rejects.toThrow();
  });
});

// ─── Platinum Tests ───────────────────────────────────────────────────────────

describe("platinum.submitInquiry", () => {
  it("accepts valid platinum inquiry submissions", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    // Use a unique email each run to avoid duplicate key constraint
    const uniqueEmail = `jane-${Date.now()}@example.com`;
    const result = await caller.platinum.submitInquiry({
      name: "Jane Smith",
      email: uniqueEmail,
      phone: "555-0100",
      petCount: "2",
      notes: "Two dogs, one cat",
    });
    expect(result).toHaveProperty("success", true);
  });

  it("rejects invalid email", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(
      caller.platinum.submitInquiry({
        name: "Jane Smith",
        email: "bad-email",
      })
    ).rejects.toThrow();
  });
});

// ─── Workspace Tests ──────────────────────────────────────────────────────────

describe("workspace", () => {
  it("requires authentication to access workspace", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(caller.workspace.get()).rejects.toThrow();
  });

  it("requires authentication to save sections", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(
      caller.workspace.saveSection({
        sectionKey: "pet-profile",
        data: { petName: "Buddy" },
      })
    ).rejects.toThrow();
  });
});

// ─── Admin Guard Tests ────────────────────────────────────────────────────────

describe("admin procedures", () => {
  it("blocks non-admin users from admin procedures", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    await expect(caller.admin.users()).rejects.toThrow();
  });

  it("blocks unauthenticated users from admin procedures", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(caller.admin.users()).rejects.toThrow();
  });
});

// ─── Newsletter Tests ─────────────────────────────────────────────────────────

describe("newsletter.subscribe", () => {
  it("accepts valid email subscriptions", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.newsletter.subscribe({
      email: `test-${Date.now()}@example.com`,
      name: "Test User",
    });
    expect(result).toHaveProperty("success", true);
  });

  it("rejects invalid email", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(
      caller.newsletter.subscribe({ email: "not-valid" })
    ).rejects.toThrow();
  });
});
