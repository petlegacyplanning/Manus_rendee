import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { registryRouter } from "./registryRouter";
import { directoryRouter } from "./directoryRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  createOrder,
  createPlannerProject,
  deletePlannerProject,
  getAffiliateStats,
  getAllUsers,
  getApprovedAdoptionListings,
  getApprovedMemorials,
  getApprovedRehomingListings,
  getFeaturedCommunityEntries,
  getFeaturedLibraryArticles,
  getCommunityEntriesByCategory,
  getLibraryArticleBySlug,
  getLibraryArticlesByHub,
  getLibraryHubs,
  getRelatedArticles,
  getAllLibraryArticleSlugs,
  searchLibraryArticles,
  getNewsletterIssueByNumber,
  getOrCreateWorkspace,
  getPendingModerationItems,
  getPlannerProject,
  getPlatinumClientByUserId,
  getPlatinumClients,
  getPublishedNewsletterIssues,
  getRegisteredPets,
  getUserOrders,
  getUserPlannerProjects,
  getWorkspaceSections,
  saveWorkspaceSection,
  submitCommunityEntry,
  submitMemorial,
  submitRehomingListing,
  subscribeNewsletter,
  trackAffiliateVisit,
  updatePlatinumClientStatus,
  updatePlannerProject,
  validateAffiliateCode,
  validatePromoCode,
  createRegistryRecord,
  deleteRegistryRecord,
  getRegistryRecord,
  getUserRegistryRecords,
  searchRegistryByPetName,
  updateRegistryRecord,
} from "./db";
import { getDb } from "./db";
import {
  affiliateCodes,
  communityEntries,
  memorialEntries,
  rehomingListings,
  adoptionListings,
} from "../drizzle/schema";
import { eq } from "drizzle-orm";

// Admin guard middleware
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new Error("FORBIDDEN");
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  registry: registryRouter,
  directory: directoryRouter,

  // ─── Auth ──────────────────────────────────────────────────────────────────
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Plans / Promo / Checkout ──────────────────────────────────────────────
  plans: router({
    validatePromo: publicProcedure
      .input(z.object({ code: z.string() }))
      .mutation(async ({ input }) => {
        const promo = await validatePromoCode(input.code);
        if (!promo) return { valid: false, discountPct: 0 };
        return { valid: true, discountPct: promo.discountPct };
      }),

    validateAffiliate: publicProcedure
      .input(z.object({ code: z.string() }))
      .mutation(async ({ input }) => {
        const aff = await validateAffiliateCode(input.code);
        if (!aff) return { valid: false, discountPct: 0 };
        return { valid: true, discountPct: aff.discountPct, affiliateName: aff.affiliateName };
      }),

    trackAffiliateVisit: publicProcedure
      .input(z.object({ code: z.string() }))
      .mutation(async ({ input }) => {
        await trackAffiliateVisit(input.code);
        return { success: true };
      }),

    purchase: protectedProcedure
      .input(z.object({
        tier: z.enum(["premium", "ultimate", "platinum"]),
        promoCode: z.string().optional(),
        affiliateCode: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const prices = { premium: 47, ultimate: 97, platinum: 297 };
        let amount = prices[input.tier];
        let discountApplied = 0;
        // Apply promo or affiliate discount
        if (input.promoCode) {
          const promo = await validatePromoCode(input.promoCode);
          if (promo) {
            discountApplied = Math.round(amount * promo.discountPct / 100 * 100) / 100;
            amount = Math.round((amount - discountApplied) * 100) / 100;
          }
        } else if (input.affiliateCode) {
          const aff = await validateAffiliateCode(input.affiliateCode);
          if (aff) {
            discountApplied = Math.round(amount * aff.discountPct / 100 * 100) / 100;
            amount = Math.round((amount - discountApplied) * 100) / 100;
          }
        }
        await createOrder({
          userId: ctx.user.id,
          tier: input.tier,
          amount,
          promoCode: input.promoCode,
          affiliateCode: input.affiliateCode,
          discountApplied,
        });
        return { success: true, amount, discountApplied };
      }),
  }),

  // ─── Newsletter ────────────────────────────────────────────────────────────
  newsletter: router({
    list: publicProcedure.query(async () => {
      return getPublishedNewsletterIssues();
    }),
    getByNumber: publicProcedure
      .input(z.object({ issueNumber: z.number() }))
      .query(async ({ input }) => {
        return getNewsletterIssueByNumber(input.issueNumber);
      }),
    subscribe: publicProcedure
      .input(z.object({ email: z.string().email(), name: z.string().optional() }))
      .mutation(async ({ input }) => {
        await subscribeNewsletter(input.email, input.name);
        return { success: true };
      }),
  }),

  // ─── Library ───────────────────────────────────────────────────────────────
  library: router({
    hubs: publicProcedure.query(async () => {
      return getLibraryHubs();
    }),
    featured: publicProcedure.query(async () => {
      return getFeaturedLibraryArticles();
    }),
    byHub: publicProcedure
      .input(z.object({ hub: z.string() }))
      .query(async ({ input }) => {
        return getLibraryArticlesByHub(input.hub);
      }),
    bySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        return getLibraryArticleBySlug(input.slug);
      }),
    related: publicProcedure
      .input(z.object({ hub: z.string(), excludeSlug: z.string() }))
      .query(async ({ input }) => {
        return getRelatedArticles(input.hub, input.excludeSlug);
      }),
    allSlugs: publicProcedure.query(async () => {
      return getAllLibraryArticleSlugs();
    }),
    search: publicProcedure
      .input(z.object({ query: z.string().min(1).max(200), limit: z.number().min(1).max(50).optional() }))
      .query(async ({ input }) => {
        return searchLibraryArticles(input.query, input.limit ?? 20);
      }),
  }),

  // ─── Community ─────────────────────────────────────────────────────────────
  community: router({
    featured: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return getFeaturedCommunityEntries(input.category);
      }),
    byCategory: publicProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ input }) => {
        return getCommunityEntriesByCategory(input.category);
      }),
    submit: publicProcedure
      .input(z.object({
        category: z.string(),
        petName: z.string(),
        ownerName: z.string().optional(),
        species: z.string().optional(),
        breed: z.string().optional(),
        story: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await submitCommunityEntry({ ...input, userId: ctx.user?.id });
        return { success: true };
      }),
  }),

  // ─── Adoption ──────────────────────────────────────────────────────────────
  adoption: router({
    list: publicProcedure
      .input(z.object({ state: z.string().optional() }))
      .query(async ({ input }) => {
        return getApprovedAdoptionListings(input.state);
      }),
  }),

  // ─── Rehoming ──────────────────────────────────────────────────────────────
  rehoming: router({
    list: publicProcedure
      .input(z.object({ state: z.string().optional() }))
      .query(async ({ input }) => {
        return getApprovedRehomingListings(input.state);
      }),
    submit: protectedProcedure
      .input(z.object({
        petName: z.string(),
        species: z.string().optional(),
        breed: z.string().optional(),
        age: z.string().optional(),
        description: z.string().optional(),
        reason: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        contactEmail: z.string().email().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await submitRehomingListing({ ...input, userId: ctx.user.id });
        return { success: true };
      }),
  }),

  // ─── Memorials ─────────────────────────────────────────────────────────────
  memorials: router({
    list: publicProcedure.query(async () => {
      return getApprovedMemorials();
    }),
    submit: publicProcedure
      .input(z.object({
        petName: z.string(),
        species: z.string().optional(),
        breed: z.string().optional(),
        birthDate: z.string().optional(),
        passDate: z.string().optional(),
        tribute: z.string().optional(),
        submitterName: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await submitMemorial({ ...input, userId: ctx.user?.id });
        return { success: true };
      }),
  }),

  // ─── Registered Pets ───────────────────────────────────────────────────────
  registeredPets: router({
    list: publicProcedure.query(async () => {
      return getRegisteredPets();
    }),
  }),

  // ─── Workspace ─────────────────────────────────────────────────────────────
  workspace: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const workspace = await getOrCreateWorkspace(ctx.user.id);
      if (!workspace) return null;
      const sections = await getWorkspaceSections(workspace.id);
      return { workspace, sections };
    }),
    saveSection: protectedProcedure
      .input(z.object({
        sectionKey: z.string(),
        data: z.record(z.string(), z.unknown()),
      }))
      .mutation(async ({ input, ctx }) => {
        const workspace = await getOrCreateWorkspace(ctx.user.id);
        if (!workspace) throw new Error("Workspace not found");
        await saveWorkspaceSection(workspace.id, input.sectionKey, input.data);
        return { success: true };
      }),
  }),

  // ─── Platinum ──────────────────────────────────────────────────────────────
  platinum: router({
    submitInquiry: publicProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email(),
        phone: z.string().optional(),
        petCount: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        // Store inquiry in contact_messages table to avoid platinum_clients unique constraint
        const { contactMessages } = await import("../drizzle/schema");
        await db.insert(contactMessages).values({
          name: input.name,
          email: input.email,
          subject: "Platinum Done-For-You Inquiry",
          message: `Phone: ${input.phone ?? "N/A"} | Pets: ${input.petCount ?? "?"} | Notes: ${input.notes ?? "N/A"}`,
          type: "platinum",
        });
        return { success: true };
      }),
    myStatus: protectedProcedure.query(async ({ ctx }) => {
      return getPlatinumClientByUserId(ctx.user.id);
    }),
    // Admin: list all platinum clients
    adminList: adminProcedure.query(async () => {
      return getPlatinumClients();
    }),
    adminUpdateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["intake", "in_progress", "review", "complete"]),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await updatePlatinumClientStatus(input.id, input.status, input.notes);
        return { success: true };
      }),
  }),

  // ─── Admin ─────────────────────────────────────────────────────────────────
  admin: router({
    users: adminProcedure.query(async () => {
      return getAllUsers();
    }),
    moderation: adminProcedure.query(async () => {
      return getPendingModerationItems();
    }),
    affiliateStats: adminProcedure.query(async () => {
      return getAffiliateStats();
    }),
    approveItem: adminProcedure
      .input(z.object({
        type: z.enum(["community", "rehoming", "memorial", "adoption"]),
        id: z.number(),
        approved: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const tableMap = {
          community: communityEntries,
          rehoming: rehomingListings,
          memorial: memorialEntries,
          adoption: adoptionListings,
        };
        const table = tableMap[input.type];
        await db.update(table).set({ approved: input.approved }).where(eq(table.id, input.id));
        return { success: true };
      }),
    createAffiliateCode: adminProcedure
      .input(z.object({
        code: z.string(),
        affiliateName: z.string().optional(),
        discountPct: z.number().min(1).max(50),
        commissionPct: z.number().min(1).max(50),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.insert(affiliateCodes).values({ ...input, code: input.code.toUpperCase(), active: true });
        return { success: true };
      }),
  }),

  // ─── Contact ───────────────────────────────────────────────────────────────
  contact: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email(),
        subject: z.string().optional(),
        message: z.string(),
      }))
      .mutation(async ({ input }) => {
        const { notifyOwner } = await import("./_core/notification");
        await notifyOwner({
          title: `Contact Form: ${input.subject ?? "General"} from ${input.name}`,
          content: `From: ${input.name} <${input.email}>\nSubject: ${input.subject ?? "General"}\n\n${input.message}`,
        });
        return { success: true };
      }),
  }),

  // ─── Pet Map ────────────────────────────────────────────────────────────────
  petMap: router({
    listPins: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      const { petPins } = await import("../drizzle/schema");
      const pins = await db.select().from(petPins).where(eq(petPins.approved, true)).limit(500);
      return pins.map(p => ({
        id: p.id,
        petName: p.petName,
        breed: p.breed ?? "",
        city: p.city,
        state: p.state,
        story: p.story ?? "",
        lat: Number(p.lat),
        lng: Number(p.lng),
      }));
    }),

    addPin: publicProcedure
      .input(z.object({
        petName: z.string().min(1).max(100),
        breed: z.string().max(100).optional(),
        city: z.string().min(1).max(100),
        state: z.string().min(1).max(50),
        story: z.string().max(1000).optional(),
        lat: z.number(),
        lng: z.number(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");
        const { petPins } = await import("../drizzle/schema");
        await db.insert(petPins).values({
          petName: input.petName,
          breed: input.breed ?? null,
          city: input.city,
          state: input.state,
          story: input.story ?? null,
          lat: String(input.lat),
          lng: String(input.lng),
          approved: true,
        });
        return { success: true };
      }),
  }),

  // ─── Chase Guided Tour Q&A ────────────────────────────────────────────────
  chase: router({
    askWithKnowledge: publicProcedure
      .input(z.object({ question: z.string().max(1200) }))
      .mutation(async ({ input }) => {
        // Search for relevant articles to ground the answer
        const relevantArticles = await searchLibraryArticles(input.question, 5);
        const articleContext = relevantArticles
          .map((a) => `- "${a.title}" (${a.hub}): ${a.excerpt}`)
          .join("\n");
        
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are Chase, the warm and knowledgeable guide for Pet Legacy Planning (PetLegacyPlanning.com). You are 30 years old, speak at a medium pace, and have a caring, storytelling style — like a trusted friend who genuinely knows this topic inside and out.

YOU HAVE ACCESS TO OUR KNOWLEDGE LIBRARY
Here are relevant articles from our library that may help answer this question:
${articleContext || "(No specific articles found, but use your general knowledge)"}

YOUR PERSONALITY
- Warm, genuine, and encouraging — never robotic or clinical
- You speak conversationally, using real examples and relatable language
- You care deeply about pets and the families who love them
- You acknowledge emotions — planning for a pet's future is a sensitive topic

WHAT YOU KNOW

Pet Legacy Planning: The process of documenting pet care needs, designating trusted guardians, creating emergency care instructions, and legally protecting pets through wills, trusts, and care agreements.

Why It Matters:
- Over 500,000 pets end up in shelters each year because owners had no plan
- Without a plan, courts treat pets as property and can assign them to anyone
- Emergency responders won't know pets exist without an emergency card
- Pets grieve and suffer from sudden changes in care

Plans & Pricing:
- Free Checklist: Basic downloadable checklist, no cost
- Premium Kit ($34.95): Core planning documents, guardian designation form, emergency care card, digital storage
- Ultimate Kit ($69.95): Everything in Premium + pet trust template, legal documentation guide, 50-state law reference, memorial planning, rehoming safety guide, lifetime access
- Platinum Service ($179.95): Everything in Ultimate + our team personally builds your complete plan with you, 1-on-1 consultation, custom documents, priority support

Pet Trusts:
- A legally enforceable arrangement setting aside money and instructions for pet care after death or incapacity
- All 50 US states recognize pet trusts as legally valid
- Names a trustee (manages money) AND a caregiver (cares for the pet) — can be different people
- Typical funding: $5,000–$50,000 depending on pet age and needs
- Without a trust, money left "for a pet" in a will is NOT legally enforceable

Pet Guardianship:
- Designate a primary AND backup guardian
- Always ask the person first — never assume
- Include care instructions: feeding, vet info, medications, behavioral quirks, favorite toys
- Consider: space, other pets, allergies, financial ability

Emergency Planning:
- Emergency pet card for wallet with pet name, vet, and emergency contact
- Emergency pet stickers on front door for first responders
- Pet emergency binder: vet records, medications, feeding instructions, photos
- Name an emergency temporary caregiver who can take pet within 24 hours

What Happens Without a Plan:
- Pets may be surrendered to shelters by family members who can't care for them
- Pets can be euthanized if no one claims them within the shelter hold period
- Courts treat pets as property — awarded to anyone in estate disputes
- Informal money left "for the pet" in a will is not legally binding

Pet Estate Planning:
- Include pets in your will — name a guardian and leave funds for care
- Pet trust is stronger than a will provision because it's legally enforceable
- Update documents when you get a new pet, move states, or guardian situation changes
- Work with an estate attorney for complex situations

State Pet Trust Laws:
- All 50 states recognize pet trusts
- Most follow the Uniform Trust Code (UTC)
- State laws vary on: trust duration, enforcement mechanisms, trustee powers
- Our library has state-specific guides for all 50 states

Site Features:
- Library: 1,380+ free articles on pet estate planning, trusts, guardianship, emergency planning, breed guides, behavior guides, state laws
- Community: pet profiles, memorial tributes, weekly spotlights, breed guides, forum
- Rescue & Adoption: connects families with approved rescue organizations, moderated rehoming system
- National Directory: vets, shelters, rescues, trainers by state
- Planning Tools: guardian designation, emergency care cards, pet trust templates

GUIDED RECOMMENDATIONS:
Based on the user's question, suggest relevant resources:

- If asking about basic planning: "You might want to start with our Free Checklist or Basic Kit ($49) — both have guardian designation forms and emergency care cards."
- If asking about pet trusts or legal protection: "Our Ultimate Kit ($99) includes a pet trust template and 50-state law reference — perfect for what you're asking about."
- If asking about multiple pets or complex situations: "Our Platinum Service ($299) includes a 1-on-1 consultation where our team can build a custom plan for your specific situation."
- If asking about specific topics: "We have a whole section in our library on this — I'd recommend checking out [Article Name] in the [Hub Name] section."
- If asking about state-specific laws: "We have a detailed guide for your state in our Pet Trust Laws section."
- If asking about adoption or rescue: "Check out our Rescue & Adoption section — we connect families with approved organizations."

ANSWERING QUESTIONS:
- Simple questions: 2-4 sentences, warm and direct
- Complex questions (trusts, legal, estate): up to 8 sentences with clear structure
- Always validate the person's concern first — they're asking because they care about their pet
- For specific legal advice: explain the concept clearly, then say "For your specific situation, I'd recommend consulting with an estate attorney — we have state-specific resources in our library too"
- For pricing: always use the exact prices above
- For unknown topics: "That's a great question — I'd recommend reaching out to our team directly at PetLegacyPlanning.com for that one"
- When referencing library articles: mention them by name and suggest the user explore them in our library
- ALWAYS end with a guided recommendation: suggest a package, library section, or resource that matches their question
- End responses with a warm invitation to explore more or ask a follow-up
- NEVER make up specific legal statutes, case names, or dollar amounts you're not sure about`,
            },
            { role: "user", content: input.question },
          ],
        });
        const content = response?.choices?.[0]?.message?.content ?? "I'm here to help you protect the pets you love. Feel free to ask me anything about pet protection planning!";
        return { answer: content, sources: relevantArticles };
      }),
    ask: publicProcedure
      .input(z.object({ question: z.string().max(1200) }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are Chase, the warm and knowledgeable guide for Pet Legacy Planning (PetLegacyPlanning.com). You are 30 years old, speak at a medium pace, and have a caring, storytelling style — like a trusted friend who genuinely knows this topic inside and out.

YOUR PERSONALITY
- Warm, genuine, and encouraging — never robotic or clinical
- You speak conversationally, using real examples and relatable language
- You care deeply about pets and the families who love them
- You acknowledge emotions — planning for a pet's future is a sensitive topic

WHAT YOU KNOW

Pet Legacy Planning: The process of documenting pet care needs, designating trusted guardians, creating emergency care instructions, and legally protecting pets through wills, trusts, and care agreements.

Why It Matters:
- Over 500,000 pets end up in shelters each year because owners had no plan
- Without a plan, courts treat pets as property and can assign them to anyone
- Emergency responders won't know pets exist without an emergency card
- Pets grieve and suffer from sudden changes in care

Plans & Pricing:
- Free Checklist: Basic downloadable checklist, no cost
- Premium Kit ($34.95): Core planning documents, guardian designation form, emergency care card, digital storage
- Ultimate Kit ($69.95): Everything in Premium + pet trust template, legal documentation guide, 50-state law reference, memorial planning, rehoming safety guide, lifetime access
- Platinum Service ($179.95): Everything in Ultimate + our team personally builds your complete plan with you, 1-on-1 consultation, custom documents, priority support

Pet Trusts:
- A legally enforceable arrangement setting aside money and instructions for pet care after death or incapacity
- All 50 US states recognize pet trusts as legally valid
- Names a trustee (manages money) AND a caregiver (cares for the pet) — can be different people
- Typical funding: $5,000–$50,000 depending on pet age and needs
- Without a trust, money left "for a pet" in a will is NOT legally enforceable

Pet Guardianship:
- Designate a primary AND backup guardian
- Always ask the person first — never assume
- Include care instructions: feeding, vet info, medications, behavioral quirks, favorite toys
- Consider: space, other pets, allergies, financial ability

Emergency Planning:
- Emergency pet card for wallet with pet name, vet, and emergency contact
- Emergency pet stickers on front door for first responders
- Pet emergency binder: vet records, medications, feeding instructions, photos
- Name an emergency temporary caregiver who can take pet within 24 hours

What Happens Without a Plan:
- Pets may be surrendered to shelters by family members who can't care for them
- Pets can be euthanized if no one claims them within the shelter hold period
- Courts treat pets as property — awarded to anyone in estate disputes
- Informal money left "for the pet" in a will is not legally binding

Pet Estate Planning:
- Include pets in your will — name a guardian and leave funds for care
- Pet trust is stronger than a will provision because it's legally enforceable
- Update documents when you get a new pet, move states, or guardian situation changes
- Work with an estate attorney for complex situations

State Pet Trust Laws:
- All 50 states recognize pet trusts
- Most follow the Uniform Trust Code (UTC)
- State laws vary on: trust duration, enforcement mechanisms, trustee powers
- Our library has state-specific guides for all 50 states

Site Features:
- Library: 1,380+ free articles on pet estate planning, trusts, guardianship, emergency planning, breed guides, behavior guides, state laws
- Community: pet profiles, memorial tributes, weekly spotlights, breed guides, forum
- Rescue & Adoption: connects families with approved rescue organizations, moderated rehoming system
- National Directory: vets, shelters, rescues, trainers by state
- Planning Tools: guardian designation, emergency care cards, pet trust templates

ANSWERING QUESTIONS:
- Simple questions: 2-4 sentences, warm and direct
- Complex questions (trusts, legal, estate): up to 8 sentences with clear structure
- Always validate the person's concern first — they're asking because they care about their pet
- For specific legal advice: explain the concept clearly, then say "For your specific situation, I'd recommend consulting with an estate attorney — we have state-specific resources in our library too"
- For pricing: always use the exact prices above
- For unknown topics: "That's a great question — I'd recommend reaching out to our team directly at PetLegacyPlanning.com for that one"
- End responses with a warm invitation to explore more or ask a follow-up
- NEVER make up specific legal statutes, case names, or dollar amounts you're not sure about`,
            },
            { role: "user", content: input.question },
          ],
        });
        const content = response?.choices?.[0]?.message?.content ?? "I'm here to help you protect the pets you love. Feel free to ask me anything about pet protection planning!";
        return { answer: content };
      }),
  }),
  // ─── Avatar Q&A (alias) ───────────────────────────────────────────────────────────
  avatar: router({
    ask: publicProcedure
      .input(z.object({ question: z.string().max(1200) }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are Chase, a warm and knowledgeable pet protection advisor for PetLegacyPlanning.com. You speak with compassion, confidence, and genuine care for pets and their families. You help people understand pet trusts, estate planning, guardianship, emergency planning, and how to protect their pets. Plans: Free Checklist, Basic Kit $49, Ultimate Kit $99, Platinum $299. All 50 states recognize pet trusts. Keep answers warm, helpful, and 2-6 sentences. Never give specific legal advice — recommend consulting an estate attorney for complex situations.`,
            },
            { role: "user", content: input.question },
          ],
        });
        const content = response?.choices?.[0]?.message?.content ?? "I'm here to help you protect the pets you love. Please feel free to ask me anything about pet protection planning!";
        return { answer: content };
      }),
  }),
  // ─── Quiz ────────────────────────────────────────────────────────────────────────────────
  quiz: router({
    recordResponse: publicProcedure
      .input(z.object({
        score: z.number().min(0).max(5),
        answers: z.record(z.string(), z.boolean()),
      }))
      .mutation(async ({ ctx, input }) => {
        const { recordQuizResponse } = await import("./db");
        const userId = ctx.user?.id || null;
        const answers = input.answers as Record<string, boolean>;
        await recordQuizResponse(userId, input.score, answers);
        return { success: true };
      }),

    getStats: publicProcedure.query(async () => {
      const { getQuizStats } = await import("./db");
      const stats = await getQuizStats();
      return stats || {
        totalResponses: 0,
        averageScore: 0,
        highestScore: 0,
        lowestScore: 0,
        scoreDistribution: [],
        tierBreakdown: [],
      };
    }),
  }),

  // ─── Planner ────────────────────────────────────────────────────────────────────────────────
  planner: router({
    createProject: protectedProcedure
      .input(z.object({
        userId: z.number(),
        planTier: z.string(),
        title: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.id !== input.userId) {
          throw new Error("Unauthorized");
        }
        await createPlannerProject(input.userId, input.planTier, input.title);
        const projects = await getUserPlannerProjects(input.userId);
        return projects[projects.length - 1] || null;
      }),

    getUserProjects: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user?.id !== input.userId) {
          throw new Error("Unauthorized");
        }
        return await getUserPlannerProjects(input.userId);
      }),

    getProject: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ ctx, input }) => {
        const project = await getPlannerProject(input.projectId);
        if (!project || project.userId !== ctx.user?.id) {
          throw new Error("Unauthorized");
        }
        return project;
      }),

    updateProject: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        currentStep: z.number().optional(),
        data: z.any().optional(),
        status: z.enum(["in_progress", "completed"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const project = await getPlannerProject(input.projectId);
        if (!project || project.userId !== ctx.user?.id) {
          throw new Error("Unauthorized");
        }
        await updatePlannerProject(input.projectId, {
          currentStep: input.currentStep,
          data: input.data,
          status: input.status,
        });
        return await getPlannerProject(input.projectId);
      }),

    deleteProject: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const project = await getPlannerProject(input.projectId);
        if (!project || project.userId !== ctx.user?.id) {
          throw new Error("Unauthorized");
        }
        await deletePlannerProject(input.projectId);
        return { success: true };
      }),
  }),

  // ─── Stripe Payment Processing ─────────────────────────────────────────────────────
  stripe: router({
    createCheckoutSession: protectedProcedure
      .input(z.object({ planId: z.enum(["premium", "ultimate", "platinum"]), promoCode: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
        const origin = ctx.req.headers.origin || "https://petlegacyplanning.com";
        
        const PLANS: Record<string, { name: string; price: number }> = {
          premium: { name: "Premium Kit", price: 3495 },
          ultimate: { name: "Ultimate Kit", price: 6995 },
          platinum: { name: "Platinum Done-For-You", price: 17995 }
        };
        
        const plan = PLANS[input.planId];
        if (!plan) throw new Error("Invalid plan");
        
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ["card"],
          line_items: [
            {
              price_data: {
                currency: "usd",
                product_data: {
                  name: plan.name,
                  description: `Pet Legacy Planning - ${plan.name}`
                },
                unit_amount: plan.price
              },
              quantity: 1
            }
          ],
          mode: "payment",
          customer_email: ctx.user.email,
          allow_promotion_codes: true,
          success_url: `${origin}/thank-you?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${origin}/checkout/${input.planId}`,
          metadata: {
            user_id: ctx.user.id.toString(),
            plan_id: input.planId,
            customer_email: ctx.user.email,
            customer_name: ctx.user.name || "Customer"
          }
        });
        
        return { checkoutUrl: session.url };
      })
  }),
});

export type AppRouter = typeof appRouter;
