import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  // Dynamic sitemap.xml
  app.get("/sitemap.xml", async (_req, res) => {
    try {
      const { getAllLibraryArticleSlugs } = await import("../db.js");
      const articles = await getAllLibraryArticleSlugs();
      const BASE = "https://petlegacyplanning.com";
      const staticPages = [
        { loc: BASE, priority: "1.0", changefreq: "weekly" },
        { loc: `${BASE}/library`, priority: "0.9", changefreq: "daily" },
        { loc: `${BASE}/plans`, priority: "0.8", changefreq: "monthly" },
        { loc: `${BASE}/community`, priority: "0.7", changefreq: "weekly" },
        { loc: `${BASE}/memorial`, priority: "0.7", changefreq: "weekly" },
        { loc: `${BASE}/newsletter`, priority: "0.6", changefreq: "weekly" },
        { loc: `${BASE}/adoption`, priority: "0.6", changefreq: "daily" },
        { loc: `${BASE}/contact`, priority: "0.5", changefreq: "monthly" },
      ];
      // Hub pages
      const hubs = Array.from(new Set(articles.map((a: any) => a.hub)));
      const hubPages = hubs.map((hub) => ({
        loc: `${BASE}/library/${hub}`,
        priority: "0.8",
        changefreq: "weekly",
      }));
      // Article pages
      const articlePages = articles.map((a: any) => ({
        loc: `${BASE}/library/article/${a.slug}`,
        priority: "0.7",
        changefreq: "monthly",
        lastmod: a.updatedAt ? new Date(a.updatedAt).toISOString().split("T")[0] : undefined,
      }));
      const allPages = [...staticPages, ...hubPages, ...articlePages];
      const xml = [
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
        ...allPages.map((p: any) =>
          `  <url>\n    <loc>${p.loc}</loc>${p.lastmod ? `\n    <lastmod>${p.lastmod}</lastmod>` : ""}\n    <changefreq>${p.changefreq}</changefreq>\n    <priority>${p.priority}</priority>\n  </url>`
        ),
        `</urlset>`,
      ].join("\n");
      res.set("Content-Type", "application/xml");
      res.send(xml);
    } catch (err) {
      console.error("Sitemap error:", err);
      res.status(500).send("Error generating sitemap");
    }
  });

  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
