import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import {
  createDirectoryListing,
  getDirectoryListings,
  getDirectoryListingById,
  updateDirectoryListing,
  deleteDirectoryListing,
  searchListingsByCity,
  searchListingsByService,
  getApprovedListings,
} from "./db";

export const directoryRouter = router({
  // Create new directory listing
  createListing: publicProcedure
    .input(
      z.object({
        businessName: z.string().min(1),
        businessType: z.string().min(1),
        businessEmail: z.string().email(),
        businessPhone: z.string().min(10),
        businessWebsite: z.string().optional(),
        address: z.string().min(1),
        city: z.string().min(1),
        state: z.string().min(1),
        zipCode: z.string().optional(),
        description: z.string().optional(),
        services: z.string().optional(),
        listingTier: z.enum(["basic", "premium"]),
      })
    )
    .mutation(async (opts: any) => {
      const input = opts.input;
      return await createDirectoryListing({
        ...input,
        price: input.listingTier === "premium" ? 4900 : 0, // $49 grand opening, $0 basic
        approvalStatus: "pending",
      });
    }),

  // Get all listings (paginated)
  getListings: publicProcedure
    .input(
      z.object({
        limit: z.number().default(10),
        offset: z.number().default(0),
      })
    )
    .query(async (opts: any) => {
      const input = opts.input;
      return await getDirectoryListings(input.limit, input.offset);
    }),

  // Get listing by ID
  getListingById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async (opts: any) => {
      const input = opts.input;
      return await getDirectoryListingById(input.id);
    }),

  // Update listing
  updateListing: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        businessName: z.string().optional(),
        businessType: z.string().optional(),
        businessEmail: z.string().email().optional(),
        businessPhone: z.string().optional(),
        businessWebsite: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        zipCode: z.string().optional(),
        description: z.string().optional(),
        services: z.string().optional(),
        listingTier: z.enum(["basic", "premium"]).optional(),
      })
    )
    .mutation(async (opts: any) => {
      const input = opts.input;
      const { id, ...data } = input;
      return await updateDirectoryListing(id, data);
    }),

  // Delete listing (admin only)
  deleteListing: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async (opts: any) => {
      const input = opts.input;
      return await deleteDirectoryListing(input.id);
    }),

  // Search by city
  searchByCity: publicProcedure
    .input(z.object({ city: z.string() }))
    .query(async (opts: any) => {
      const input = opts.input;
      return await searchListingsByCity(input.city);
    }),

  // Search by service type
  searchByService: publicProcedure
    .input(z.object({ service: z.string() }))
    .query(async (opts: any) => {
      const input = opts.input;
      return await searchListingsByService(input.service);
    }),

  // Get approved listings for public directory
  getApprovedListings: publicProcedure
    .input(
      z.object({
        city: z.string().optional(),
        service: z.string().optional(),
        limit: z.number().default(20),
      })
    )
    .query(async (opts: any) => {
      const input = opts.input;
      return await getApprovedListings(input);
    }),
});
