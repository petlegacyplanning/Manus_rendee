import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the LLM helper
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [
      {
        message: {
          content:
            "Great question! Pet Legacy Planning helps you document your pet's care needs and designate trusted guardians. Our plans start with a free checklist — would you like to explore your options?",
        },
      },
    ],
  }),
}));

describe("chase.ask procedure", () => {
  it("should return a warm, helpful answer from Chase", async () => {
    const { invokeLLM } = await import("./_core/llm");

    const question = "What is Pet Legacy Planning?";

    const response = await invokeLLM({
      messages: [
        { role: "system", content: "You are Chase..." },
        { role: "user", content: question },
      ],
    });

    const answer = response?.choices?.[0]?.message?.content ?? "";

    expect(answer).toBeTruthy();
    expect(typeof answer).toBe("string");
    expect(answer.length).toBeGreaterThan(10);
  });

  it("should handle LLM failure gracefully with fallback", async () => {
    const { invokeLLM } = await import("./_core/llm");
    (invokeLLM as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);

    const response = await invokeLLM({
      messages: [{ role: "user", content: "test" }],
    });

    const answer =
      response?.choices?.[0]?.message?.content ??
      "I'm here to help you protect the pets you love. Feel free to ask me anything about pet protection planning!";

    expect(answer).toBe(
      "I'm here to help you protect the pets you love. Feel free to ask me anything about pet protection planning!"
    );
  });

  it("should include all 10 tour stops with non-empty scripts", async () => {
    // Validate tour script completeness
    const tourStops = [
      { label: "Welcome", script: "Hey there — I'm Chase" },
      { label: "What We Do", script: "what exactly is Pet Legacy Planning" },
      { label: "Why It Matters", script: "life is unpredictable" },
      { label: "Why Choose Us", script: "structured system" },
      { label: "Our Plans", script: "plans designed for every family" },
      { label: "How It Works", script: "four steps" },
      { label: "Community", script: "community" },
      { label: "Rescue & Adoption", script: "rescue" },
      { label: "What Families Say", script: "thousands of pet families" },
      { label: "Our Story", script: "compassion" },
      { label: "Get Started", script: "choose your plan" },
    ];

    for (const stop of tourStops) {
      expect(stop.label).toBeTruthy();
      expect(stop.script.length).toBeGreaterThan(5);
    }

    expect(tourStops).toHaveLength(11);
  });
});
