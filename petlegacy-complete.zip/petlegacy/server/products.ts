/**
 * Stripe Products & Pricing Configuration
 * Define all products and prices for Pet Legacy Planning
 */

export const STRIPE_PRODUCTS = {
  BASIC: {
    name: "Basic Plan",
    description: "Essential pet protection planning",
    price: 9900, // $99.00 in cents
    currency: "usd",
    features: [
      "Pet information storage",
      "Basic emergency contacts",
      "Digital pet profile",
      "Email support"
    ]
  },
  PREMIUM: {
    name: "Premium Plan",
    description: "Complete pet legacy planning with legal guidance",
    price: 19900, // $199.00 in cents
    currency: "usd",
    features: [
      "Everything in Basic",
      "Pet trust templates",
      "Legal document generator",
      "Guardian matching",
      "Priority email support"
    ]
  },
  ELITE: {
    name: "Elite Plan",
    description: "Full-service pet protection with expert consultation",
    price: 39900, // $399.00 in cents
    currency: "usd",
    features: [
      "Everything in Premium",
      "1-on-1 expert consultation",
      "Custom legal documents",
      "Lifetime updates",
      "24/7 phone support",
      "Memorial planning"
    ]
  }
};

/**
 * Grand Opening Promotion
 * 20% off all plans with code: grand20
 */
export const GRAND_OPENING_DISCOUNT = {
  code: "grand20",
  percentOff: 20,
  description: "Grand Opening Special - 20% Off"
};

/**
 * Calculate discounted price
 */
export function calculateDiscountedPrice(originalPrice: number, percentOff: number): number {
  return Math.round(originalPrice * (1 - percentOff / 100));
}

/**
 * Get all products as array for iteration
 */
export function getAllProducts() {
  return [
    { id: "basic", ...STRIPE_PRODUCTS.BASIC },
    { id: "premium", ...STRIPE_PRODUCTS.PREMIUM },
    { id: "elite", ...STRIPE_PRODUCTS.ELITE }
  ];
}
